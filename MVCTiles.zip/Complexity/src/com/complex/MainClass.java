package com.complex;
import com.complex.Regex;
import java.io.IOException;
public class MainClass {
	public static void main(String args[])throws IOException {
	int msg=Regex.findcomplex();
	System.out.println(msg);
	}	
}