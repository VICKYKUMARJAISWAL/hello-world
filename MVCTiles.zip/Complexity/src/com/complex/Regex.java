package com.complex;
import java.util.*;
import java.io.BufferedReader;
import java.io.*;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex {
	static List<Integer> myList = new ArrayList<Integer>();
	static int complex=1;
	public static void patternmatch(String pattern,String line) {
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(line);
		if (m.find( )) {
			
			if(m.group().equals("END IF")){
				myList.add(4);
			}
			else if(m.group().equals("IF")){
				myList.add(1);
			}
			else if(m.group().equals("ELSIF")){
				
				myList.add(2);
			}
			else if(m.group().equals("ELSE")){
				myList.add(3);
			}
			else if(m.group().equals("WHEN")){
				myList.add(5);
			}
			
		System.out.println(myList);	
		}
		
	}
	
public static int findcomplex() {
	
	try 
	{
		String sCurrLine,pattern;
		//String message;
		BufferedReader br = new BufferedReader(new FileReader("D:\\Arun\\examples\\ex4.txt"));
		while((sCurrLine = br.readLine()) != null){
			System.out.println(sCurrLine);
			pattern="IF|ELSE|ELSIF|END\\s?IF|WHEN";
			patternmatch(pattern,sCurrLine.toUpperCase());
			
		}
		System.out.println("List="+myList);
		for (int i = 0; i < myList.size(); i++) {
			if(myList.get(i)==4){
				if(myList.get(i-1)==1){
					continue;
				}
				else {
					complex++;
				}
			
			}
			if(myList.get(i)==2){
				complex++;
			}
			if(myList.get(i)==5){
					complex++;
			}
			if(myList.get(i)==3 && myList.get(i-1)==5){
				complex++;
			}
		}
		/*if(complex>40){
			message="Not at all testable\nVery high Cost and Effort\n";
		}
		else if(complex>20){
			message="Very complex Code\nLow Testability\nCost and Effort are high\n";
		}
		else if(complex>10){
			message="Complex Code\nMedium Testability\nCost and effort is Medium\n";
		}
		else {
			message="Structured and well written code\nHigh Testability\nCost and Effort is less\n";
		}*/
		
		//System.out.println("Complexity Value="+complex+"\n");
		//System.out.println("Meaning:\n"+message);
		//message="Complexity Value="+complex+"\n\nMeaning: \n"+message;
		br.close();
		
	}
	catch (IOException e) {
		e.printStackTrace();
	}
	return complex; 
}
}
