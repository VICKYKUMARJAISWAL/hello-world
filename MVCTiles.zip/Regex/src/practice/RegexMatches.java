package practice;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexMatches
{
	
	private static String REGEX = "printf";
    //private static String INPUT = "The dog says meow. " +
                                    //"All dogs say meow.";
    private static String REPLACE = "System.out.println";

    public static void main(String[] args) {
    	Pattern p = Pattern.compile(REGEX);
    	try 
    	{
    		BufferedReader br = new BufferedReader(new FileReader("D:\\hello.txt"));
    		String sCurrentLine;
    		
    		while ((sCurrentLine = br.readLine()) != null) {
    			System.out.println(sCurrentLine);
    			Matcher m = p.matcher(sCurrentLine); 
    			sCurrentLine=m.replaceAll(REPLACE);
    			System.out.println(sCurrentLine);
    		}

    	} catch (IOException e) {
    		e.printStackTrace();
    	} 

       //Pattern p = Pattern.compile(REGEX);
       // get a matcher object
       Matcher m = p.matcher(INPUT); 
       INPUT = m.replaceAll(REPLACE);
       System.out.println(INPUT);
   }
}