package com.igate.pagination;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;

import com.igate.product.Product;

public class Pagination extends HttpServlet
{
	
	SessionFactory factory;
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		 factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	}
	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1)
			throws ServletException, IOException {
		int totalNumberOfRecords=0;
		int recordPerPage=4;
		int pageIndex=0;
		
		String sPageIndex = arg0.getParameter("pageIndex");
		if(sPageIndex==null)
		{
			pageIndex=1;
		}
		else
		{
			pageIndex = Integer.parseInt(sPageIndex);
			
		}
		Session session = factory.openSession();
		int s  = (pageIndex*recordPerPage)-recordPerPage;
		Criteria crit = session.createCriteria(Product.class);
		crit.setFirstResult(s);
		crit.setMaxResults(recordPerPage);
		//System.out.println(s);
		//System.out.println(recordPerPage);
		List list = crit.list();
		Iterator it = list.iterator();
		PrintWriter out = arg1.getWriter();
		out.println("<table border=0>");
		out.println("<tr>");
		out.println("<th>"+"Id"+"</th>"+"<th>"+"Empname"+"<th>"+"Address");
		out.println("</tr>");
		
		while(it.hasNext())
		{
			Object obj = it.next();
			Product product = (Product)obj;
			out.println("<tr>");
			out.println("<td>"+product.getId()+"</td>"+"<td>"+product.getProName()+"</td>"+"<td>"+product.getPrice()+"</td>");
			out.println("</tr>");
			
		}
		out.println("</table>");
		Criteria crit1 = session.createCriteria(Product.class);
		crit1.setProjection(Projections.rowCount());
		
		List list1 = crit1.list();
		//System.out.println(list1);
		Iterator it1 = list1.iterator();
		if(it1.hasNext())
		{
			Object o = it1.next();
			totalNumberOfRecords = Integer.parseInt(o.toString());
			//System.out.println();
			
		}
		int noOfPages = totalNumberOfRecords/recordPerPage;
		if(totalNumberOfRecords>(noOfPages*recordPerPage))
		{
			noOfPages = noOfPages+1;
		}
		int i;
		for(i=1;i<=noOfPages;i++)
		{
			String myURL = "ind?pageIndex="+i;
			out.println("<a href="+myURL+">"+i+"</a>");
		}
		session.close();
		out.close();
		
		
	}
	@Override
	public void destroy() {
		factory.close();
		
		
	}
}
