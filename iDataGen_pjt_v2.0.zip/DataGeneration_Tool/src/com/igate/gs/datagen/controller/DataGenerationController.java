package com.igate.gs.datagen.controller;

public class DataGenerationController {

}
