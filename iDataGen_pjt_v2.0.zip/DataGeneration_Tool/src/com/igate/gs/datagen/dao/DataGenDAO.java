package com.igate.gs.datagen.dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import org.sqlite.SQLiteDataSource;
import org.sqlite.SQLiteJDBCLoader;

public class DataGenDAO {
	static Connection conn = null;
	static Connection conn1 = null;
	static Statement stmt = null;
	static Statement stmt1 = null;
	static ResultSet rst = null;
	static ResultSetMetaData metaData = null;
	static DatabaseMetaData dBmetaData = null;
	static PreparedStatement ps = null;
	private static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final int RANDOM_STRING_LENGTH = 10;
	static Scanner sc = new Scanner(System.in);

	public static Connection connected() throws Exception {
		boolean initialize = SQLiteJDBCLoader.initialize();

		SQLiteDataSource dataSource = new SQLiteDataSource();
		dataSource.setUrl("jdbc:sqlite:D:/idatagen/createschemadb.db");
		Connection conn = dataSource.getConnection();
		System.out.println("connected");
		return conn;

	}

	// method to generate random String
	public static String generateRandomString() {

		StringBuffer randStr = new StringBuffer();
		for (int i = 0; i < RANDOM_STRING_LENGTH; i++) {
			int number = getRandomNumber();
			char ch = CHAR_LIST.charAt(number);
			randStr.append(ch);
		}
		return randStr.toString();

	}

	// method to pick up the random value from the master look up table given
	// the column name of look up table
	public static String generateRandomDataFromMasterLookUpTable(
			Map<String, ArrayList<String>> map, String name) {

		Random randomNamesGenerator = new Random();
		ArrayList<String> nameList = new ArrayList<String>();

		String masterLookUpField = name;

		if (map.containsKey(masterLookUpField)) {
			nameList.addAll(map.get("Name"));
		}

		int nameListSize = nameList.size();

		// System.out.println(nameListSize);

		int index = randomNamesGenerator.nextInt(nameListSize);
		// System.out.println("................ name position"+index);
		// System.out.println(nameList.get(index));
		return nameList.get(index);

	}

	// method to add the given column from master lookup table to a map given
	// master table name
	public static Map<String, ArrayList<String>> getMasterTable(
			String masterTableName) throws Exception {
		String fetchMasterTable = "select * from " + masterTableName;
		Map<String, ArrayList<String>> masterTableMap = new HashMap<String, ArrayList<String>>();
		ArrayList<String> namesList = new ArrayList<String>();

		try {
			conn1 = connected();

			stmt = conn.createStatement();
			rst = stmt.executeQuery(fetchMasterTable);
			metaData = rst.getMetaData();

			String[] masterColumnNames = new String[metaData.getColumnCount()];

			for (int m = 1; m <= metaData.getColumnCount(); m++) {
				masterColumnNames[m - 1] = metaData.getColumnName(m);
			}

			for (int n = 0; n < metaData.getColumnCount(); n++) {
				if (masterColumnNames[n].equalsIgnoreCase("name")) {
					String fetchNamesQuery = "select " + masterColumnNames[n]
							+ " from " + masterTableName;
					// Connection conn= connected();
					stmt = conn.createStatement();
					rst = stmt.executeQuery(fetchNamesQuery);

					while (rst.next()) {
						namesList.add(rst.getString(1));

					}
					System.out.println(namesList);
					masterTableMap.put(masterColumnNames[n], namesList);

				}
			}

			return masterTableMap;

		} finally {
			conn1.close();
		}

	}

	// method to generate random Number
	public static int getRandomNumber() {
		int randomInt = 0;
		Random randomGenerator = new Random();
		randomInt = randomGenerator.nextInt(CHAR_LIST.length());

		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}
	}

	// method to get the metaData for a given table
	public static Map<String,String> getMetaData(String tableName) throws Exception {
		String sqlQuery = "select * from " + tableName;
		Map<String,String> metaDataMap = new LinkedHashMap<String,String>();
		
		try {
			conn = connected();
			stmt = conn.createStatement();
			rst = stmt.executeQuery(sqlQuery);
			metaData = rst.getMetaData();
	
			System.out.println("Table Name :" + metaData.getTableName(1));
			System.out.println("Number of Columns: "
					+ metaData.getColumnCount());
			System.out.println("Column details:");
			
		

			for (int i = 1; i <= metaData.getColumnCount(); i++) {
				System.out.print(metaData.getColumnName(i) + "("
						+ metaData.getColumnTypeName(i) +")   ");
			
				metaDataMap.put(metaData.getColumnName(i).trim(), metaData.getColumnTypeName(i).trim());

			}
			System.out.println("\n");

		} finally {
			conn.close();
		}

		return metaDataMap;

	}

	// method to insert the random values and values from master look up table
	// given the table name
	public static String InsertDataToTable(String tableName, String primaryKey)
			throws Exception {

		String sqlQuery = "select * from " + tableName;
		String primaryColumnName = null;
		String primaryColumnValue = null;
		StringBuilder sb1 = null;

		if (primaryKey != null) {
			String[] primaryValues = primaryKey.split("=");
			primaryColumnName = primaryValues[0];
			primaryColumnValue = primaryValues[1];
		}
		try {
			conn = connected();
			stmt = conn.createStatement();
			rst = stmt.executeQuery(sqlQuery);
			metaData = rst.getMetaData();

			String[] columnNamesType = new String[metaData.getColumnCount()];
			String[] columnNames = new String[metaData.getColumnCount()];

			for (int i = 1; i <= metaData.getColumnCount(); i++) {

				columnNamesType[i - 1] = metaData.getColumnTypeName(i);
				columnNames[i - 1] = metaData.getColumnName(i);

			}

			sb1 = new StringBuilder("INSERT INTO " + metaData.getTableName(1)
					+ "(");

			for (int j = 0; j < metaData.getColumnCount(); j++) {
				sb1.append(columnNames[j] + ",");
			}

			sb1.deleteCharAt(sb1.length() - 1);
			sb1.append(") VALUES(");

			for (int m = 0; m < 1; m++) {
				String columnType = "";
				String columnName = "";
				int temp = 0;
				for (int l = 0; l < metaData.getColumnCount(); l++) {

					columnType = columnNamesType[l].trim();
					columnName = columnNames[l].trim();

					if (l != 0) {
						sb1.append(",");
					}

					if (primaryColumnName != null
							&& columnName.equalsIgnoreCase(primaryColumnName)) {
						sb1.append(primaryColumnValue);

					} else {
						if (columnType.equals("VARCHAR")
								&& columnName.equalsIgnoreCase(columnName)) {

							Map map = getMasterTable("MasterLookUpTable");

							sb1.append("'" + generateRandomDataFromMasterLookUpTable(
									map, "Name") + "'");
						}

						else if (columnType.equals("VARCHAR")) {
							sb1.append("'" + generateRandomString() + "'");
						}

						else if (columnType.equals("INTEGER")) {
							sb1.append(getRandomNumber());
						}

						else if (columnType.equals("NUMERIC")) {
							sb1.append(getRandomNumber());
						}
					}

				}
				sb1.append(")");
				System.out.println(sb1);

			}

		} finally {
			conn.close();
		}

		return sb1.toString();

	}

	public static void main(String[] args) throws Exception {

		System.out
				.println("Enter the Table Name which you want to get the details");
		String tableName = sc.nextLine();

		getMetaData(tableName);

	}

}
