package com.igate.gs.datagen.dao;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.sqlite.SQLiteDataSource;
import org.sqlite.SQLiteJDBCLoader;

public class DataGenerationDao {
	public static void main(String[] args) throws Exception {

		String schemaFile = "D:/schema.sql";

		String[] sqlCmds = readSql(schemaFile);

		createTable(sqlCmds);

		referenceChk(sqlCmds);

		// insertTables();

		// String tableName = "records";

		// List<String> columnNames =
		// BUDataColumnsFinder.getColumnNames(tableName, schemaFile);

	}

	public static String[] readSql(String schema) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(
				new FileInputStream(schema)));
		String sqlString = "";
		String line;
		while ((line = br.readLine()) != null) {
			sqlString = sqlString + line;
		}
		br.close();
		sqlString = sqlString.replaceAll("`", "");
		System.out.println("Schema File Lines: " + sqlString);
		// return sqlString;
		String sqlSubs[] = sqlString.split(";");
		return sqlSubs;
	}

	// Function to chk for references keyword

	public static void referenceChk(String[] sqlsubs) {

		for (int i = 0; i < sqlsubs.length; i++) {
			if (sqlsubs[i].contains("REFERENCES")) {
				System.out.println(sqlsubs[i]);
			} else
				System.out.println(sqlsubs[i]);
		}
	}

	/**
	 * @Description Checks the master data table for references of a particular table
	 * @param tableName
	 * @return
	 */
	public static Map<String, String> checkReferences(String tableName) {
		PreparedStatement stmt = null;
		String query = "Select * FROM MasterReferencesTable WHERE TableName is ? ";
		Map<String, String> referenceValues = new HashMap<String, String>();
		try {
			Connection conn = connected();

			stmt = conn.prepareStatement(query);
			stmt.setString(1, tableName);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				String refTable = rs.getString("ReferenceTable");
				String refColumnName = rs.getString("ReferenceColumn");
				String foreignKeyColumn = rs.getString("TableRefColumn");
				if (refTable != null && refColumnName != null && foreignKeyColumn!=null) {
					referenceValues.put(foreignKeyColumn, refTable+","+refColumnName);
				} else {
					referenceValues = null;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return referenceValues;
	}

	public static Connection connected() throws Exception {
		boolean initialize = SQLiteJDBCLoader.initialize();

		SQLiteDataSource dataSource = new SQLiteDataSource();
		dataSource.setUrl("jdbc:sqlite:D:/idatagen/idatagendb.db");
		Connection conn = dataSource.getConnection();
		System.out.println("connected");
		return conn;

	}

	public static boolean createTable(String[] sqlCmds) throws SQLException,
			Exception {

		try {
			Connection conn = connected();
			for (int i = 0; i < sqlCmds.length; i++)
				conn.createStatement().executeUpdate(sqlCmds[i]);

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;

	}

	/**
	 * @Description Inserts the sql query into db
	 * @param sqlCmd
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	public static boolean insertTables(String sqlCmd) throws SQLException,
			Exception {
		int updated = 0;

		try {
			Connection conn = connected();
			updated = conn.createStatement().executeUpdate(sqlCmd);

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Sql cmd inserted " +sqlCmd+"  "+ updated);
		if (updated != 0) {
			return true;
		} else {
			return false;
		}

	}
	
	/**
	 * @Description Check if a particular value exists in the respective table
	 * @param arr
	 * @return
	 * @throws SQLException 
	 */
	public static Boolean checkValueExists(ArrayList arr) throws SQLException
 {
		PreparedStatement stmt = null;
		String query = "Select * FROM " + arr.get(0) + " WHERE " + arr.get(1)
				+ "=?";
		ResultSet rs = null;
		int updated = 0;
		try {
			Connection conn = connected();
			stmt = conn.prepareStatement(query);
			stmt.setString(1, arr.get(2).toString());
			rs = stmt.executeQuery();
			while (rs.next()) {
				updated = 1;
			}

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			rs.close();
			stmt.close();
		}

		if (updated != 0) {
			return true;
		} else {
			return false;
		}

	}


}
