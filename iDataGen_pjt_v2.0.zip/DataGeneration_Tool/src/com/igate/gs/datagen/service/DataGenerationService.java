package com.igate.gs.datagen.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.igate.gs.datagen.dao.DataGenDAO;
import com.igate.gs.datagen.dao.DataGenerationDao;

public class DataGenerationService {

	private static Map<String, String> dependencyMap = new LinkedHashMap<String, String>();
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		try {
			buildInsertQuery("Employee");
			// insertRandomRecord();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @Description Builds the insert query from the records in flat file.
	 *              Assume file name is same as table name
	 * @param fileName
	 * @throws Exception
	 * @throws SQLException
	 */
	public static void buildInsertQuery(String tableName) throws SQLException,
			Exception {

		String records[] = getRecordsFromFile(tableName);
		String headerString = records[0];
		String recordValues = records[1];
		String[] values = recordValues.split(";");
		for (String rec : values) {
			String insertQuery = "INSERT INTO " + tableName + "("
					+ headerString + ") " + "VALUES(" + rec + ")";
			Boolean isInserted = insertValues(insertQuery);
		}

	}

	/**
	 * @Description checks if references exist for the given table and retrieves
	 *              them
	 * @param tableName
	 * @return
	 * @throws IOException
	 */
	public static String[] getRecordsFromFile(String tableName)
			throws IOException {

		String fileName = "\\D:" + tableName + ".sql";
		BufferedReader br = new BufferedReader(new InputStreamReader(
				new FileInputStream(fileName)));
		StringBuilder sqlString = new StringBuilder("");
		String headerString = null;
		String line;

		int index = 0;
		while ((line = br.readLine()) != null) {
			if (index == 0) {
				headerString = line;
			} else {
				sqlString = sqlString.append(line).append(";");
			}
			index++;
		}
		br.close();

		return new String[] { headerString, sqlString.toString() };
	}

	/**
	 * @throws Exception
	 * @Description Inserts the records randomly generated using the data
	 *              generator
	 */
	public static void insertRandomRecord() throws Exception {
		System.out
				.println("Enter the Table Name which you want to get the details");
		String tableName = sc.nextLine();
		System.out
				.println("Enter the Number of record you want to Insert into the table");
		int NoOfRec = sc.nextInt();
		for (int i = 0; i < NoOfRec; i++) {
			String insertQuery = DataGenDAO.InsertDataToTable(tableName, null);

			Boolean isInserted = insertValues(insertQuery);
		}
	}

	/**
	 * @Description Inserts the record into table after checking all the
	 *              necessary conditions
	 * @throws SQLException
	 * @throws Exception
	 */
	public static Boolean insertValues(String insertQuery) throws SQLException,
			Exception {

		Boolean isInserted = false;
		String tableName = null;
		Boolean returnValue =false;
		ArrayList<String> arr = new ArrayList<String>();

		tableName = getTableName(insertQuery, "INTO", "\\(");

		Map<String, String> referenceTable = checkReferences(tableName);

		if (!dependencyMap.containsKey(tableName + "Map")) {
			dependencyMap.put(tableName + "Map", insertQuery);
		}

		if (referenceTable == null) {
			isInserted = DataGenerationDao.insertTables(insertQuery);
			if (isInserted) {
				dependencyMap.remove(tableName + "Map");
			}
		} else {
			int noOfReferences = referenceTable.size();
			for (Map.Entry<String, String> ref : referenceTable.entrySet()) {

				String foreignKeyColumn = ref.getKey();
				String referenceData = ref.getValue();

				String refColumnValue = getReferenceValue(insertQuery,
						foreignKeyColumn);

				String[] refValues = referenceData.split(",");
				arr.add(0, refValues[0]);
				arr.add(1, refValues[1]);
				arr.add(2, refColumnValue);

				Boolean valueExists = DataGenerationDao.checkValueExists(arr);
				System.out.println(valueExists);

				noOfReferences = noOfReferences - 1;

				if (valueExists) {
					if (noOfReferences != 0) {
						continue; // Does not let you insert unless all the
									// references exist
					}
					isInserted = DataGenerationDao.insertTables(insertQuery);

					if (isInserted) {
						dependencyMap.remove(tableName + "Map");
					}
				} else {

					String insertDependantQuery = DataGenDAO.InsertDataToTable(
							refValues[0], refValues[1] + "=" + refColumnValue);
					insertValues(insertDependantQuery);

				}

			}

			if (!dependencyMap.isEmpty()) {
				ListIterator<Map.Entry<String, String>> iterator = new ArrayList<Map.Entry<String, String>>(
						dependencyMap.entrySet()).listIterator(dependencyMap
						.size());

				while (iterator.hasPrevious()) {
					Map.Entry<String, String> tableMap = iterator.previous();

					if (tableMap.getValue() != null) {
						String insertQueryLeft = tableMap.getValue();
						 returnValue = insertValues(insertQueryLeft);
						 if(returnValue==true)
						 {
							 break;
						 }
					}
				}
			}
		}

		return true;
	}

	/**
	 * @Description Extracts the table name from the respective query and
	 *              returns it
	 * @param query
	 * @param prefix
	 * @param postFix
	 * @return String - table name
	 */
	public static String getTableName(String query, String prefix,
			String postFix) {
		String tableName = null;
		Pattern pattern = Pattern.compile("(?<=" + prefix + ").*?(?=" + postFix
				+ ")");
		Matcher matcher = pattern.matcher(query);
		while (matcher.find()) {
			tableName = matcher.group().trim().toString();
		}
		return tableName;
	}

	/**
	 * @Description checks if references exist for the given table and retrieves
	 *              them
	 * @param tableName
	 * @return
	 */
	private static Map<String, String> checkReferences(String tableName) {
		Map<String, String> referenceTable = DataGenerationDao
				.checkReferences(tableName);

		/*
		 * for (Map.Entry<String, String> ref : referenceTable.entrySet()) {
		 * System.out.println(ref.getKey() + "  " + ref.getValue()); }
		 */

		return referenceTable;
	}

	/**
	 * @Description Gets the value of the foreign key which has to be inserted
	 * @param insertQuery
	 * @return
	 */
	public static String getReferenceValue(String insertQuery,
			String foreignKeyColumn) {
		int index = 0;
		int columnIndex = 0;
		List<String> subStrings = new ArrayList<String>();

		Pattern pattern = Pattern.compile("\\(([^)]*)\\)");
		Matcher matcher = pattern.matcher(insertQuery);
		while (matcher.find()) {
			subStrings.add(matcher.group(1));
		}

		String headerString = subStrings.get(0).toString();
		String dataString = subStrings.get(1).toString();

		String[] headerColumns = headerString.split(",");
		for (String columnName : headerColumns) {
			if (foreignKeyColumn.equals(columnName)) {
				columnIndex = index;
			} else {
				index++;
			}
		}

		String[] dataColumn = dataString.split(",");
		System.out.println(dataColumn[columnIndex]);
		return dataColumn[columnIndex];

	}

}
