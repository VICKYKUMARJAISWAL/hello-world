package com.idatagen.query;

import com.idatagen.util.CommonUtils;
import com.igate.db.dao.SqlDynamicGeneratorDAO;

public class SqlDynamicQueryBuild {

	SqlDynamicGeneratorDAO sqlDynamicDao = new SqlDynamicGeneratorDAO();

	public boolean sqlQueryGenerator(String tableName, String[] fieldNames,
			String[] dataTypes, String[] constraints) {
		
		boolean isQueryExecuted = sqlDynamicDao.createSqlQuery(tableName,
				fieldNames, dataTypes, constraints);
		return isQueryExecuted;

	}

	public static void main(String[] args) {
		String tableName = "Students10";
		String fieldName[] = { "Student_ID", "Student_Name", "College",
				"Dept_ID", "Class_Teacher" };
		String dataType[] = { "int", "", "", "int", "" };
		String constraint[] = { "PRIMARY KEY", "", "", "", "NOT NULL" };
		System.out.println("In main method");

		SqlDynamicQueryBuild fields = new SqlDynamicQueryBuild();
		boolean isCreated = fields.sqlQueryGenerator(tableName, fieldName,
				dataType, constraint);

		if (isCreated == true)
			System.out.println("Query Executed");
		else
			System.out.println("QUERY NOT Executed");
	}

}
