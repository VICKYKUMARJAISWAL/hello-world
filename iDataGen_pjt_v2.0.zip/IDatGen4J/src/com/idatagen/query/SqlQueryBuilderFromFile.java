package com.idatagen.query;

import java.io.IOException;

import com.igate.db.dao.SqlDataGeneratorDAO;

public class SqlQueryBuilderFromFile {
	
	public boolean batchInsert(String[] query) throws IOException{
		SqlDataGeneratorDAO sqlFile = new SqlDataGeneratorDAO();
		String [] batchQuery = query;
		
		boolean isQueryExecuted = sqlFile.executeBatchSqlFile(batchQuery);
		return isQueryExecuted;
	}

}
