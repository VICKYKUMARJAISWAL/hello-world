package com.idatagen.query;

import java.util.ArrayList;
import java.util.List;

import com.idatagen.util.Utility;
import com.idategen.data.reader.DataResultSet;
import com.igate.dto.ColumnDetail;

public class SqliteQueryBuider {

	String sql;
	final String  SPACE = " ";
	final String  COMMA = ","; 
	public String[] getInsertBatchQuery(List<ColumnDetail> filecolumns, DataResultSet filedata, String tablename){
		//insert into (c1,c2) values (?,?);
		StringBuilder sb = new StringBuilder();
		String []queries = new String[2];
		String sql = "insert into "+tablename;
				
		String columnparam = "(";
		String valueparam = "values (";
		for(int i = 0; i < filecolumns.size(); i++){
			ColumnDetail cd = filecolumns.get(i);
			String filecolumnname = cd.getColumnName();
			String dbcolumn = (cd.getMappedColumn() == null) ? filecolumnname : cd.getMappedColumn().getColumnName();			 
			columnparam += dbcolumn+",";
			valueparam +="?,";
		}
		
		//columnparam = columnparam.replace(columnparam.charAt(columnparam.lastIndexOf(","))+"", ") ");
		columnparam = columnparam.substring(0, columnparam.lastIndexOf(","))+") ";
		valueparam = valueparam.substring(0, valueparam.lastIndexOf(","))+") ";
		
		sb.append(sql).append(columnparam).append(valueparam);
		queries[0]=sb.toString();
		System.out.println(sb.toString());
		return queries;
	}
	
	
	public String buildSelectQuery(List<ColumnDetail> columns, List params, String tablename){
		StringBuilder sb = new StringBuilder("select");
		
		for(int i = 0; i < columns.size(); i++){
			ColumnDetail column = columns.get(i);
			sb.append(SPACE)
				.append(column.getColumnName())
				.append(COMMA);
		}
		sb.deleteCharAt(sb.lastIndexOf(","))
		.append(SPACE)
		.append("from")
		.append(SPACE)
		.append(tablename);
		if(null != params){
			sb.append(SPACE)
				.append("where");
			for(int i = 0; i < params.size(); i++){
				sb.append(SPACE)
				  .append(params.get(i));
			}
		}
		System.out.println("buildSelectQuery:: sql before return = " +sb.toString());			
		return sb.append(";").toString();
	}
	
public String[] buildAddColumnQuery(List<ColumnDetail> filecolumns,String tablename){
		
		
		/**
		 * Alter table tablename add column columnn1 char(127), column2 char(127); 
		 * 
		 *
		 */
		String [] queries = new String[filecolumns.size()];
		
		int count=0;
		String defaultype = " char(127) ";
		
		for(int i = 0; i < filecolumns.size(); i++){
				
			ColumnDetail cd = filecolumns.get(i);
			if(cd.isPresentInDB() || cd.getMappedColumn() != null){
				System.out.println("Removing from alter "+cd.getColumnName());
				continue;
			}
			String columntype = cd.getColumnType();
			if(!Utility.isValidDataType(columntype))
				columntype = defaultype;
			StringBuilder sb = new StringBuilder("Alter table");
			sb.append(SPACE)
			  .append(tablename)
			  .append(SPACE)
			  .append("add column")
			  .append(SPACE)
			  .append(cd.getColumnName())
			  .append(SPACE)
			  .append(columntype)
			  .append(";");		
			queries[count++]= sb.toString();
		}
		//sb.replace(sb.lastIndexOf(COMMA), sb.lastIndexOf(SPACE), ";");
		//System.out.println(sb.toString());
		
		System.out.println("length = "+queries.length);		
		return queries;
	}

	public static void main(String args[]){
		ColumnDetail c1 = new ColumnDetail();
		c1.setColumnName("empname");
		ColumnDetail c2 = new ColumnDetail();
		c2.setColumnName("empval");
		SqliteQueryBuider qb = new SqliteQueryBuider();
		List<ColumnDetail> lists = new ArrayList<>();
		lists.add(c1);
		lists.add(c2);
		String sql = qb.buildSelectQuery(lists, null, "table1");
	//	qb.getInsertBatchQuery(lists, null, "t1");
		System.out.println("sql = "+sql);
		
		int [] arr = new int[3];
		System.out.println(arr.length);
		
		
	}
}
