package com.idatagen.util;

import java.util.ArrayList;
import java.util.List;

public class QueryReferenceCheck {

	public static String MASTERTABLE = "MasterReferencesTable";
	public static String OPENBRACE = "(";
	public static String CLOSEBRACE = ")";
	public static String COMA = ",";
	public static String INSERTONESPACE = " "; // Don't change the Space length
												// (1)
	public static String NOTNULL = "NOT NULL";
	public static String PRIMARYKEY = "PRIMARY KEY";
	public static String FOREIGNKEY = "FOREIGN KEY";
	
	public static String NOT_NULL = "NOT_NULL";
	public static String PRIMARY_KEY = "PRIMARY_KEY";
	public static String FOREIGN_KEY = "FOREIGN_KEY";
	

	// public static String reference = "";

	public String[] referenceChecker(String[] queries) {
		String query = "";
		String queryModified = "";
		
		String tableName = "";
		String tableRefColumn = "";
		String refTable = "";
		String refTableColumn = "";
		
		String[] insertQuerries =null;
		List<String> queryList = new ArrayList<String>();
		

		int queriesSize = queries.length;
		for (int i = 0; i < queriesSize; i++) {
			query = queries[i];

			queryModified = CommonUtils.insertCharBeforeAndAfter(query, OPENBRACE, INSERTONESPACE);
			queryModified = CommonUtils.insertCharBeforeAndAfter(queryModified,CLOSEBRACE, INSERTONESPACE);
			System.out.println("*************** 1 "+queryModified);
			queryModified = CommonUtils.replaceCharatersFromStr(queryModified, COMA, INSERTONESPACE);
			System.out.println("*************** 2 "+queryModified);
			queryModified = CommonUtils.removeExtraSpacesToOneSpace(queryModified);
			queryModified = queryModified.toUpperCase();
			queryModified = CommonUtils.replaceCharatersFromStr(queryModified, NOTNULL, NOT_NULL);
			queryModified = CommonUtils.replaceCharatersFromStr(queryModified, PRIMARYKEY, PRIMARY_KEY);
			queryModified = CommonUtils.replaceCharatersFromStr(queryModified, FOREIGNKEY, FOREIGN_KEY);
			System.out.println("*************** 3 "+queryModified);
			
			String[] querySplited = queryModified.split(" ");
			System.out.println("SPLITTED QUERY :: ");
			for (int j =0; j< querySplited.length;j++) {
				System.out.println("INDEX "+j+": " + querySplited[j]);
			}
			
			
			// Checking References
			for (int k = 0; k < querySplited.length; k++) {
				System.out.println(">> >> > Loop* " + k);
				if (querySplited[k].equalsIgnoreCase("TABLE")) {
					tableName = querySplited[k + 1];
					k++;
				}

				System.out.println(">> >> > Loop** " + k);
				if (querySplited[k].equals("REFERENCES")) {
					tableRefColumn = querySplited[k - 2];
					refTable = querySplited[k + 1];
					refTableColumn = querySplited[k + 3];
					System.out.println("> Table_Name : " + tableName+ ", Table Ref. Column : " + tableRefColumn+ ", Reference table : " + refTable+ ", Reference Table Colum : " + refTableColumn);
					k = k + 4;
					System.out.println("@@@@ index : " + querySplited[k]);

					String queryCreated = "INSERT INTO "+ MASTERTABLE+ "(TableName, TableRefColumn, ReferenceTable, ReferenceColumn) VALUES ('"+ tableName + "', '" + tableRefColumn + "', '"+ refTable + "', '" + refTableColumn + "');";
					queryList.add(queryCreated);
					System.out.println("QUERY CREATED : " + queryCreated);

				}

				System.out.println(">> >> > Loop*** " + k);
			}
			insertQuerries = queryList.toArray(new String[queryList.size()]);

			System.out.println("Array Size : " + insertQuerries.length);
		}
		return insertQuerries;

	}

		
	
	
	
	public static void main(String[] args) {
		String tableName = "";
		String tableRefColumn = "";
		String refTable = "";
		String refTableColumn = "";

		/* Finding index positions of a word in multiple positions - Starts here */
		// TODO Auto-generated method stub
		String testStr = "This example shows how we can search a REFERENCES within a String object using indexOf() method which returns a position index of a REFERENCES within the string if found. Otherwise it returns -1.";
		String searchWord = "REFERENCES".toLowerCase();

		int strLength = testStr.length();
		int wordLength = searchWord.length();

		System.out.println("Word Length : " + wordLength);
		int wordPosition = testStr.toLowerCase().indexOf(searchWord);
		System.out.println("Occurance 100@: " + wordPosition);
		int searchFrom = wordPosition + wordLength;
		/*
		 * for (int i = searchFrom; i < strLength; i++) {
		 * 
		 * }
		 */
		int occurance = 2;
		while (true) {

			wordPosition = testStr.toLowerCase()
					.indexOf(searchWord, searchFrom);
			searchFrom = wordPosition + wordLength;

			System.out.println("**Occurance " + occurance + " 100@: "
					+ wordPosition);
			occurance++;

			if (wordPosition == -1)
				break;

		}
		/* ENDS HERE */

		//String str = "CREATE TABLE Orders(O_Id int NOT NULL PRIMARY KEY,OrderNo int NOT NULL,P_Id int FOREIGN KEY REFERENCES Persons(PER_Id), TEST_Id int FOREIGN KEY REFERENCES COMPANY(CAN_Id))";
		
		String str = "CREATE TABLE orders (id INTEGER PRIMARY KEY,customer_id INTEGER,salesperson_id INTEGER,FOREIGN KEY(customer_id) REFERENCES customers(id),FOREIGN KEY(salesperson_id) REFERENCES salespeople(id));";
		
		// str = new StringBuffer(str).insert(str.length() - 2, ".").toString();
		str = str.replaceAll("\\s+", " ").toLowerCase();
		System.out.println("==== >>" + str);
		searchWord = "(";
		wordLength = searchWord.length();
		wordPosition = str.toLowerCase().indexOf(searchWord);
		System.out.println("Occurance 1@: " + wordPosition);
		searchFrom = wordPosition + wordLength;
		while (true) {

			str = new StringBuffer(str).insert(wordPosition, " ").toString();
			str = new StringBuffer(str).insert(wordPosition + 2, " ")
					.toString();
			wordPosition = str.toLowerCase()
					.indexOf(searchWord, searchFrom + 3);
			searchFrom = wordPosition + wordLength;

			if (wordPosition == -1)
				break;
			System.out.println("==== >>" + str);

		}

		searchWord = ")";
		wordLength = searchWord.length();
		wordPosition = str.toLowerCase().indexOf(searchWord);
		System.out.println("Occurance 1@: " + wordPosition);
		searchFrom = wordPosition + wordLength;
		while (true) {

			str = new StringBuffer(str).insert(wordPosition, " ").toString();
			str = new StringBuffer(str).insert(wordPosition + 2, " ")
					.toString();
			wordPosition = str.toLowerCase()
					.indexOf(searchWord, searchFrom + 3);
			searchFrom = wordPosition + wordLength;

			if (wordPosition == -1)
				break;
			System.out.println("==== >>" + str);
		}

		str = str.replaceAll(",", " ");
		str = str.replaceAll("\\s+", " ").toUpperCase();
		System.out.println("==== >>" + str);

		String strOriginal = str;

		/*
		 * StringBuffer sb = new StringBuffer(str);
		 */
		if (str.contains("NOT NULL")) {
			str = str.replaceAll("NOT NULL", "NOT_NULL");
		}
		if (str.contains("PRIMARY KEY")) {
			str = str.replaceAll("PRIMARY KEY", "PRIMARY_KEY");
		}
		if (str.contains("FOREIGN KEY")) {
			str = str.replaceAll("FOREIGN KEY", "FOREIGN_KEY");
		}

		System.out.println("==== >>" + str);
		// Spliting the Query
		String[] querySplited = str.split(" ");

		for (String part : querySplited) {
			System.out.println(">> " + part);
		}
		// tableName = querySplit[3];

		// Checking References
		List<String> queryList = new ArrayList<String>();
		for (int i = 0; i < querySplited.length; i++) {
			System.out.println(">> >> > Loop* " + i);
			if (querySplited[i].equalsIgnoreCase("TABLE")) {
				tableName = querySplited[i + 1];
				i++;
			}

			System.out.println(">> >> > Loop** " + i);
			if (querySplited[i].equals("REFERENCES")) {
				tableRefColumn = querySplited[i - 2];
				refTable = querySplited[i + 1];
				refTableColumn = querySplited[i + 3];
				System.out.println(" Table_Name : " + tableName
						+ ", Table Ref. Column : " + tableRefColumn
						+ ", Reference table : " + refTable
						+ ", Reference Table Colum : " + refTableColumn);
				i = i + 4;
				System.out.println("@@@@ : " + querySplited[i]);

				String queryCreated = "INSERT INTO "
						+ MASTERTABLE
						+ "(TableName, TableRefColumn, ReferenceTable, ReferenceColumn) VALUES ('"
						+ tableName + "', '" + tableRefColumn + "', '"
						+ refTable + "', '" + refTableColumn + "');";
				queryList.add(queryCreated);
				System.out.println("QUERY CREATED : " + queryCreated);

			}

			System.out.println(">> >> > Loop*** " + i);
		}
		String[] querries = queryList.toArray(new String[queryList.size()]);

		System.out.println("Array Size : " + querries.length);

		/*
		 * String mytext = " hello()      there  hi, how a,re       	you    ";
		 * //mytext = mytext.replaceAll("( )+", " "); mytext =
		 * mytext.replaceAll("[\\s, ]+", " ");
		 * System.out.println("++++++++:"+mytext);
		 */

	}

}