package com.idategen.data.reader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.igate.dto.ColumnDetail;



public class DataResultSet {

	
	private Map<ColumnDetail,List<String>> dataMap;
	private List<String[]> lines = new ArrayList<>();
	private List<ColumnDetail> sourceColumnList; 
	
	public DataResultSet(){
		dataMap = new LinkedHashMap<ColumnDetail, List<String>>();
	}
	
	public boolean keep(ColumnDetail colummndetail,List<String> dataset ){
		
		if(null == colummndetail)
			return false;
		if(null == dataset){
				return false;
		}
		
		dataMap.put(colummndetail, dataset);
		
		return true;
	}
	
	public List<ColumnDetail> getSourceColumnList(){
		if(sourceColumnList == null || sourceColumnList.isEmpty()){
			List<ColumnDetail> clist = new ArrayList<>(dataMap.keySet());
			return clist;
		}
		else
			return sourceColumnList;
				
		
	}
	public void setSourceColumnList(List<ColumnDetail> columns){
		this.sourceColumnList = columns;				
	}
	public List<String> retrive(ColumnDetail key){
		
		return dataMap.get(key);
	}
	
	public void setHorizontalData(List<String []> line){
		this.lines = line;
	}
	
	public List<String[]> getHorizontalData(){
		return this.lines;
	}
	
	
	
	 public String toString() {
	        return dataMap.toString();
	    }
	
}
