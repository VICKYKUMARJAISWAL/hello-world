package com.idategen.data.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.idatagen.query.SqlQueryBuilderFromFile;
import com.idatagen.util.CommonUtils;
import com.idatagen.util.QueryReferenceCheck;

public class SqlFileReader {

	public static boolean readSql(String fileName) {
		SqlQueryBuilderFromFile queryBuild = new SqlQueryBuilderFromFile();
		QueryReferenceCheck queryRefCheck = new QueryReferenceCheck();

		File schemaFile = new File(fileName);
		String sqlString = "";
		String sqlCreateQueries[] = null;
		String strCurrentLine;
		boolean isQueryExecuted = false;
		String[] insertQueriesCreated = null;
		String[] sqlConcatinatedQueries = null;

		if (schemaFile.exists()) {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(
						new FileInputStream(schemaFile)));

				while ((strCurrentLine = br.readLine()) != null) {
					sqlString = sqlString + strCurrentLine;
				}
				br.close();
				System.out.println("Input from File : " + sqlString);
			} catch (IOException e) {
				System.out.println("EXCEPTION: While reading the input file");
				e.printStackTrace();
			}

			sqlString = sqlString.replaceAll("`", "");

			sqlCreateQueries = sqlString.split(";");

			System.out.println("Queries to be executed : ");
			for (int i = 0; i < sqlCreateQueries.length; i++) {
				System.out.println(sqlCreateQueries[i]);
			}

			// Call Reference Check
			System.out.println("====================== REFERENCE CHECK STARTS ======================");
			if (sqlCreateQueries != null) {
				insertQueriesCreated = queryRefCheck.referenceChecker(sqlCreateQueries);
				System.out.println("====================== REFERENCE CHECK COMPLETED ======================");
				sqlConcatinatedQueries = CommonUtils.concatinateTwoStrArrays(sqlCreateQueries, insertQueriesCreated);
			}
			/*List<String> sqlQueriesList = new ArrayList<String>();
			sqlQueriesList.addAll(Arrays.asList(sqlCreateQueries));
			sqlQueriesList.addAll(Arrays.asList(insertQueriesCreated));
			sqlConcatinatedQueries = sqlQueriesList.toArray(new String[sqlQueriesList
					.size()]);*/

		} else {
			isQueryExecuted = false;
			System.out.println("EXCEPTION : The input file doesn't exist");
			return isQueryExecuted;
		}

		try {
			isQueryExecuted = queryBuild.batchInsert(sqlConcatinatedQueries);
		} catch (IOException e) {
			isQueryExecuted = false;
			System.out.println("EXCEPTION: While inserting the Queries.");
			e.printStackTrace();
		}
		return isQueryExecuted;
	}

	public static void main(String args[]) throws IOException {
		SqlFileReader reader = new SqlFileReader();
		boolean isQueryInserted = reader.readSql("D:/SqlFiles/schema.txt");

		if (isQueryInserted == true)
			System.out.println("Query Executed");
		else
			System.out.println("Query NOT Executed");

	}
}
