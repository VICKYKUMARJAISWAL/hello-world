package com.igate.dao.factory;

import com.igate.constants.DBType;

public class DDLCommandFactory {

	
	public static String getColumnInfoCommand(DBType dbtype){
		String command = "";
		switch(dbtype){
			case SQLLITE:				
				//command = "PRAGMA table_info(?)";
				command = "SELECT sql FROM sqlite_master WHERE tbl_name = ? AND type = 'table'";
				break;
			case SYBASE:
				command = "SELECT object_name(sc.id) AS tABLEnAME,sc.name,st.name,sc.length"
						+ " FROM syscolumns sc ,systypes st"
						+ " WHERE  object_name(sc.id) = ?  AND "
						+ "sc.type = st.type AND sc.usertype = st.usertype ";

				break;
		}
		return command;		
	}
}
