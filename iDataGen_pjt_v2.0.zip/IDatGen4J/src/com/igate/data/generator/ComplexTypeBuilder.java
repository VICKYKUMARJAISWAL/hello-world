package com.igate.data.generator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ComplexTypeBuilder {

	private List<DataGenerator> typeList;
	
	public ComplexTypeBuilder(){
		typeList = new ArrayList<>();
	}
	
	public void addItem(DataGenerator dg){
		this.typeList.add(dg);
	}
	public int getItemSize(){
		return this.typeList.size();
	}
	
	public String toString(){
		StringBuilder sb = new StringBuilder("");
		Iterator<DataGenerator> itr = typeList.iterator();
		while(itr.hasNext()){
			DataGenerator dg = itr.next();
			sb.append(dg.toString()).append("#");
		}
		return sb.toString();
	}
	
	public String[] buildData(int totalnum){
		String [] data = new String[totalnum];
		for(int i = 0 ; i < totalnum; i++){
			String dgdata = "";
			for(int j = 0; j < typeList.size(); j++){
				DataGenerator dg = typeList.get(j);
				dgdata += dg.generatedAndGet(1)[0]; 
			}
			data[i] = dgdata;		
		}
		return data;
	}
	

	public static void main(String args[]){
	
		List<ComplexTypeBuilder> clist = new ArrayList<>();
		ComplexTypeBuilder ctype = new ComplexTypeBuilder();
		DataGenerator dg1  = new CharacterGenerator(3);
		
		DataGenerator dg2  = new DigitGenerator(4);
		ctype.addItem(dg1);
		ctype.addItem(dg2);
		clist.add(ctype);
		ComplexTypeBuilder ctype1 = new ComplexTypeBuilder();
		ctype1.addItem(dg2);
		ctype1.addItem(dg1);
		clist.add(ctype1);
		
		
		
		
		String[] items = ctype.buildData(20);
		
		for(int i = 0; i < items.length; i++){
			System.out.println(items[i]);
		}		
	}
	
}
