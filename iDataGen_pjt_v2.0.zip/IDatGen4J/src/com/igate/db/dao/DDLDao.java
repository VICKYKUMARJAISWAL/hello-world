package com.igate.db.dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.fluttercode.datafactory.impl.DataFactory;

import com.igate.constants.DBType;
import com.igate.dao.factory.DDLCommandFactory;
import com.igate.db.manager.ConnectionManager;
import com.igate.dto.ColumnDetail;
import com.igate.dto.ConnectionDetail;

public class DDLDao implements GenericDao {

	private Connection connection;
	DataFactory dataFactory = new DataFactory();

	private static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final int RANDOM_STRING_LENGTH = 10;

	public DDLDao(Connection connection) {
		this.connection = connection;
	}

	/*
	 * public List<String> getAllUserTables() {
	 * 
	 * String sybasesql = "SELECT * FROM sysobjects WHERE type='U'";
	 * System.out.println("inside getAllUserTables"); Statement stmt = null;
	 * ResultSet rs = null; try { stmt = connection.createStatement(); rs =
	 * stmt.executeQuery(sybasesql); while (rs.next()) { String name =
	 * rs.getString(1); System.out.println("tname = " + name); }
	 * 
	 * } catch (SQLException sex) { sex.printStackTrace(); } finally { try { if
	 * (null != rs) { rs.close(); rs = null; } if (null != stmt) { stmt.close();
	 * stmt = null; } } catch (SQLException sx) {
	 * 
	 * }
	 * 
	 * } return null; }
	 */

	private List<ColumnDetail> parseAndGetList(String result) {
		List<ColumnDetail> lists = new ArrayList<>();
		// CREATE TABLE G111 (id INTEGER PRIMARY KEY AUTOINCREMENT, C1 CHAR
		// (10), C2 CHAR (11), C3 CHAR (11))
		if (null == result || result.isEmpty())
			return lists;
		String substr = result.substring(result.indexOf("(") + 1,
				result.lastIndexOf(")"));
		System.out.println("substr = " + substr);
		String[] columns = substr.split(",");
		for (int i = 0; i < columns.length; i++) {

			String name = columns[i].trim().split("\\s+")[0];
			String type = columns[i].trim().split("\\s+")[1];
			if ("pid".equalsIgnoreCase(name))
				continue;
			ColumnDetail cd = new ColumnDetail();
			cd.setColumnName(name);
			cd.setColumnType(type);
			lists.add(cd);
		}

		return lists;

	}

	@Override
	public List<ColumnDetail> getTableInfo(String tablename) {
		// TODO Auto-generated method stub
		List<ColumnDetail> lists = new ArrayList<>();
		String sql = DDLCommandFactory.getColumnInfoCommand(DBType.SQLLITE);
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			System.out.println("sql = " + sql);
			ps = connection.prepareStatement(sql);
			ps.setString(1, tablename);
			rs = ps.executeQuery();
			String result = "NA";
			while (rs.next()) {
				result = rs.getString(1);
				break;
			}
			if (!"NA".equalsIgnoreCase(result))
				lists = parseAndGetList(result);
		} catch (SQLException sex) {
			sex.printStackTrace();
		} finally {
			try {
				if (null != rs) {
					rs.close();
					rs = null;
				}
				if (null != ps) {
					ps.close();
					ps = null;
				}
			} catch (SQLException sx) {

			}

		}
		return lists;
	}

	// method to get the metaData for a given table
	public Map<String, String> getMetaData(String tableName) throws Exception {
		String sqlQuery = "select * from " + tableName;
		Map<String, String> metaDataMap = new LinkedHashMap<String, String>();
		Statement stmt = null;
		ResultSet rst = null;

		try {
			stmt = connection.createStatement();
			rst = stmt.executeQuery(sqlQuery);
			ResultSetMetaData metaData = rst.getMetaData();

			/*
			 * System.out.println("Table Name :" + metaData.getTableName(1));
			 * System.out.println("Number of Columns: " +
			 * metaData.getColumnCount());
			 * System.out.println("Column details:");
			 */

			for (int i = 1; i <= metaData.getColumnCount(); i++) {
				System.out.print(metaData.getColumnName(i) + "("
						+ metaData.getColumnTypeName(i) + ")   ");

				metaDataMap.put(metaData.getColumnName(i).trim(), metaData
						.getColumnTypeName(i).trim());

			}
			// System.out.println("\n");

		} finally {
			stmt.close();
			rst.close();
		}

		return metaDataMap;

	}

	public Map<String, String> getTableConstraints(String tableName) {
		DatabaseMetaData meta = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		Map<String, String> constraintsMap = new HashMap<String, String>();
		try {

			meta = connection.getMetaData();

			// To get primary key of table
			rs1 = meta.getPrimaryKeys(null, null, tableName);

			if (rs1.next()) {
				String columnName = rs1.getString(4);
				System.out
						.println("getPrimaryKeys(): columnName=" + columnName);
				constraintsMap.put(columnName, "PRIMARY KEY");
			}

			// To get Foreign keys
			rs2 = meta.getImportedKeys(null, null, tableName);
			while (rs2.next()) {
				String foreignKey = rs2.getString(4);
				System.out.println("Foreign Key :" + foreignKey);
				constraintsMap.put(foreignKey, "FOREIGN KEY");
			}

			// To get unique keys
			rs3 = meta.getIndexInfo(null, null, tableName, true, true);

			while (rs3.next()) {
				String indexName = rs3.getString("INDEX_NAME");
				String columnName = rs3.getString("COLUMN_NAME");
				if (indexName == null) {
					continue;
				}
				System.out.println("Unique Column " + columnName);
				constraintsMap.put(columnName, "UNIQUE KEY");
			}

			
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return constraintsMap;
	}

	/*
	 * To get all the tables from the database
	 */
	public List<String> getTables() {

		List<String> list = null;
		try {

			list = new ArrayList<String>();

			DatabaseMetaData md = connection.getMetaData();
			ResultSet rs = md.getTables(null, null, "%", null);

			while (rs.next()) {
				String table_name = rs.getString(3);
				System.out.println("Table Name : " + rs.getString(3));
				list.add(table_name);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return list;
	}

	/**
	 * @Description Checks the master data table for references of a particular
	 *              table
	 * @param tableName
	 * @return
	 */
	public Map<String, String> checkReferences(String tableName) {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "Select * FROM MasterReferencesTable WHERE Upper(TableName) is ? ";
		Map<String, String> referenceValues = new HashMap<String, String>();
		try {

			stmt = connection.prepareStatement(query);
			stmt.setString(1, tableName.toUpperCase());
			rs = stmt.executeQuery();

			while (rs.next()) {
				String refTable = rs.getString("ReferenceTable");
				String refColumnName = rs.getString("ReferenceColumn");
				String foreignKeyColumn = rs.getString("TableRefColumn");
				if (refTable != null && refColumnName != null
						&& foreignKeyColumn != null) {
					referenceValues.put(foreignKeyColumn, refTable + ","
							+ refColumnName);
				} else {
					referenceValues = null;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return referenceValues;
	}

	/**
	 * @Description Inserts the sql query into db
	 * @param sqlCmd
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	public boolean insertTables(String sqlCmd) throws SQLException, Exception {
		int updated = 0;

		try {
			updated = connection.createStatement().executeUpdate(sqlCmd);

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Sql cmd inserted " + sqlCmd + "  " + updated);
		if (updated != 0) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * @Description Check if a particular value exists in the respective table
	 * @param arr
	 * @return
	 * @throws SQLException
	 */
	public Boolean checkValueExists(ArrayList arr) throws SQLException {
		PreparedStatement stmt = null;
		String query = "Select * FROM " + arr.get(0) + " WHERE " + arr.get(1)
				+ "=?";
		ResultSet rs = null;
		int updated = 0;
		try {
			stmt = connection.prepareStatement(query);
			stmt.setString(1, arr.get(2).toString());
			rs = stmt.executeQuery();
			while (rs.next()) {
				updated = 1;
			}

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			rs.close();
			stmt.close();
		}

		if (updated != 0) {
			return true;
		} else {
			return false;
		}

	}

	// method to insert the random values and values from master look up table
	// given the table name
	public String buildRandomDataQuery(String tableName, String primaryKey)
			throws Exception {

		String sqlQuery = "select * from " + tableName;
		String primaryColumnName = null;
		String primaryColumnValue = null;
		StringBuilder sb1 = null;

		Statement stmt = null;
		ResultSet rst = null;

		if (primaryKey != null) {
			String[] primaryValues = primaryKey.split("=");
			primaryColumnName = primaryValues[0];
			primaryColumnValue = primaryValues[1];
		}
		try {
			stmt = connection.createStatement();
			rst = stmt.executeQuery(sqlQuery);
			ResultSetMetaData metaData = rst.getMetaData();

			String[] columnNamesType = new String[metaData.getColumnCount()];
			String[] columnNames = new String[metaData.getColumnCount()];

			for (int i = 1; i <= metaData.getColumnCount(); i++) {

				columnNamesType[i - 1] = metaData.getColumnTypeName(i);
				columnNames[i - 1] = metaData.getColumnName(i);

			}

			sb1 = new StringBuilder("INSERT INTO " + metaData.getTableName(1)
					+ "(");

			for (int j = 0; j < metaData.getColumnCount(); j++) {
				sb1.append(columnNames[j] + ",");
			}

			sb1.deleteCharAt(sb1.length() - 1);
			sb1.append(") VALUES(");

			for (int m = 0; m < 1; m++) {
				String columnType = "";
				String columnName = "";
				int temp = 0;
				for (int l = 0; l < metaData.getColumnCount(); l++) {
					Boolean lookUpExists = false;
					columnType = columnNamesType[l].trim();
					columnName = columnNames[l].trim();

					if (l != 0) {
						sb1.append(",");
					}

					if (primaryColumnName != null
							&& columnName.equalsIgnoreCase(primaryColumnName)) {
						sb1.append(primaryColumnValue);

					} else {
						if (columnType.equalsIgnoreCase("VARCHAR")) {
							if (columnName.contains("address")) {
								sb1.append("'" + dataFactory.getAddress() + "'");

							} else if (columnName.equalsIgnoreCase("firstName")) {
								sb1.append("'" + dataFactory.getFirstName()
										+ "'");
							} else if (columnName.equalsIgnoreCase("lastName")) {
								sb1.append("'" + dataFactory.getLastName()
										+ "'");
							} else if (columnName.equalsIgnoreCase("empName")) {
								sb1.append("'" + dataFactory.getName() + "'");
							} else {
								String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);

								if (lookUpValue != null) {
									sb1.append("'" + lookUpValue + "'");
								} else {
									sb1.append("'" + generateRandomString()
											+ "'");
								}

							}

						} else if (columnType.equalsIgnoreCase("INTEGER")) {

							String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);

							if (lookUpValue != null) {
								sb1.append(Integer.valueOf(lookUpValue));
							} else {
								sb1.append(getRandomNumber());
							}

						} else if (columnType.equalsIgnoreCase("CHAR")) {
							String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);

							if (lookUpValue != null) {
								sb1.append("'" + lookUpValue + "'");
							} else {
								sb1.append("'" + generateRandomString() + "'");
							}
						} else if (columnType.equalsIgnoreCase("BIGINT")) {

							String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);
							if (lookUpValue != null) {
								sb1.append(Integer.valueOf(lookUpValue));
							} else {
								sb1.append(getInteger());
							}

						} else if (columnType.equalsIgnoreCase("DATE")
								|| columnType.contains("Date")) {
							String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);

							if (lookUpValue != null) {
								sb1.append("'" + lookUpValue + "'");
							} else {
								sb1.append("'" + getDate() + "'");
							}
						} else if (columnType.equalsIgnoreCase("DATETIME")) {
							sb1.append("'" + System.currentTimeMillis() + "'");
						}
					}

				}
				sb1.append(")");
				System.out.println(sb1);

			}

		} finally {
			stmt.close();
			rst.close();
		}

		return sb1.toString();

	}

	// method to pick up the random value from the master look up table given
	// the column name of look up table
	public String generateRandomDataFromMasterLookUpTable(String columnName)
			throws Exception {
		Random randomNamesGenerator = new Random();
		ArrayList<Object> nameList = new ArrayList<Object>();
		String randomValue = null;

		Map<String, ArrayList<Object>> map = getMasterTable("MasterDataGenLookUpTable");
		Set<String> masterColumns = map.keySet();

		for (String column : masterColumns) {
			if (columnName.equalsIgnoreCase(column)) {

				if (map.containsKey(column)) {
					nameList.addAll(map.get(column));
				}

				int nameListSize = nameList.size();
				int index = randomNamesGenerator.nextInt(nameListSize);
				randomValue = nameList.get(index).toString();
				break;
			}
		}

		return randomValue;
	}

	// method to generate random Number
	public static int getRandomNumber() {
		int randomInt = 0;
		Random randomGenerator = new Random();
		randomInt = randomGenerator.nextInt(CHAR_LIST.length());

		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}
	}

	// method to generate random integer
	public int getInteger() {
		int randomInt = 0;
		randomInt = dataFactory.getNumberBetween(-2 ^ 31, 2 ^ 31 - 1);
		return randomInt;
	}

	// method to generate random String
	public String generateRandomString() {

		StringBuffer randStr = new StringBuffer();
		for (int i = 0; i < RANDOM_STRING_LENGTH; i++) {
			int number = getRandomNumber();
			char ch = CHAR_LIST.charAt(number);
			randStr.append(ch);
		}
		return randStr.toString();
	}

	public Date getDate() {
		Date date = new Date();
		Date minDate = dataFactory.getDate(2000, 1, 1);
		Date maxDate = new Date();
		for (int i = 0; i < 10; i++) {
			date = dataFactory.getDateBetween(minDate, maxDate);
			System.out.println("Date = " + date);
		}

		return date;
	}

	public String getAddress() {
		String address = dataFactory.getAddress();
		return address;
	}

	// method to add the given column from master lookup table to a map given
	// master table name
	public Map<String, ArrayList<Object>> getMasterTable(String masterTableName)
			throws Exception {
		String fetchMasterTable = "select * from " + masterTableName;
		Map<String, ArrayList<Object>> masterTableMap = new HashMap<String, ArrayList<Object>>();

		try {
			Statement stmt = connection.createStatement();
			ResultSet rst = stmt.executeQuery(fetchMasterTable);
			ResultSetMetaData metaData = rst.getMetaData();

			String[] masterColumnNames = new String[metaData.getColumnCount()];

			for (int m = 1; m <= metaData.getColumnCount(); m++) {
				masterColumnNames[m - 1] = metaData.getColumnName(m);
			}

			for (int n = 0; n < metaData.getColumnCount(); n++) {
				ArrayList<Object> namesList = new ArrayList<Object>();

				String fetchNamesQuery = "select " + masterColumnNames[n]
						+ " from " + masterTableName;
				stmt = connection.createStatement();
				rst = stmt.executeQuery(fetchNamesQuery);

				while (rst.next()) {
					if (rst.getString(1) != null) {
						namesList.add(rst.getString(1));
					}

				}
				System.out.println(namesList);
				masterTableMap.put(masterColumnNames[n], namesList);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return masterTableMap;

	}

	public static void main(String args[]) {

		ConnectionDetail cd = new ConnectionDetail("BLRWFD6681.igatecorp.com",
				"5000", "GS_MGMT1", "dev2", "dev234");
		ConnectionManager cm = new ConnectionManager();
		Connection conn = cm.getConnection(cd);

		DDLDao dd = new DDLDao(conn);
		/* dd.getAllUserTables(); */
		cm.closeConnection(conn);
		// List<ColumnDetail> l =
		// d.parseAndGetList("CREATE TABLE G111 (id INTEGER PRIMARY KEY AUTOINCREMENT, C1 CHAR (10), C2 CHAR (11), C3 CHAR (11))");
		// for (ColumnDetail tablecolumnDetail : l) {
		//
		// System.out.println(tablecolumnDetail.getColumnName()+" "+tablecolumnDetail.getColumnType());
		// }
	}

}
