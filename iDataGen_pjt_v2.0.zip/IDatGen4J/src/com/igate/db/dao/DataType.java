package com.igate.db.dao;

public interface DataType {

	String INTEGER = "INTEGER";
	String BIGINT = "BIGINT";
	String VARCHAR = "VARCHAR";
	String DATE = "DATE";
	String DATETIME = "DATETIME";
	
}
