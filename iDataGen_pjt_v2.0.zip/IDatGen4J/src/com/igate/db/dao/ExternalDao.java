package com.igate.db.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.idategen.data.reader.DataResultSet;
import com.igate.constants.DBType;
import com.igate.dao.factory.DDLCommandFactory;
import com.igate.dto.ColumnDetail;

public class ExternalDao {

	private Connection connection;
	private DBType dbType;
	public ExternalDao(Connection connection){
		this.connection = connection;
		// we will get the dbtype fronn config
		//this.dbType = DBType.SYBASE;
		this.dbType = dbType.SQLLITE;
	}
	
	private String prepareLine(ResultSet rs,List<ColumnDetail> columnlists){
		StringBuilder line = new StringBuilder();
		
		for(int i = 0; i < columnlists.size(); i++){
			
			ColumnDetail cd = columnlists.get(i);
			try {
				Object val = rs.getObject(cd.getColumnName());
				line.append(val.toString());
				line.append(",");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "NA";
			} 
			
		}
		line.deleteCharAt(line.lastIndexOf(","));
		
		return line.toString();
	}
	
	
	private List<ColumnDetail> getColumnList(ResultSet rs){
		List<ColumnDetail> list = new ArrayList<>();
		try{
			ResultSetMetaData rsmd = rs.getMetaData();
			int coulmncount = rsmd.getColumnCount();
			for(int i = 0; i < coulmncount; i++){
				ColumnDetail cd = new ColumnDetail();
				cd.setColumnName(rsmd.getColumnName(i+1));
				cd.setColumnType(rsmd.getColumnTypeName(i+1));
				System.out.println("column At"+i+" = "+cd.getColumnName());
				list.add(cd);
			}
			return list;
		}catch(SQLException sex){
			return null;
		}
		
	}
	
	
	public DataResultSet executeCommandAndgetDataResultSet(String command) {
		// TODO Auto-generated method stub
		DataResultSet ds = new DataResultSet();
		List<String[]> lines = new ArrayList<>();
		String sql = command;
		Statement ps = null;
		ResultSet rs = null;
		try{
			System.out.println("sql = "+sql);
			ps = connection.createStatement();
			
			rs = ps.executeQuery(sql);
			String result = "NA";
			
			List<ColumnDetail> columnlists = getColumnList(rs); 
			if(null == columnlists || columnlists.isEmpty())return null;
			ds.setSourceColumnList(columnlists);
			
				while(rs.next()){
					String line = prepareLine(rs,columnlists);
					lines.add(line.split(","));
				//	break;
				}
				ds.setHorizontalData(lines);
			//	if(!"NA".equals(result))
			//	lists = parseAndGetList(result);
		}catch(SQLException sex){
			sex.printStackTrace();
		}finally{
			try{
				if(null != rs){
					rs.close();
					rs = null;
				}
				if(null != ps){
					ps.close();
					ps = null;
				}
			}catch(SQLException sx){
				
			}
			
		}
		return ds;
	}
	
	
	private List<ColumnDetail> parseAndGetList(String result){
		List<ColumnDetail> lists = new ArrayList<>();	
		//CREATE TABLE G111 (id INTEGER PRIMARY KEY AUTOINCREMENT, C1 CHAR (10), C2 CHAR (11), C3 CHAR (11))
		if(null == result || result.isEmpty())
			return lists;
		String substr = result.substring(result.indexOf("(")+1,result.lastIndexOf(")"));
		System.out.println("substr = "+substr);
		String [] columns = substr.split(",");
		for(int i = 0; i < columns.length;i++){
			
			String name = columns[i].trim().split("\\s+")[0];
			String type = columns[i].trim().split("\\s+")[1];
			if("pid".equalsIgnoreCase(name))continue;
			ColumnDetail cd = new ColumnDetail();
			cd.setColumnName(name);
			cd.setColumnType(type);
			lists.add(cd);
		}
		
		return lists;
		
		
	}
	
	
	/*public List<ColumnDetail> getTableInfo(String tablename) {
		// TODO Auto-generated method stub
		List<ColumnDetail> lists = new ArrayList<>();		
		//String sql = DDLCommandFactory.getColumnInfoCommand(DBType.SYBASE);
		String sql = DDLCommandFactory.getColumnInfoCommand(DBType.SQLLITE);
		PreparedStatement ps = null;
		ResultSet rs = null;
		try{
			System.out.println("sql = "+sql);
			ps = connection.prepareStatement(sql);
			ps.setString(1, tablename);
			rs = ps.executeQuery();
			String result = "NA";
			if(this.dbType == dbType.SYBASE){
				while(rs.next()){
					String tname = rs.getString(2);
					String type = rs.getString(3);
					ColumnDetail cd = new ColumnDetail();
					cd.setColumnName(tname);
					cd.setColumnType(type);
					lists.add(cd);
					System.out.println("name = "+tname+" type = "+type);
					//break;
				}
			}else{
				while(rs.next()){
					result = rs.getString(1);
					break;
				}
				if(!"NA".equals(result))
					lists = parseAndGetList(result);
			}
			
		}catch(SQLException sex){
			sex.printStackTrace();
		}finally{
			try{
				if(null != rs){
					rs.close();
					rs = null;
				}
				if(null != ps){
					ps.close();
					ps = null;
				}
			}catch(SQLException sx){
				
			}
			
		}
		return lists;
	}*/
}
