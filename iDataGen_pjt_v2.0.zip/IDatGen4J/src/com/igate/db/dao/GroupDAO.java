package com.igate.db.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.idatagen.query.SqliteQueryBuider;
import com.idatagen.util.Utility;
import com.idategen.data.reader.DataResultSet;
import com.igate.constants.DBType;
import com.igate.constants.GroupType;
import com.igate.datagen.exceptions.AlterColumnException;
import com.igate.dto.ColumnDetail;
import com.igate.dto.GroupRecord;

public class GroupDAO {

	private Connection connection;
	private DBType dbType;
	public GroupDAO(Connection connection){
		this.connection = connection;
		// we will get the dbtype fronn config
		this.dbType = DBType.SQLLITE;
	}
	
	//public getAllParentGroups(){
		
//	}
	
	
	public List<List<String>> getDataList(List<ColumnDetail> columns, List Params, String tablename){
		List<List<String>> records = new ArrayList<>();
		SqliteQueryBuider qb = new SqliteQueryBuider();
		String sql = qb.buildSelectQuery(columns, Params, tablename);
		System.out.println("getDataList:: sql = "+sql);
		Statement stmt = null;
		ResultSet rs = null;
		try{
			stmt = connection.createStatement();			
			rs = stmt.executeQuery(sql);
			while(rs.next()){
				List<String> rowdata = new ArrayList<>();
				for(int i = 0; i < columns.size(); i++){
					String cdata = rs.getString(i+1);
					rowdata.add(cdata);
				}
				records.add(rowdata);
			}
		}catch(SQLException sex){
			sex.printStackTrace();
		}finally{
			try{
				if(null != rs){
					rs.close();
					rs = null;
				}
				if(null != stmt){
					stmt.close();
					stmt = null;
				}
			}catch(SQLException sx){
				
			}
			
		}
		
		return records;
		
	}
			
	
	
	public GroupRecord addGroup(GroupRecord group){
		String sql = "insert into group_master (name,parent_id,grouptype) values(?,?,?)";
		 
		PreparedStatement ps = null;
		ResultSet rs = null;		
		try{
			//connection.setAutoCommit(false);
		
			ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1,group.getName());
			ps.setInt(2, group.getParentId());
			ps.setInt(3, group.getType().getValue());
			ps.executeUpdate();
			
			rs = ps.getGeneratedKeys();
			int groupid = -1;
			while(rs.next()){
				groupid = rs.getInt(1);
				break;
			}
			if(groupid == -1)
			{
				// do a select to get the groupid
			}else{
				
			}
			group.setId(groupid);
		}catch(SQLException sex){
			sex.printStackTrace();
			return null;
		}finally{
			try{
				if(null != rs){
					rs.close();
					rs = null;
				}
				if(null != ps){
					ps.close();
					ps = null;
				}
			}catch(SQLException sx){
				
			}			
		}
		return group;
	}	
	
	private boolean createTable(String tablename) throws SQLException{
		/*
		 * CREATE TABLE tbl1 (
    pid       INTEGER       PRIMARY KEY AUTOINCREMENT,
    dt        DATETIME      DEFAULT CURRENT_TIMESTAMP,
    createdby VARCHAR (127) 
);
		 * 
		 */
		
		String ddl = "CREATE TABLE "+tablename+" (pid INTEGER   PRIMARY KEY AUTOINCREMENT)";
		System.out.println("DDL = "+ddl);
		PreparedStatement ps = null;
		
			ps = connection.prepareStatement(ddl);
			//ps.setString(1, tablename);
			ps.executeUpdate();
			if(ps != null){
				ps.close();ps = null;
			}
		
		return true;
	}
	
private boolean alterTable(List<ColumnDetail> filecolumnlist, String tablename) throws SQLException{
		
	SqliteQueryBuider qb = new SqliteQueryBuider();
	String [] ddl = qb.buildAddColumnQuery(filecolumnlist, tablename);
	if(ddl.length <= 0){
		System.out.println("alterTable:: Not require to alter table");
		return true;
	}
				
	//System.out.println("DDL = "+ddl);
	Statement stmt = connection.createStatement();
	for(int i = 0; i < ddl.length; i++){
		if(ddl[i] == null || ddl[i].isEmpty()){
			System.out.println("Not executing ... ");
			continue;
		}
			
		System.out.println("executing "+ddl[i]);
		stmt.execute(ddl[i]);
	}
		
	if(null != stmt){
		stmt.close();
		stmt = null;
	}
	/*PreparedStatement ps = null;
	
		ps = connection.prepareStatement(ddl);
		//ps.setString(1, tablename);
		ps.executeUpdate();
		if(ps != null){
			ps.close();ps = null;
		}*/
	return true;
	}
	
	public GroupRecord addAssetClass(GroupRecord assetclass){
		
		/**
		 * 0) create the table by giving 1 primary key autogenerate columns
		 * 1) Add an entry to gropu master 
		 * 2) returns the grouprecord object to make this sync with front end cache
		 * 3) 
		 */
		GroupRecord group = null;
		try{
			connection.setAutoCommit(false);
			boolean isCreated = createTable(assetclass.getName());
			group = addGroup(assetclass);		
			connection.commit();
		}catch(SQLException sex){
			sex.printStackTrace();
			try{
				connection.rollback();
			}catch(SQLException ex){
				ex.printStackTrace();
			}
		}
		
		
		return group;
				
	}
	
	public  boolean isvalidata(String data, String type){
		
		switch(type){
			case DataType.BIGINT:
				return Utility.isValidBigInt(data);
			case DataType.INTEGER:
				return Utility.isValidInt(data);
			case DataType.DATE:
				return Utility.isValidDate((data));
			case DataType.DATETIME:
				return Utility.isValidDateTime((data));
			default:
				return true;				
				
		}
	}
	
	private boolean isDataToTypeAreSatisfy(String [] rowdata, List<ColumnDetail> filecolumnlist){
		
		if(rowdata.length != filecolumnlist.size())
			return false;
		for(int i = 0; i < filecolumnlist.size(); i++){
			ColumnDetail cd = filecolumnlist.get(i);
			if(!isvalidata(rowdata[i],cd.getColumnType())){
				System.out.println("isDataToTypeAreSatisfy:: fails "+rowdata[i]+" and "+cd.getColumnType() );
				return false;
			}
		}
		return true;
	}
	
	public List<Integer> uploadRecords(List<ColumnDetail> filecolumnlist,DataResultSet filedata,String tablename) throws AlterColumnException{
		/**
		 * 1) alter the table with new columns
		 * 2) Try to upload the data
		 * 
		 */
		SqliteQueryBuider qb = new SqliteQueryBuider();
		PreparedStatement  ps = null;
		try {
			connection.setAutoCommit(false);
			boolean isaltered = alterTable(filecolumnlist, tablename);
			if(!isaltered){
				connection.rollback();
				throw new AlterColumnException("Unable to add columns");
			}
			connection.commit();
			connection.setAutoCommit(false);
			String sql[] = qb.getInsertBatchQuery(filecolumnlist, filedata, tablename);
			ps = connection.prepareStatement(sql[0]);
			
			List<String[]> lines = filedata.getHorizontalData();
			for(int i = 0; i < lines.size(); i++ ){
				String [] datas = lines.get(i);
				if(!isDataToTypeAreSatisfy(datas,filecolumnlist))
					continue;
				for(int j = 0; j < filecolumnlist.size(); j++){					
					ps.setString(j+1, datas[j]);
				}				
				ps.addBatch();
			}
			
			ps.executeBatch();
			connection.commit();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try{
				connection.rollback();
			}catch(Exception ex){
				ex.printStackTrace();
			}
			e.printStackTrace();
		}
		
		
		return new ArrayList<Integer>();
	}
	
	
	public List<GroupRecord> getAllSubCategoryById(int gid){
		
		List<GroupRecord> lists = new ArrayList<>();		
		String sql = "select * from Group_Master where parent_id= ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try{
			ps = connection.prepareStatement(sql);
			ps.setInt(1, gid);
			rs = ps.executeQuery();
			while(rs.next()){
				GroupRecord gr = new GroupRecord(GroupType.GROUP);
				gr.setId(rs.getInt(1));
				gr.setName(rs.getString(2));
				gr.setParentId(rs.getInt(3));
				lists.add(gr);
			}
		}catch(SQLException sex){
			sex.printStackTrace();
		}finally{
			try{
				if(null != rs){
					rs.close();
					rs = null;
				}
				if(null != ps){
					ps.close();
					ps = null;
				}
			}catch(SQLException sx){
				
			}
			
		}
		
		return lists;
		
	}
	
	
public List<GroupRecord> getAllGroupRecords(){
		
		List<GroupRecord> lists = new ArrayList<>();		
		String sql = "select * from Group_Master";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try{
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				Integer gtype = rs.getInt(4);
				if(gtype == null) gtype = 1;
				GroupRecord gr = new GroupRecord(GroupType.getType(gtype));
				gr.setId(rs.getInt(1));
				gr.setName(rs.getString(2));
				gr.setParentId(rs.getInt(3));
				lists.add(gr);
			}
		}catch(SQLException sex){
			sex.printStackTrace();
		}finally{
			try{
				if(null != rs){
					rs.close();
					rs = null;
				}
				if(null != ps){
					ps.close();
					ps = null;
				}
			}catch(SQLException sx){
				
			}
			
		}
		
		return lists;
		
	}

}
