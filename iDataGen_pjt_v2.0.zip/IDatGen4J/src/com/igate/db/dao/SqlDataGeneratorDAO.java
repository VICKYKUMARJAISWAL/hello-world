package com.igate.db.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.igate.db.manager.ConnectionManager;

public class SqlDataGeneratorDAO {
	ConnectionManager conMgr = new ConnectionManager();
	String[] queries;
	Connection con;
	Statement stmt;

	public boolean executeBatchSqlFile(String[] strQueries) {
		boolean isQueryExecuted = false;
		this.queries = strQueries;

		try {
			con = conMgr.getConnection();
			stmt = con.createStatement();
			for (String query : queries) {

				stmt.addBatch(query);
				stmt.executeBatch();
				isQueryExecuted = true;

				System.out.println("Query executed : " + query);

			}
		} catch (SQLException e) {
			try {
				isQueryExecuted = false;
				con.rollback();
			} catch (SQLException e1) {
				isQueryExecuted = false;
				System.out.println("EXCEPTION : While rollingback the batch");
				e1.printStackTrace();
			}
			System.out.println("EXCEPTION : While Executing batch ");
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				System.out.println("EXCEPTION : While closing the connection");
				e.printStackTrace();
			}

		}
		return isQueryExecuted;

	}
}
