package com.igate.db.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.idatagen.util.CommonUtils;
import com.idatagen.util.QueryReferenceCheck;
import com.igate.db.manager.ConnectionManager;

public class SqlDynamicGeneratorDAO {

	ConnectionManager conMgr = new ConnectionManager();
	String[] queries;
	Connection con;
	Statement stmt;
	boolean isQueryExecuted = false;
	QueryReferenceCheck queryRefCheck = new QueryReferenceCheck();
	SqlDataGeneratorDAO queryDao = new SqlDataGeneratorDAO();
	
	public boolean createSqlQuery(String entity, String[] fieldNames,
			String[] dataTypes, String[] constraints) {

		StringBuffer queryString = new StringBuffer("CREATE TABLE " + entity
				+ " (");
		for (int i = 0; i < fieldNames.length; i++) {

			if (i < fieldNames.length - 1)
				queryString.append(fieldNames[i] + " ").append(dataTypes[i] + " ").append(constraints[i] + ", ");
			else
				queryString.append(fieldNames[i] + " ").append(dataTypes[i] + " ").append(constraints[i] + " ");
		}

		queryString.append(" )");
		System.out.println("QUERY CREATED: " + queryString);
		String strQuery = queryString.toString();
		String[] sqlCreateQueries = strQuery.split(";");
		String[] insertQueriesCreated = null;
		String[] sqlConcatinatedQueries = null;
		
		System.out.println("====================== REFERENCE CHECK STARTS ======================");
		if (sqlCreateQueries != null) {
			insertQueriesCreated = queryRefCheck.referenceChecker(sqlCreateQueries);
			System.out.println("====================== REFERENCE CHECK COMPLETED ======================");
			sqlConcatinatedQueries = CommonUtils.concatinateTwoStrArrays(sqlCreateQueries, insertQueriesCreated);
		}
		
		
		
		//isQueryExecuted = insertData(strQuery);
		
		isQueryExecuted= queryDao.executeBatchSqlFile(sqlConcatinatedQueries);
		return isQueryExecuted;

	}

	public boolean insertData(String createTableQuery) {

		try {
			con = conMgr.getConnection();
			stmt = con.createStatement();

			stmt.execute(createTableQuery);
			isQueryExecuted = true;
			System.out.println("Table Created : " + isQueryExecuted);

		} catch (SQLException e) {
			try {
				isQueryExecuted = false;
				con.rollback();
			} catch (SQLException e1) {
				isQueryExecuted = false;
				System.out.println("EXCEPTION : While rolling back");
				System.out.println("QUERY : " + createTableQuery);
				e1.printStackTrace();
			}
			e.printStackTrace();

		} finally {
			try {
				stmt.close();
				con.close();
				System.out.println("Connection Closed : " + con.isClosed()
						+ ",  " + con.toString());
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("EXCEPTION : While closing the connection");
			}

		}
		return isQueryExecuted;

	}

}
