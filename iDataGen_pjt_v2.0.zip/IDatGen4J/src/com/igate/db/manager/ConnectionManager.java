package com.igate.db.manager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.igate.dto.ConnectionDetail;

public class ConnectionManager {

	
public Connection getConnection(){
		
		Connection conn = null;
		try {
			//Class.forName("com.sybase.jdbc3.jdbc.SybDriver");
			String sqlitedriver = "org.sqlite.JDBC";
			Class.forName(sqlitedriver);
			
			//
			String sybaseurl = "jdbc:sybase:Tds:BLRWFD6681.igatecorp.com:5000/GS_MGMT1";
			String sqliteurl ="jdbc:sqlite:D:/idatagen/createSchemadb.db"; 
			
			
			//conn = DriverManager.getConnection(sybaseurl,"dev2","dev234");
			conn = DriverManager.getConnection(sqliteurl);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(SQLException sex){
			sex.printStackTrace();
		}
		
		return conn;
	}

public Connection getConnection(ConnectionDetail connnectioninfo){
	
	/*Connection conn = null;
	try {
		//Class.forName("com.sybase.jdbc3.jdbc.SybDriver");
		//String sqlitedriver = "org.sqlite.JDBC";
		String sybasedriver = "com.sybase.jdbc3.jdbc.SybDriver";
//							  "com.sybase.jdbc3.jdbc.SybDriver";
		Class.forName(sybasedriver);
		
		//
		//String sybaseurl = "jdbc:sybase:Tds:BLRWFD6681.igatecorp.com:5000";
	//	String sybaseurl = "jdbc:sybase:Tds:BLRWFD6681:5000?ServiceName=GS_MGMT1";
//						   "jdbc:sybase:Tds:BLRWFD6681.igatecorp.com:5000"
	//	String sybaseurl	= "jdbc:sybase:Tds:BLRWFD6681.igatecorp.com:5000/GS_MGMT1";
		//String sybaseurl    = "jdbc:sybase:Tds:BLRWFD6681.igatecorp.com:5000/GS_MGMT";
		//String sybaseurl = "jdbc:sybase:Tds:BLRWFD6681.igatecorp.com:5000/master";
		String sybaseurl = "jdbc:sybase:Tds:"+connnectioninfo.getHostName()+":"+
							connnectioninfo.getPort()+"?ServiceName="+connnectioninfo.getDbName();
		System.out.println("sybaseurl = "+sybaseurl);
		//String sqliteurl ="jdbc:sqlite:D:/rashmi/db/mydb.db"; 
		//conn = DriverManager.getConnection(sybaseurl,"dev2","dev234");
		//conn = DriverManager.getConnection(sybaseurl,"dev1","dev123");
    	conn = DriverManager.getConnection(sybaseurl,connnectioninfo.getUserName(),connnectioninfo.getPassword());
		//conn = DriverManager.getConnection(sqliteurl);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch(SQLException sex){
		sex.printStackTrace();
	}
	
	return conn;*/
	
	Connection conn = null;
	try {
		//Class.forName("com.sybase.jdbc3.jdbc.SybDriver");
		String sqlitedriver = "org.sqlite.JDBC";
		Class.forName(sqlitedriver);
		
		//
		String sybaseurl = "jdbc:sybase:Tds:BLRWFD6681.igatecorp.com:5000/GS_MGMT1";
		String sqliteurl ="jdbc:sqlite:D:/idatagen/createSchemadb.db"; 
		//conn = DriverManager.getConnection(sybaseurl,"dev2","dev234");
		conn = DriverManager.getConnection(sqliteurl);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch(SQLException sex){
		sex.printStackTrace();
	}
	
	return conn;
	
}

public void closeConnection(Connection connnecton){
	if( null != connnecton){
		try {
			connnecton.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		connnecton = null;
	}
}




}
