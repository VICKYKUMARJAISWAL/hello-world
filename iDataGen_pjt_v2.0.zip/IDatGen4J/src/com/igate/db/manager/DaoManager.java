package com.igate.db.manager;

import java.sql.Connection;
import java.sql.SQLException;

import com.igate.db.command.DaoCommand;
import com.igate.db.dao.DDLDao;
import com.igate.db.dao.ExternalDao;
import com.igate.db.dao.GroupDAO;

public class DaoManager {

	protected Connection connection = null;
	protected Connection externalconnection = null;
	  protected GroupDAO  groupDao  = null;
	  protected ExternalDao  externalDao  = null;
	  protected DDLDao ddldao = null;

	  public DaoManager(Connection connection){
	    this.connection = connection;
	  }
	  public DaoManager(Connection srcconnection, Connection externconnn){
		    this.connection = srcconnection;
		    this.externalconnection = externconnn;
		  }

	  public void setExternalConnection(Connection conn){
		  this.externalconnection = conn;
	  }
	  
	  public GroupDAO getGroupDAO(){
	    if(this.groupDao == null){
	      this.groupDao = new GroupDAO(this.connection);
	    }
	    return this.groupDao;
	  }
	  
	  public ExternalDao  getExternalDAO(){
		    if(this.externalDao == null){
		      this.externalDao = new ExternalDao(this.externalconnection);
		    }
		    return this.externalDao;		    		
		  }


	  public DDLDao getDDLDAO(){
		    if(this.ddldao == null){
		      this.ddldao = new DDLDao(this.connection);
		    }
		    return this.ddldao;
		  }
	  
	  public Object executeAndClose(DaoCommand command) {
		    try{
		      return command.execute(this);
		    } finally {
		    	try{
		    		if(null != connection){
		    			this.connection.close();
		    			this.connection = null;
		    		}
		    		
		    	}catch(SQLException sex){
		    		
		    	}
		    }
		  }
	  
	  public Object executeAndCloseExternalCommand(DaoCommand command) {
		    try{
		      return command.execute(this);
		    } finally {
		    	try{
		    		
		    		if(null != externalconnection){
		    			this.externalconnection.close();
		    			this.externalconnection = null;
		    		}
		    	}catch(SQLException sex){
		    		
		    	}
		    }
		  }

	  
}
