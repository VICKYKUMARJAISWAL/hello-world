package com.igate.mapper;

import java.util.ArrayList;
import java.util.List;

import com.idategen.data.reader.DataResultSet;
import com.igate.dto.ColumnDetail;

public class CompareResultDetail {

	private List<ColumnDetail> destinationColumns;
	private List<ColumnDetail> sourceColumns;
	DataResultSet sourceDataResult;
	public List<ColumnDetail> getDestinationColumns() {
		return destinationColumns;
	}
	public void setDestinationColumns(List<ColumnDetail> dbColumns) {
		this.destinationColumns = dbColumns;
	}
	private boolean ispresentInDb(ColumnDetail cd){
		return destinationColumns.contains(cd);		
	}
	public List<ColumnDetail> getSourceColumns() {
		sourceColumns =  sourceDataResult.getSourceColumnList();
		for(int i = 0; i < sourceColumns.size(); i++){
			//ColumnDetail cd = fileColumns.get(i);
			if(ispresentInDb(sourceColumns.get(i))){
				sourceColumns.get(i).setAsDbColumn(true);				
			}
		}
		return sourceColumns;
	}
//	public void setSourceColumns(List<ColumnDetail> fileColumns) {
	//	this.sourceColumns = fileColumns;
	//}
	public DataResultSet getSourceDataResult() {
		return sourceDataResult;
	}
	public void setSourceDataResult(DataResultSet fileDataResult) {
		this.sourceDataResult = fileDataResult;
	}
	
	
	
}
