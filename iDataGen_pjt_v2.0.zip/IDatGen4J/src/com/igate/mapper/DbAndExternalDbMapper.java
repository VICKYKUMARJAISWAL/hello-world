package com.igate.mapper;

import java.util.List;

import com.idategen.data.reader.CSVFileReader;
import com.idategen.data.reader.DataResultSet;
import com.idategen.data.reader.FileReaderManager;
import com.igate.datagen.exceptions.InvalidFileFormatException;
import com.igate.dto.ColumnDetail;
import com.igate.service.ServiceManager;

public class DbAndExternalDbMapper extends SourceDestinationMapper{


private CompareResultDetail compareResultDetail;
ServiceManager sm;
//String externalTableName;
String destTableName;
//List<ColumnDetail> sourceColumnlist;
String sqlCommand;

public DbAndExternalDbMapper(String destinationtablename,ServiceManager sm, String sqlCommand){
	this.sm = sm;
//	externalTableName = externaltablename;
	//this.sourceColumnlist = columnlist;
	this.sqlCommand = sqlCommand;
	this.destTableName = destinationtablename;
}

public CompareResultDetail doProcess(){
		
		// Calculate the culumn detail
		compareResultDetail = new CompareResultDetail();
		compareResultDetail.setDestinationColumns(sm.getAllColumns(destTableName));
		//if(null == sourceColumnlist || sourceColumnlist.isEmpty())
		//	sourceColumnlist = sm.getAllColumnsFromExternalDB(externalTableName);
		// read the file and get the data
		FileReaderManager frm = null;
		//try {
			//frm = new CSVFileReader(fileInputType.getFile(), fileInputType.getFileType(), fileInputType.getDelimeter());
		DataResultSet ds = sm.executeCommandAndgetDataResultSet(sqlCommand);
		//ds.setSourceColumnList(sourceColumnlist);
		compareResultDetail.setSourceDataResult(ds); 
						
		//} catch (InvalidFileFormatException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		//	return null;
		//}
		
		return compareResultDetail;
	}
}
