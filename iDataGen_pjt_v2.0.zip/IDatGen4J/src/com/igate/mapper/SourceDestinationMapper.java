package com.igate.mapper;

public abstract class SourceDestinationMapper {

	public abstract CompareResultDetail doProcess();
}
