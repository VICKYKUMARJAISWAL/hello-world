--<ScriptOptions statementTerminator=";"/>

USE idatagendb;

SETUSER 'dev2';

CREATE TABLE testing (
		id INT  NOT NULL,
		name VARCHAR(10)  NOT NULL,
		salary INT  NULL
	)
LOCK allpages 
WITH max_rows_per_page=0, exp_row_size=0, reservepagegap=0, identity_gap=0 
ON 'default';

SETUSER;

