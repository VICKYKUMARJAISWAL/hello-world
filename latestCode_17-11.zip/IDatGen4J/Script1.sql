--<ScriptOptions statementTerminator=";"/>

USE idatagendb;

SETUSER 'dev2';

CREATE TABLE MasterDataGenLookUpTable (
		deptName VARCHAR(1)  NOT NULL
	)
LOCK allpages 
WITH max_rows_per_page=0, exp_row_size=0, reservepagegap=0, identity_gap=0 
ON 'default';

EXEC sp_cachestrategy 'idatagendb','dev2.MasterDataGenLookUpTable','table only',MRU,'ON';

EXEC sp_cachestrategy 'idatagendb','dev2.MasterDataGenLookUpTable','table only',PREFETCH,'ON';

SETUSER;

