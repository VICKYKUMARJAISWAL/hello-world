package com.idatagen.file;

import java.io.File;

import com.idategen.data.reader.DataResultSet;
import com.igate.constants.FileType;
import com.igate.datagen.exceptions.InvalidFileFormatException;

public abstract class FileResourceManager {

	private String filePath;
	private FileType fileType;
	private String delimeter;
	private String repositoryPath;
	
	private String fileName;
	private String absPath;
	private String lineSeparator;
	
	public FileResourceManager(String filepath, FileType filetype, String delm) throws InvalidFileFormatException{
		this.filePath = filepath;
		this.fileType = filetype;
		this.delimeter = delm;
		// To do read from the config file
		this.repositoryPath = "d:\\repository";
		doInit();
	}
	
	public String getLineSeparator(){
		return this.lineSeparator;
	}
	private boolean isWindow(){
		String osname = System.getProperty("os.name");
		if( null == osname || osname.isEmpty() || osname.startsWith("Windows")){
			return true;
		}
		return false;
	}
	private void doInit() throws InvalidFileFormatException{
		
		//String separator =
		if(null == filePath || filePath.isEmpty())
			throw new InvalidFileFormatException("File can't be null or empty");
		
		String separator = File.separator;
		
		if(isWindow()) {
			separator = "\\\\";
		//	lineSeparator = "\n";
		}else{
			separator = "/";
			//lineSeparator = "\n";
		}
		lineSeparator = System.lineSeparator();
		
		
		System.out.println("Separator = "+separator);
		String []paths = filePath.split(separator);
		System.out.println("paths array size = "+paths.length);
		if(null == paths || paths.length == 0){
			this.fileName = filePath;
			this.absPath = ".";
		}else{
			this.fileName = paths[paths.length-1];
			this.absPath = filePath.substring(0,filePath.indexOf(fileName));
		}
		
		System.out.println("filename = "+fileName+" filepath = "+absPath);
		
		
		
		
		
		
	}
	
	
	
	

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	
		
	public FileType getFileType() {
		return fileType;
	}

	public void setFileType(FileType fileType) {
		this.fileType = fileType;
	}

	public String getDelimeter() {
		return delimeter;
	}

	public void setDelimeter(String delimeter) {
		this.delimeter = delimeter;
	}

	public String getRepositoryPath() {
		return repositoryPath;
	}

	public void setRepositoryPath(String repositoryPath) {
		this.repositoryPath = repositoryPath;
	}

}
