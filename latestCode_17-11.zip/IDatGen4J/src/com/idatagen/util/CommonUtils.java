package com.idatagen.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommonUtils {

	// Insert a character in a string at a certain position - before and after
	public static String insertCharBeforeAndAfter(String originalStr,
			String searchWord, String toInsert) {
		String modifiedStr = originalStr;
		int wordLength = searchWord.length();
		int wordPosition = modifiedStr.toLowerCase().indexOf(searchWord);
		// System.out.println("Occurance 1@: " + wordPosition);
		int searchFrom = wordPosition + wordLength;

		while (true) {
			modifiedStr = new StringBuffer(modifiedStr).insert(wordPosition,
					" ").toString();
			modifiedStr = new StringBuffer(modifiedStr).insert(
					wordPosition + 2, " ").toString();
			wordPosition = modifiedStr.toLowerCase().indexOf(searchWord,
					searchFrom + 3);
			searchFrom = wordPosition + wordLength;

			if (wordPosition == -1)
				break;
			// System.out.println("==== >>" + modifiedStr);

		}

		return modifiedStr;
	}

	public static String removeExtraSpacesToOneSpace(String strToModify) {

		String modifiedStr = strToModify.replaceAll("\\s+", " ");

		return modifiedStr;
	}

	public static String replaceCharatersFromStr(String original,
			String toReplace, String replacement) {

		toReplace = "(?i)"+toReplace; // Using this for irrespective of any case 
		String modifiedStr = original.replaceAll(toReplace, replacement);

		return modifiedStr;

	}

	public static String[] concatinateTwoStrArrays(String[] arrayOne,
			String[] arrayTwo) {

		String[] arraysMerged = null;

		if (arrayOne != null && arrayTwo != null) {

			List<String> sqlQueriesList = new ArrayList<String>();
			sqlQueriesList.addAll(Arrays.asList(arrayOne));
			sqlQueriesList.addAll(Arrays.asList(arrayTwo));
			arraysMerged = sqlQueriesList.toArray(new String[sqlQueriesList.size()]);

		}

		else if (arrayOne == null && arrayTwo != null) {
			arraysMerged = arrayTwo;

		} else if (arrayOne != null && arrayTwo == null) {
			arraysMerged = arrayOne;

		}

		return arraysMerged;

	}

}
