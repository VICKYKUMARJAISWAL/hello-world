package com.idatagen.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.xml.crypto.Data;

import com.igate.db.dao.DataType;

public class Utility {

	
	public static boolean isValidInt(String text){
		  
		try{
			Integer.parseInt(text);
			return true;
		}catch(NumberFormatException nx){
			return false;
		}
		
	}
	public static boolean isValidBigInt(String text){		 
		try{
			Long.parseLong(text);
			return true;
		}catch(NumberFormatException nx){
			return false;
		}		
	}
	
	public static boolean isValidDate(String text){		 
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			sdf.parse(text);
			return true;
		}catch(ParseException nx){
			return false;
		}		
	}
	public static boolean isValidDateTime(String text){		 
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			sdf.parse(text);
			return true;
		}catch(ParseException nx){
			return false;
		}		
	}
	
	public static boolean isValidDataType(String type){
		
		/*switch(type){
			case DataType.BIGINT:
				return true;
			case DataType.INTEGER:
				return true;
			case DataType.DATE:
				return true;
			case DataType.DATETIME:
				return true;
			case DataType.VARCHAR:
				return true;
			default:
				return false;				
				
		}*/
		
		switch(type){
		case DataType.INT:
			return true;
		case DataType.DATE:
			return true;
		case DataType.DATETIME:
			return true;
		case DataType.VARCHAR:
			return true;
		case DataType.FLOAT:
			return true;
		default:
			return false;				
			
	}
				
	}
	
	
	
	
	
}
