package com.idategen.data.reader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.text.Utilities;
import javax.xml.crypto.Data;

import com.idatagen.file.FileResourceManager;
import com.idatagen.util.Utility;
import com.igate.constants.FileType;
import com.igate.datagen.exceptions.InvalidFileFormatException;
import com.igate.db.dao.DataType;
import com.igate.dto.ColumnDetail;

public class CSVFileReader extends FileReaderManager{

	private List<ColumnValueHelper> fileColummnList;
	private List<String[]> lines = new ArrayList<>();
	public CSVFileReader(String filepath, FileType filetype, String delm) throws InvalidFileFormatException {
		super(filepath, filetype, delm);
		// TODO Auto-generated constructor stub
		fileColummnList = new ArrayList<>();
	}

	//String delim, Vector<Vector<Object>> datavector, List<ColumnDetail> columnlist, String filepath 
	private void setColumns(String line){
		
		//String []columns = line.trim().split(this.getDelimeter());
		StringTokenizer tokens = new StringTokenizer(line, this.getDelimeter());
		while(tokens.hasMoreTokens()){
			String val = tokens.nextToken();
			ColumnValueHelper cv = new ColumnValueHelper(val.trim());
			fileColummnList.add(cv);
		}
		/*for(int i = 0; i < columns.length; i++){
			ColumnValueHelper cv = new ColumnValueHelper(columns[i].trim());
			fileColummnList.add(cv);
		}*/
	}
	
	
	
	private boolean processItems(String line){
		
		List<String> tokenlist = new ArrayList<>();
		StringTokenizer tokens = new StringTokenizer(line, this.getDelimeter());
		while(tokens.hasMoreTokens()){
			String val = tokens.nextToken();
			if(null == val)
				val = "";
			tokenlist.add(val.trim());
		}
		String []datas = tokenlist.toArray(new String[tokenlist.size()]);
		//String []datas = line.trim().split(this.getDelimeter());
		if(null == datas || datas.length != fileColummnList.size())
			return false;
		
		// Now coulmn count and data count in the current line are equal
		// Let's validate the data with the datatype
		
	/*	for(int i = 0; i < fileColummnList.size(); i++){
			ColumnDetail cd = new ColumnDetail();
			String type= cd.getColumnType();
			if(!isvalidata(datas[i],type)){
				return false;
			}
		}*/
			
		
		
		lines.add(datas);
		for(int i = 0; i < fileColummnList.size(); i++){
			ColumnValueHelper cv = fileColummnList.get(i);
			cv.getValueList().add(datas[i]);			
		}
		return true;
	}
	
	private DataResultSet processDataResultSet(){
	
		DataResultSet ds = new DataResultSet();
		for(int i = 0; i < fileColummnList.size(); i++){
			ColumnValueHelper cv = fileColummnList.get(i);
			ColumnDetail cd = new ColumnDetail();
			cd.setColumnName(cv.columnName);
			cd.setColumnType("varchar");
			ds.keep(cd, cv.getValueList());
		}
		ds.setHorizontalData(lines);
		return ds;
	}
	
	@Override
	public DataResultSet read()throws InvalidFileFormatException {
		// TODO Auto-generated method stub
	
		BufferedReader br = null;
		String line = "";
		int count = 0;
		try {
			br = new BufferedReader(new FileReader(this.getFilePath()));
			while ((line = br.readLine()) != null) {
				if(null == line || line.isEmpty())
					continue;
				count++;
			if(count == 1)
				setColumns(line);
			else{
				if(!processItems(line)){
					System.out.println("Problem in the line "+count);
				}
			}						
		}
		} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
		e.printStackTrace();
		}finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		return processDataResultSet();

	}

	 class ColumnValueHelper{
		String columnName;
		List<String> valuelist;
		
		ColumnValueHelper(String cname){
			columnName = cname;
			valuelist = new ArrayList<String>();
		}
		
		public List<String> getValueList(){
			return valuelist;
		}
		
	}
	
	
	public static void main(String args[]){
		try {
			FileReaderManager fm = new CSVFileReader("d:\\rashmi\\testlarge.txt",FileType.CSV,",");
			DataResultSet ds = fm.read();
			System.out.println(ds);
		} catch (InvalidFileFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
