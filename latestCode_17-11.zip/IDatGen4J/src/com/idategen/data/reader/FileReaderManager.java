package com.idategen.data.reader;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import com.idatagen.file.FileResourceManager;
import com.igate.constants.FileType;
import com.igate.datagen.exceptions.InvalidFileFormatException;

public abstract class FileReaderManager extends FileResourceManager{

	public FileReaderManager(String filepath, FileType filetype, String delm)
			throws InvalidFileFormatException {
		super(filepath, filetype, delm);
		// TODO Auto-generated constructor stub
	}

	public abstract DataResultSet read() throws InvalidFileFormatException;	
	
	
}
