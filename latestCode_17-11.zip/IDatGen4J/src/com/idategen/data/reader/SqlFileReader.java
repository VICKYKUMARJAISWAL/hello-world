package com.idategen.data.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.idatagen.query.SqlQueryBuilderFromFile;
import com.idatagen.util.CommonUtils;
import com.idatagen.util.QueryReferenceCheck;

public class SqlFileReader {
	
	
	static String strCurrentLine;
	static String sqlString = "";
	static String dbName="idatagendb.dev2.";

	public static boolean readSql(String fileName, String dataModelName) {
		SqlQueryBuilderFromFile queryBuild = new SqlQueryBuilderFromFile();
		QueryReferenceCheck queryRefCheck = new QueryReferenceCheck();

		File schemaFile = new File(fileName);
		String sqlString = "";
		String sqlCreateQueries[] = null;
		
		boolean isQueryExecuted = false;
		String[] insertQueriesCreated = null;
		String[] sqlConcatinatedQueries = null;

		if (schemaFile.exists()) {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(
						new FileInputStream(schemaFile)));

				while ((strCurrentLine = br.readLine()) != null) {
					sqlString = sqlString + strCurrentLine;
				}
				br.close();
				System.out.println("Input from File : " + sqlString);
			} catch (IOException e) {
				System.out.println("EXCEPTION: While reading the input file");
				e.printStackTrace();
			}

			sqlString = sqlString.replaceAll("`", "");

			sqlCreateQueries = sqlString.split(";");

			System.out.println("Queries to be executed : ");
			for (int i = 0; i < sqlCreateQueries.length; i++) {
				System.out.println(sqlCreateQueries[i]);
			}
			
			
			// adding code to appened dataModelName to entity and its  reference table 
			String tableName="";
			for(int n=0;n<=(sqlCreateQueries.length)-1; n++ )
			{
				String[] querySplited = sqlCreateQueries[n].split(" ");
				
				for (int k = 1; k < querySplited.length; k++) {
					//System.out.println(">> >> > Loop* " + k);
					if (querySplited[k].equalsIgnoreCase("TABLE")) {
						tableName = querySplited[k + 1];
						System.out.println("Table Name is here: "+tableName);
						String finaltableName=dbName+dataModelName+tableName;
						System.out.println("finaltableName  is here: "+finaltableName);
						
						
						sqlCreateQueries[n]=sqlCreateQueries[n].replaceFirst(tableName, finaltableName);
						k++;
						System.out.println("here is the final query after replacing table-------------->>>"+sqlCreateQueries[n]);
					}
					
					if (querySplited[k].equals("REFERENCES")) {
						String refTable = querySplited[k + 1];
						String finalReferencetableName=dbName+dataModelName+refTable;
						sqlCreateQueries[n]=sqlCreateQueries[n].replace("REFERENCES "+refTable, "REFERENCES "+finalReferencetableName);
						System.out.println("here is the final query replacing refer-------------->>>"+sqlCreateQueries[n]);
					}
					
					
			}
			}
			
			
			
			

			// Call Reference Check
			System.out.println("====================== REFERENCE CHECK STARTS ======================");
			if (sqlCreateQueries != null) {
				insertQueriesCreated = queryRefCheck.referenceChecker(sqlCreateQueries, dataModelName);
				System.out.println("====================== REFERENCE CHECK COMPLETED ======================");
				sqlConcatinatedQueries = CommonUtils.concatinateTwoStrArrays(sqlCreateQueries, insertQueriesCreated);
				System.out.println("Query after concatination---"+sqlConcatinatedQueries);
				
			}
			/*List<String> sqlQueriesList = new ArrayList<String>();
			sqlQueriesList.addAll(Arrays.asList(sqlCreateQueries));
			sqlQueriesList.addAll(Arrays.asList(insertQueriesCreated));
			sqlConcatinatedQueries = sqlQueriesList.toArray(new String[sqlQueriesList
					.size()]);*/

		} else {
			isQueryExecuted = false;
			System.out.println("EXCEPTION : The input file doesn't exist");
			return isQueryExecuted;
		}

		try {
			isQueryExecuted = queryBuild.batchInsert(sqlConcatinatedQueries);
			System.out.println("***@@@*@*@*@*@*@*@*@*@*@*@*@*@*@*");
		} catch (IOException e) {
			isQueryExecuted = false;
			System.out.println("EXCEPTION: While inserting the Queries.");
			e.printStackTrace();
		}
		return isQueryExecuted;
	}
	
    public static String displaySqlSchema(String filePath) {
		
    	File schemaFile = new File(filePath);
    	String strDispCurrentLine = "";
    	String sqlDispString = "";
    	
    	if (schemaFile.exists()) {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(
						new FileInputStream(schemaFile)));

				while ((strDispCurrentLine = br.readLine()) != null) {
					sqlDispString = sqlDispString + strDispCurrentLine;
				}
				
				
				br.close();
				System.out.println("Input from File : " + sqlDispString);
				sqlDispString = sqlDispString.replaceAll(";",";\n \n");
			} catch (IOException e) {
				System.out.println("EXCEPTION: While reading the input file");
				e.printStackTrace();
			}
	}
    	return sqlDispString;
    }

	public static void main(String args[]) throws IOException {
		SqlFileReader reader = new SqlFileReader();
		boolean isQueryInserted = reader.readSql("D:/schema.sql", "dataModel");

		if (isQueryInserted == true)
			System.out.println("Query Executed");
		else
			System.out.println("Query NOT Executed");

	}

	
}
