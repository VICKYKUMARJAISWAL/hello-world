package com.idategen.data.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import com.idatagen.query.SqlQueryBuilderFromFile;

public class SqlFileReader_Old {

	public static boolean readSql(String fileName) {
		SqlQueryBuilderFromFile queryBuild = new SqlQueryBuilderFromFile();
		File schemaFile = new File(fileName);
		String sqlString = "";
		String sqlQueries[] = null;
		String strCurrentLine;
		boolean isQueryInserted = false;

		if (schemaFile.exists()) {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(
						new FileInputStream(schemaFile)));

				while ((strCurrentLine = br.readLine()) != null) {
					sqlString = sqlString + strCurrentLine;
				}
				br.close();
				System.out.println("Input from File : "+sqlString);
			} catch (IOException e) {
				System.out.println("EXCEPTION: While reading the input file");
				e.printStackTrace();
			}

			sqlString = sqlString.replaceAll("`", "");

			sqlQueries = sqlString.split(";");

			System.out.println("Queries to be executed : ");
			for (int i = 0; i < sqlQueries.length; i++) {
				System.out.println(sqlQueries[i]);
			}
			// }

		} else {
			isQueryInserted = false;
			System.out.println("EXCEPTION : The input file doesn't exist");
			return isQueryInserted;
		}

		try {
			isQueryInserted = queryBuild.batchInsert(sqlQueries);
		} catch (IOException e) {
			isQueryInserted = false;
			System.out.println("EXCEPTION: While inserting the Queries.");
			e.printStackTrace();
		}
		return isQueryInserted;
	}

	public static void main(String args[]) throws IOException {
		SqlFileReader_Old reader = new SqlFileReader_Old();
		boolean isQueryInserted = reader.readSql("D:/SqlFiles/schemaa.txt");

		if (isQueryInserted == true)
			System.out.println("Query Executed");
		else
			System.out.println("Query NOT Executed");

	}
}
