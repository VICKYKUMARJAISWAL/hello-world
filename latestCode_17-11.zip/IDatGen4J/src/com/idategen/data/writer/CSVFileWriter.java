package com.idategen.data.writer;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Vector;

import com.idatagen.file.FileResourceManager;
import com.idategen.data.reader.DataResultSet;
import com.igate.constants.FileType;
import com.igate.datagen.exceptions.InvalidFileFormatException;
import com.igate.dto.ColumnDetail;

public class CSVFileWriter extends FileWriteManager{

	private Vector<Vector<Object>> datavector;
	private List<ColumnDetail> columnList;
	private  FileWriter fw;
	private boolean iscolumnwritten = false;
	private boolean isresourceActie = false;

	public CSVFileWriter(String filepath, FileType filetype, String delm,Vector<Vector<Object>> datavector, List<ColumnDetail> columnlist)
			throws InvalidFileFormatException {
		super(filepath, filetype, delm);		
		// TODO Auto-generated constructor stub
		this.datavector = datavector;
		this.columnList = columnlist;
		initWriter();
		
	}
	
	public CSVFileWriter(String filepath, FileType filetype, String delm,List<ColumnDetail> columnlist) throws InvalidFileFormatException{
		super(filepath, filetype, delm);
		this.columnList = columnlist;
		initWriter();	
	}
	
	private boolean isInit = false; 
	private void initWriter(){
		try{
			this.fw = new FileWriter(getFilePath());
			isInit = true;
			writeColumns();
		}catch(IOException iox){
			iox.printStackTrace();
		}
	}
	private void writeColumns() throws IOException{
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < columnList.size(); i++){
			sb.append(columnList.get(i).getColumnName());
			sb.append(getDelimeter());			
		}
		sb.deleteCharAt(sb.lastIndexOf(getDelimeter()));
		fw.append(sb.toString());
		fw.append(getLineSeparator());
		iscolumnwritten = true;
		//fw.append("line sep");
	}
	private void closeResource() throws IOException{
		if(null != fw){
			fw.close();
			fw = null;
		}
	}
	
	private void export0(boolean isclosereq){
		try{	
		
			if(datavector == null || datavector.isEmpty()){
				System.out.println("No data found");
				closeResource();
				return;
			}
			for(int i = 0; i < datavector.size(); i++){
				StringBuilder linebbuilder = new StringBuilder();
				List<Object> lineobbject =datavector.get(i); 
				for(int j = 0; j < lineobbject.size(); j++ ){
					linebbuilder.append(lineobbject.get(j));
					linebbuilder.append(getDelimeter());
				}
				linebbuilder.deleteCharAt(linebbuilder.lastIndexOf(getDelimeter()));
				fw.append(linebbuilder.toString());
				fw.append(getLineSeparator());
				//fw.append("line sep");
			}
		}catch(IOException iox){
			
		}finally{
			try{
				if(isclosereq)
					closeResource();
			}catch(IOException ix2){
				ix2.printStackTrace();
			}
		}

	}
	
	
	@Override
	public void export() throws InvalidFileFormatException {
		// TODO Auto-generated method stub
		
		if(!isInit) throw new InvalidFileFormatException("Oops.. a problem occurs !!!");
		System.out.println("Going to export'''");		
		export0(true);
				
	}

	public void setDataVector(Vector<Vector<Object>> data){
		this.datavector = data;
	}
	@Override
	public void append(Vector<Vector<Object>> data){
		// TODO Auto-generated method stub
	//	if(!isInit) throw new InvalidFileFormatException("Oops.. a problem occurs !!!");
		System.out.println("Going to export'''");
		this.datavector = data;
		export0(false);
	}

	@Override
	public void closeResoureceGracefully() {
		// TODO Auto-generated method stub
		try {
			this.closeResource();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
