package com.idategen.data.writer;

import java.util.Vector;

import com.idatagen.file.FileResourceManager;
import com.idategen.data.reader.DataResultSet;
import com.igate.constants.FileType;
import com.igate.datagen.exceptions.InvalidFileFormatException;

public abstract class FileWriteManager extends FileResourceManager{

	public FileWriteManager(String filepath, FileType filetype, String delm)
			throws InvalidFileFormatException {
		super(filepath, filetype, delm);
		// TODO Auto-generated constructor stub
	}
	public abstract void export() throws InvalidFileFormatException;
	public abstract void append(Vector<Vector<Object>> data) ;
	public abstract void closeResoureceGracefully();

}
