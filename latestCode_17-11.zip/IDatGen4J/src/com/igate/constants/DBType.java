package com.igate.constants;

public enum DBType {

	SQLLITE,
	SYBASE
}
