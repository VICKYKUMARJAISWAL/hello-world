package com.igate.constants;

public enum FileType {

	CSV,
	Excel	
}
