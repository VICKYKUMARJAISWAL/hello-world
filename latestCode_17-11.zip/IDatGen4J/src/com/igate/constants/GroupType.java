package com.igate.constants;

public enum GroupType {

	GROUP(1),
	ASSETCLASS(2);
	
	private final int value;
	GroupType(int type){
		this.value = type;
	}
	
	public int getValue() {
	        return value;
	}
	public static GroupType getType(int type){
		switch(type){
		case 1:
			return GROUP;
		case 2:
			return ASSETCLASS;
		default:
			return GROUP;
		}
	}
}
