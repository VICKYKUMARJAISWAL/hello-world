package com.igate.dao.factory;

import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;





import com.igate.db.command.DaoCommand;
import com.igate.db.manager.ConnectionManager;
import com.igate.db.manager.DaoManager;
import com.igate.dto.ConnectionDetail;
import com.igate.dto.GroupRecord;

public class DaoFactory {


	private static ConnectionManager cm = null;
	public static DaoManager createDaoManager(){
		if(null == cm)
			cm = new ConnectionManager();
		Connection conn = cm.getConnection();
		return new DaoManager(conn);
		
	}
	
	public static DaoManager createDaoManager(ConnectionDetail condetaili){
		if(null == cm)
			cm = new ConnectionManager();
		Connection conn = cm.getConnection();
		return new DaoManager(cm.getConnection(),cm.getConnection());
		
	}
	
	
	public static void main(String args[]){
		
	/*	DaoManager dm = DaoFactory.createDaoManager();
		List<GroupRecord> glist = (List<GroupRecord>)dm.executeAndClose(new DaoCommand() {
			
			@Override
			public Object execute(DaoManager daoManager) {
				// TODO Auto-generated method stub
				return daoManager.getGroupDAO().getAllSubCategoryById(0);
			}
		});*/
		
		//System.out.println("list = "+glist);				
		StringBuffer sb = new StringBuffer();
		//BlockingQueue d ;
	}
}
