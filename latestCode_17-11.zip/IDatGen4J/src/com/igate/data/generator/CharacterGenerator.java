package com.igate.data.generator;

import java.util.Random;

public class CharacterGenerator extends DataGenerator{

	
	
	public CharacterGenerator(int digitlength){
		super(digitlength);
		//this.digitLength = digitlength;
		//data = new char[size];
	}
	public CharacterGenerator(){
		super(1);
		//this(DEFAULT_SIZE);
	}
	
	
	@Override
	public String[] generatedAndGet(int noofitems) {
		System.out.println("noofitems = "+noofitems);
		String []data = new String[noofitems];
		Random randomobj = new Random();
		int high = 90;
		int low = 65;
		int digitlenght = getDigitLength();
		int lcount = 0;
		for(int j = 0; j < noofitems; j++){
			String item = "";			
			for(int i = 0; i < digitlenght; i++ ){
				char s = (char)(randomobj.nextInt(high-low)+low);
				//System.out.println("lcount = "+lcount++);
				item = item+s;
			}
			data[j] = item;
		}
		return data;
	}
	

	public static void main(String args[]){
	
		DataGenerator dg  = new CharacterGenerator(11);
		String[] items = dg.generatedAndGet(10000000);
		
		
		
		for(int i = 0; i < items.length; i++){
			System.out.println(items[i]+" no "+i);
		}
		
	}
	
}
