package com.igate.data.generator;

public abstract class DataGenerator {

	private String [] data;
	private final static int DEFAULT_SIZE=1;
	private  int digitLength;
	
	public DataGenerator(){
		
	}
	public DataGenerator(int digitLength){
		this.digitLength = digitLength;
	}
	public abstract String [] generatedAndGet(int noofitems);
	
	public int getDigitLength(){
		return this.digitLength;
	}
	public String toString(){
		return this.getClass().getName()+" of "+digitLength;
	}
	
	 
}
