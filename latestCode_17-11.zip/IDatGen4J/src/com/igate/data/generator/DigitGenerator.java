package com.igate.data.generator;

import java.util.Random;

public class DigitGenerator extends DataGenerator{
	
	public DigitGenerator(int digitlength){
		super(digitlength);
		//this.digitLength = digitlength;
		//data = new char[size];
	}
	public DigitGenerator(){
		super(1);
		//this(DEFAULT_SIZE);
	}
	
	
	public String [] generatedAndGet(int noofitems){
		String []data = new String[noofitems];
		Random randomobj = new Random();
		int digitlenght = getDigitLength();
		for(int j = 0; j < noofitems; j++){
			String item = "";			
			for(int i = 0; i < digitlenght; i++ ){
				int s = randomobj.nextInt(10);
				item = item+s;
			}
			data[j] = item;
		}
		return data;
	}
	
	
	public static void main(String args[]){
		
		DataGenerator dg  = new DigitGenerator(3);
		String[] items = dg.generatedAndGet(50);
		
		for(int i = 0; i < items.length; i++){
			System.out.println(items[i]);
		}
		
	}
	
}
