package com.igate.data.generator;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;

import com.idategen.data.writer.CSVFileWriter;
import com.idategen.data.writer.FileWriteManager;
import com.igate.constants.FileType;
import com.igate.datagen.exceptions.InvalidFileFormatException;
import com.igate.dto.ColumnDetail;

public class FileExporter {

	List<ComplexTypeBuilder> complexlist;
	List<ComplexTypeBuilder> cblist = new ArrayList<>();
	
	private Vector<Object> createrow(){
		Vector<Object> row = new Vector<>();
		for(int i = 0; i < cblist.size(); i++){
			ComplexTypeBuilder cb = cblist.get(i);
			String cdata = cb.buildData(1)[0];
			if(null == cdata){
				System.out.println("null at i = "+i);
				continue;
			}
			row.add(cdata);
		}
		return row;
	}
	
	
	public void doExport(String fullfile,List<ColumnDetail> clist, Map<String,ComplexTypeBuilder> typemap,int totalRow,String delim){
		
			Date sd = new Date();
		
		
		
	//	FileWriteManager fm = new CSVFileWriter(filepath, filetype, delm, datavector, columnlist);
		
	//	List<ComplexTypeBuilder> cblist = new ArrayList<>(clist.size());
		Vector<Vector<Object>> datavector = new Vector<>();
		for(int i = 0; i < clist.size(); i++){
			ComplexTypeBuilder cb = typemap.get(clist.get(i).getColumnName());
			if(cb == null){
				System.out.println("Not getting for "+clist.get(i));
				continue;
			}
			else{
				System.out.println(" Getting ctype for "+clist.get(i).getColumnName()+" ctype = "+cb.getItemSize());
			}
			cblist.add(cb);
		}
		
		System.out.println("Time taken to cal random numbers = "+(new Date().getTime()-sd.getTime())/1000 );
	//	try {
			//Thread.sleep(5000);
		//} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
		//	e1.printStackTrace();
		//}
		FileWriteManager fm = null;
		try{
			fm = new CSVFileWriter(fullfile, FileType.CSV, delim, clist);
		}catch(InvalidFileFormatException ix){
			ix.printStackTrace();
			return;
		}
		for(int i = 0; i < totalRow; i++)	{	
			datavector.add(createrow());
			if(datavector.size() == 1000){
				fm.append(datavector);
				datavector.clear();
			}
			System.out.println(""+i+" size = "+datavector.size());
		}
		if(datavector.size() > 0){
			fm.append(datavector);
			datavector.clear();
		}
		Date md = new Date();
		System.out.println("Time taken to cal random numbers = "+(md.getTime()-sd.getTime())/1000 );
		fm.closeResoureceGracefully();
		/*try {
		//	FileWriteManager fm = new CSVFileWriter(fullfile, FileType.CSV, delim, datavector, clist);
		//	fm.export();
		} catch (InvalidFileFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		Date ed = new Date();
		System.out.println("Time taken to generate files = "+(ed.getTime()-md.getTime())/1000 );
	}
	
	public static void main(String args[]){
		
		
		char[] caray = System.lineSeparator().toCharArray();
		
		System.out.println(caray.length);
		//for(int i = 0; i < caray.length; i++)
		//System.out.println(Character.
		
		Map<String, ComplexTypeBuilder> mymap = new HashMap<String, ComplexTypeBuilder>();
		ColumnDetail cd = new ColumnDetail();
		cd.setColumnName("c1");
		ComplexTypeBuilder cb = new ComplexTypeBuilder();
		cb.addItem(new DigitGenerator(11));
		//cb.addItem(new CharacterGenerator(2));
		mymap.put(cd.getColumnName(), cb);
		
		
		ColumnDetail cd1 = new ColumnDetail();
		cd1.setColumnName("c2");
		ComplexTypeBuilder cb1 = new ComplexTypeBuilder();
		cb1.addItem(new CharacterGenerator(11));
		//cb1.addItem(new DigitGenerator(2));
		mymap.put(cd1.getColumnName(), cb1);
		
		ColumnDetail cd2 = new ColumnDetail();
		cd2.setColumnName("c3");
		ComplexTypeBuilder cb2 = new ComplexTypeBuilder();
		cb2.addItem(new CharacterGenerator(5));
		cb2.addItem(new DigitGenerator(6));
		mymap.put(cd2.getColumnName(), cb2);
		
		List<ColumnDetail> clist = new ArrayList<>();
		clist.add(cd);
		clist.add(cd1);
		clist.add(cd2);
		
		FileExporter fe = new FileExporter();
		fe.doExport("D://rashmi//testlarge.txt",clist, mymap,1000000,",");
		
		
		
		
		
	}
}
