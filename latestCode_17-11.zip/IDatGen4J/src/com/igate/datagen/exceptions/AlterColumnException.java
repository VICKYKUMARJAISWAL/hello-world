package com.igate.datagen.exceptions;

public class AlterColumnException extends Exception {

	public AlterColumnException(String message){
		super(message);
	}
}
