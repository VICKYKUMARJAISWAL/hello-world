package com.igate.datagen.exceptions;

public class InvalidFileFormatException extends Exception{

	public InvalidFileFormatException(String message){
		super(message);
	}
}
