package com.igate.db.command;

import com.igate.db.manager.DaoManager;

public interface DaoCommand {

	 public Object execute(DaoManager daoManager);
}
