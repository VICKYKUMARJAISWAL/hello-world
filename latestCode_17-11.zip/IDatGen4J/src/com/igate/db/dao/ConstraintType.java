package com.igate.db.dao;

public class ConstraintType {
	public static String Pk_varchar = "Primary Key";
	public static String FK_varchar= "Foreign Key";
	public static String UQ_varchar= "Unique";
	public static String NotNull_varchar="Not null";
	

}
