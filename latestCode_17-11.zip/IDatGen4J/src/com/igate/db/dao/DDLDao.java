package com.igate.db.dao;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.text.TabExpander;

import org.fluttercode.datafactory.impl.DataFactory;

import com.igate.constants.DBType;
import com.igate.dao.factory.DDLCommandFactory;
import com.igate.db.manager.ConnectionManager;
import com.igate.dto.ColumnDetail;
import com.igate.dto.ConnectionDetail;

public class DDLDao implements GenericDao {

	private Connection connection;
	DataFactory dataFactory = new DataFactory();
	private static String MASTERLOOKUPTABLE ="MasterDataGenLookUpTable";
	private static String MASTERREFERENCETABLE ="MasterReferencesTable";
	
	String dbPrefix = "idatagendb.dev2.";

	private static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final int RANDOM_STRING_LENGTH = 10;
	
	private Set<Integer> primarySet = new HashSet<Integer>();
	private Map<String, ArrayList<Object>> lookUpMap = new HashMap<String,ArrayList<Object>>(); 

	public DDLDao(Connection connection) {
		this.connection = connection;
	}

	private List<ColumnDetail> parseAndGetList(String result) {
		List<ColumnDetail> lists = new ArrayList<>();
		// CREATE TABLE G111 (id INTEGER PRIMARY KEY AUTOINCREMENT, C1 CHAR
		// (10), C2 CHAR (11), C3 CHAR (11))
		if (null == result || result.isEmpty())
			return lists;
		String substr = result.substring(result.indexOf("(") + 1,
				result.lastIndexOf(")"));
		String[] columns = substr.split(",");
		for (int i = 0; i < columns.length; i++) {

			String name = columns[i].trim().split("\\s+")[0];
			String type = columns[i].trim().split("\\s+")[1];
			if ("pid".equalsIgnoreCase(name))
				continue;
			ColumnDetail cd = new ColumnDetail();
			cd.setColumnName(name);
			cd.setColumnType(type);
			lists.add(cd);
		}

		return lists;

	}

	@Override
	public List<ColumnDetail> getTableInfo(String tablename) {
		// TODO Auto-generated method stub
		List<ColumnDetail> lists = new ArrayList<>();
		String sql = DDLCommandFactory.getColumnInfoCommand(DBType.SQLLITE);
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			//System.out.println("sql = " + sql);
			ps = connection.prepareStatement(sql);
			ps.setString(1, tablename);
			rs = ps.executeQuery();
			String result = "NA";
			while (rs.next()) {
				result = rs.getString(1);
				break;
			}
			if (!"NA".equalsIgnoreCase(result))
				lists = parseAndGetList(result);
		} catch (SQLException sex) {
			sex.printStackTrace();
		} finally {
			try {
				if (null != rs) {
					rs.close();
					rs = null;
				}
				if (null != ps) {
					ps.close();
					ps = null;
				}
			} catch (SQLException sx) {

			}

		}
		return lists;
	}

	/**
	 * @Description Method to retrieve the metaData of the columns and put them in a map and return it
	 * @param tableName
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getMetaData(String tableName) throws Exception {
		
		tableName = dbPrefix+ tableName;
		String sqlQuery = "SELECT * FROM " + tableName;
		
		Map<String, String> metaDataMap = new LinkedHashMap<String, String>();
		Statement stmt = null;
		ResultSet rst = null;

		try {
			stmt = connection.createStatement();
			rst = stmt.executeQuery(sqlQuery);
			ResultSetMetaData metaData = rst.getMetaData();

			for (int i = 1; i <= metaData.getColumnCount(); i++) {
				/*System.out.print(metaData.getColumnName(i) + "("
						+ metaData.getColumnTypeName(i) + ")   ");*/

				metaDataMap.put(metaData.getColumnName(i).trim(), metaData
						.getColumnTypeName(i).trim());

			}
			// System.out.println("\n");

		} finally {
			stmt.close();
			rst.close();
		}

		return metaDataMap;
	}

	/**
	 * @Description Retrieves the constraints on each column and puts them in a map and returns it
	 * @param tableName
	 * @return
	 */
	public Map<String, String> getTableConstraints(String tableName) {
		DatabaseMetaData meta = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		ResultSet rs4 = null;
		Statement stmt = null;
		Map<String, String> constraintsMap = new HashMap<String, String>();
		try {

			meta = connection.getMetaData();

			// System.out.println("I am here--------" + meta.getDriverName());

			// To get primary key of table
			// tableName = dbPrefix+ tableName;
			rs1 = meta.getPrimaryKeys("idatagendb", "dev2", tableName);

			if (rs1.next()) {
				String columnName = rs1.getString(4);
				/*
				 * System.out .println("getPrimaryKeys(): columnName=" +
				 * columnName);
				 */
				constraintsMap.put(columnName, "PRIMARY KEY");
			}

			// To get Foreign keys
			rs2 = meta.getImportedKeys("idatagendb", "dev2", tableName);
			while (rs2.next()) {
				String foreignKey = rs2.getString(4);
				// System.out.println("Foreign Key :" + foreignKey);
				constraintsMap.put(foreignKey, "FOREIGN KEY");
			}

			// To get unique keys
			rs3 = meta
					.getIndexInfo("idatagendb", "dev2", tableName, true, true);

			while (rs3.next()) {
				String indexName = rs3.getString("INDEX_NAME");
				/* System.out.println("--------------"+indexName); */
				String columnName = rs3.getString("COLUMN_NAME");
				if (indexName == null) {
					continue;
				}

				if (!("PRIMARY KEY").equalsIgnoreCase(constraintsMap
						.get(columnName))) {
					constraintsMap.put(columnName, "UNIQUE KEY");
				}
				// System.out.println("Unique Column " + columnName);

			}

			// to find if the column is Nullable
			// tableName = dbPrefix+ tableName;
			String query = "select * from " + dbPrefix + tableName;

			try {

				stmt = connection.createStatement();
				rs4 = stmt.executeQuery(query);

				ResultSetMetaData metaData = rs4.getMetaData();

				for (int m = 1; m <= metaData.getColumnCount(); m++) {

					int nullable = metaData.isNullable(m);

					if (nullable == 0) {

						if (!constraintsMap.containsKey(metaData
								.getColumnName(m))) {
							constraintsMap.put(metaData.getColumnName(m),
									"NOT NULL");
						}
					} else if (nullable == 1) {
						if (!constraintsMap.containsKey(metaData
								.getColumnName(m))) {
							constraintsMap.put(metaData.getColumnName(m),
									"NULL");
						}
					}

				}

			} catch (Exception e) {
				e.printStackTrace();

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {

			try {
				rs1.close();
				rs2.close();
				rs3.close();
				rs4.close();
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return constraintsMap;
	}

	
	/**
	 * @Description Method gets all the tables of a particular model based on the data model name
	 * @param dataModel
	 * @return
	 */
	public Set<String> getTables(String dataModel) {

		String referenceTableName = "idatagendb.dev2."+MASTERREFERENCETABLE;
		String query = "Select TableName FROM " + referenceTableName+ " WHERE DataModel = '" + dataModel + "'";

		Statement stmt = null;
		ResultSet rst = null;
		Set<String> tableNames = new HashSet<String>();

		try {
			stmt = connection.createStatement();
			rst = stmt.executeQuery(query);

			while (rst.next()) {
				tableNames.add(rst.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rst.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return tableNames;
	}
	
	
	/**
	 * @Description Retrieves the names of all the data models from the master reference table
	 * @return
	 */
	public Set<String> getDataModels()
	{
		String referenceTableName = "idatagendb.dev2."+MASTERREFERENCETABLE;
		String query = "Select DataModel FROM " + referenceTableName;

		Statement stmt = null;
		ResultSet rst = null;
		Set<String> modelNames = new HashSet<String>();

		try {
			stmt = connection.createStatement();
			rst = stmt.executeQuery(query);

			while (rst.next()) {
				modelNames.add(rst.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rst.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return modelNames;
	
	}

	/**
	 * @Description Checks the master data table for references of a particular
	 *              table
	 * @param tableName
	 * @return
	 */
	public Map<String, String> checkReferences(String tableName) {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		tableName = tableName.substring(tableName.lastIndexOf(".")+1);
		String referenceTableName = "idatagendb.dev2."+MASTERREFERENCETABLE;
		String query = "SELECT * FROM "+referenceTableName+ " WHERE upper(TableName) = ? ";
		Map<String, String> referenceValues = new HashMap<String, String>();
		try {
			stmt = connection.prepareStatement(query);
			stmt.setString(1, tableName.toUpperCase());
			rs = stmt.executeQuery();

			while (rs.next()) {
				String refTable = rs.getString("ReferenceTable");
				String refColumnName = rs.getString("ReferenceColumn");
				String foreignKeyColumn = rs.getString("TableRefColumn");
				if (refTable != null && refColumnName != null
						&& foreignKeyColumn != null) {
					referenceValues.put(foreignKeyColumn, refTable + ","
							+ refColumnName);
				} else {
					referenceValues = null;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return referenceValues;
	}
	
	/**
	 * @Description Extracts the table name from the respective query and
	 *              returns it
	 * @param query
	 * @param prefix
	 * @param postFix
	 * @return String - table name
	 */
	public static String getTableName(String query, String prefix,
			String postFix) {
		String tableName = null;
		Pattern pattern = Pattern.compile("(?<=" + prefix + ").*?(?=" + postFix
				+ ")");
		Matcher matcher = pattern.matcher(query);
		while (matcher.find()) {
			tableName = matcher.group().trim().toString();
		}
		return tableName;
	}


	/**
	 * @Description Inserts the sql query into db
	 * @param sqlCmd
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	public boolean insertTables(String sqlCmd) throws SQLException, Exception {
		int updated = 0;

		try {
		updated = connection.createStatement().executeUpdate(sqlCmd);

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Sql cmd inserted " + sqlCmd + "  " + updated);
		if (updated != 0) {
			return true;
		} else {
			return false;
		}

	}
	
	

	/**
	 * @Description Inserts the entire batch into the table
	 * @param insertQueries
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	public boolean insertBatchIntoTable(String[] insertQueries) throws SQLException, Exception {
		boolean isQueryExecuted = false;
		Statement stmt=null;
		try {
			stmt = connection.createStatement();
		
			for(String insertQuery:insertQueries)
			{
				stmt.addBatch(insertQuery);
				isQueryExecuted = true;
			}
			
			stmt.executeBatch();
			System.out.println("Inserted successfully***");
			
		} catch (SQLException se) {
			isQueryExecuted = false;
			se.printStackTrace();
		} catch (Exception e) {
			isQueryExecuted = false;
			e.printStackTrace();
		}
		finally {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		
		return isQueryExecuted;
	}

	/**
	 * @Description Check if a particular value exists in the respective table
	 * @param arr
	 * @return
	 * @throws SQLException
	 */
	public Boolean checkValueExists(ArrayList arr) throws SQLException {
		PreparedStatement stmt = null;
		String tableName = dbPrefix+arr.get(0);
		String query = "Select * FROM " + tableName + " WHERE " + arr.get(1)
				+ "=?";
		ResultSet rs = null;
		int updated = 0;
		try {
			stmt = connection.prepareStatement(query);
			stmt.setInt(1, Integer.parseInt(arr.get(2).toString()));
			//stmt.setString(1, arr.get(2).toString());
			rs = stmt.executeQuery();
			while (rs.next()) {
				updated = 1;
			}

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			rs.close();
			stmt.close();
		}

		if (updated != 0) {
			return true;
		} else {
			return false;
		}

	}

	// method to insert the random values and values from master look up table
	// given the table name
	/**
	 * @Description Method to build the insert query for a table record based on its meta data. Data is either retrieved from lookup table,DB or data factory
	 * @param tableName
	 * @param primaryKey
	 * @return
	 * @throws Exception
	 */
	public String buildRandomDataQuery(String tableName, String primaryKey)
			throws Exception {
		//tableName = dbPrefix+ tableName;
		String sqlQuery = "select * from " +dbPrefix+ tableName;
		String primaryColumnName = null;
		String primaryColumnValue = null;
		StringBuilder sb1 = null;

		Statement stmt = null;
		ResultSet rst = null;

		if (primaryKey != null) {
			String[] primaryValues = primaryKey.split("=");
			primaryColumnName = primaryValues[0];
			primaryColumnValue = primaryValues[1];
		}
		try {
			stmt = connection.createStatement();
			rst = stmt.executeQuery(sqlQuery);
			ResultSetMetaData metaData = rst.getMetaData();
			
			int columnCount = metaData.getColumnCount();

			String[] columnNamesType = new String[columnCount];
			String[] columnNames = new String[columnCount];

			for (int i = 1; i <= columnCount; i++) {

				columnNamesType[i - 1] = metaData.getColumnTypeName(i);
				columnNames[i - 1] = metaData.getColumnName(i);

			}

			sb1 = new StringBuilder("INSERT INTO " +dbPrefix+ metaData.getTableName(1)
					+ "(");

			for (int j = 0; j < columnCount; j++) {
				sb1.append(columnNames[j] + ",");
			}

			sb1.deleteCharAt(sb1.length() - 1);
			sb1.append(") VALUES(");

			for (int m = 0; m < 1; m++) {
				String columnType = "";
				String columnName = "";
				for (int l = 0; l < columnCount; l++) {
			
					columnType = columnNamesType[l].trim();
					columnName = columnNames[l].trim();
					
					////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					//To find out if there exists any constraint on the column
					
					Boolean isPrimary = false;
					Boolean isUnique = false;
					Boolean isForeign = false;
					Map<String,String> constraintsMap = getTableConstraints(tableName);
					
					if(constraintsMap.containsKey(columnName))
					{
						String value = constraintsMap.get(columnName);
						
						if(value.equalsIgnoreCase("PRIMARY KEY"))
						{
							isPrimary = true;
						}
						
						if(value.equalsIgnoreCase("UNIQUE KEY"))
						{
							isUnique = true;
						}
						
						if(value.equalsIgnoreCase("FOREIGN KEY"))
						{
							isForeign = true;
						}

					}
					

					
					/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
					if (l != 0) {
						sb1.append(",");
					}
					

					if (primaryColumnName != null
							&& columnName.equalsIgnoreCase(primaryColumnName)) {
						sb1.append(primaryColumnValue);

					} 
					//udpated o contains
					else {
						if (columnType.equalsIgnoreCase("VARCHAR")) {
							String generatedString;
							while(true)
							{
								if (columnName.equalsIgnoreCase("address")) {
									generatedString = dataFactory.getAddress();
								} else if (columnName.equalsIgnoreCase("firstName")) {
									generatedString = dataFactory.getFirstName();
								} else if (columnName.equalsIgnoreCase("lastName")) {
									generatedString = dataFactory.getLastName();
								} else if (columnName.equalsIgnoreCase("name")) {
									generatedString = dataFactory.getName();
								} else {
									String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);

									if (lookUpValue != null) {
										generatedString = lookUpValue;
									} else {
										generatedString = generateRandomString();
									}

								}
								
								generatedString = generatedString.replace("'","");
							//Check unique value
							if(isPrimary || isUnique)
							{
								List<String> dbList = getColumnListFromDB(tableName, columnName);
								
								if(dbList.contains(generatedString))
								{
									continue;
								}
								else
								{	
									sb1.append("'" + generatedString + "'");
									break;
								}
							}
							else
							{
								sb1.append("'" + generatedString + "'");
								break;
							}

						}
						}
						else if (columnType.equalsIgnoreCase("INT")) {
							int generatedInteger = 0;
							
							while(true)
							{

							/*	if (isPrimary) {
									
									
									generatedInteger = getColumnValuePrimaryKey(
											tableName, columnName);
								} else*/ if (isForeign) {
									generatedInteger = getColumnValueForeignKey(
											tableName, columnName);
								} else {
									String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);
									if (lookUpValue != null) {
										generatedInteger = Integer
												.parseInt(lookUpValue);
									} else {
										generatedInteger = getInteger();
									}
								}

								// Check unique value
								if (isPrimary || isUnique) {
									Boolean isPresent = false;
									/*List<String> dbList = getColumnListFromDB(
											tableName, columnName);
									for (String dbValue : dbList) {
										if (generatedInteger == Integer
												.parseInt(dbValue)) {
											isPresent = true;
											break;
										}
									}*/
									if(primarySet.contains(generatedInteger))
									{
										isPresent = true;
									}else
									{
										primarySet.add(generatedInteger);
									}
									
									if (isPresent)
									{
										continue;
									} else {
										sb1.append(generatedInteger);
										break;
									}
								} else {
									sb1.append(generatedInteger);
									break;
								}
							}

							/*String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);
							if (lookUpValue != null) {
								sb1.append(Integer.valueOf(lookUpValue));
							} else {
								sb1.append(getInteger());
							}*/

						} else if (columnType.equalsIgnoreCase("CHAR")) {
							String generatedChar;
							while(true)
							{
							String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);
							if (lookUpValue != null) {
								generatedChar=lookUpValue;
							} else {
								generatedChar = generateRandomString();
							}
							
							//Check unique value
							if(isPrimary || isUnique)
							{
								List<String> dbList = getColumnListFromDB(tableName, columnName);
								
								if(dbList.contains(generatedChar))
								{
									continue;
								}
								else
								{	
									sb1.append("'" + generatedChar + "'");
									break;
								}
							}
							else
							{
								sb1.append("'" + generatedChar + "'");
								break;
							}
							}						
							
							/*String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);

							if (lookUpValue != null) {
								sb1.append("'" + lookUpValue + "'");
							} else {
								sb1.append("'" + generateRandomString() + "'");
							}*/
						}
						else if (columnType.equalsIgnoreCase("DATE")
								|| columnType.contains("Date")) {
							String generatedDate;
							
							while(true)
							{
							String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);
							if (lookUpValue != null) {
								generatedDate = lookUpValue;
							} else {
								Date date = getDate();
								SimpleDateFormat sdf = new SimpleDateFormat(
										"yyyy-MM-dd");
								String formattedDate = sdf.format(date);
								generatedDate = formattedDate;			
							}
							
							//Check unique value
							if(isPrimary || isUnique)
							{
								List<String> dbList = getColumnListFromDB(tableName, columnName);
								
								if(dbList.contains(generatedDate))
								{
									continue;
								}
								else
								{	
									sb1.append("'" + generatedDate + "'");
									break;
								}
							}
							else
							{
								sb1.append("'" + generatedDate + "'");
								break;
							}
							
							}	
							
							/*String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);

							if (lookUpValue != null) {
								sb1.append("'" + lookUpValue + "'");
							} else {
								Date date = getDate();
								SimpleDateFormat sdf = new SimpleDateFormat(
										"yyyy-MM-dd");
								String formattedDate = sdf.format(date);
								sb1.append("'" + formattedDate+ "'");
							}
							*/
							
							
						}
						else if (columnType.equalsIgnoreCase("DATETIME")) {
							
							String generatedDateTime;
							
							while(true)
							{
							String lookUpValue = generateRandomDataFromMasterLookUpTable(columnName);
							if (lookUpValue != null) {
								generatedDateTime = lookUpValue;
							} else {
								SimpleDateFormat sdfDate = new SimpleDateFormat(
										"yyyy-MM-dd HH:mm:ss");// dd/MM/yyyy
								Date now = new Date();
								String currentDate = sdfDate.format(now);
								generatedDateTime = currentDate;			
							}
							
							//Check unique value
							if(isPrimary || isUnique)
							{
								List<String> dbList = getColumnListFromDB(tableName, columnName);
								
								if(dbList.contains(generatedDateTime))
								{
									continue;
								}
								else
								{	
									sb1.append("'" + generatedDateTime + "'");
									break;
								}
							}
							else
							{
								sb1.append("'" + generatedDateTime + "'");
								break;
							}
							}	
							
							
							/*SimpleDateFormat sdfDate = new SimpleDateFormat(
									"yyyy-MM-dd HH:mm:ss");// dd/MM/yyyy
							Date now = new Date();
							String currentDate = sdfDate.format(now);
							sb1.append("'" + currentDate + "'");*/
							
							
						} else if (columnType.equalsIgnoreCase("DOUBLE PRECISION")) {
							
							
							double generatedDouble;
							
							while(true)
							{
								Random randomGenerator = new Random();
								int randomInt = randomGenerator.nextInt();
								double randomFloat = Math.abs(randomGenerator.nextDouble() * randomInt);
								DecimalFormat df = new DecimalFormat(".###");
								generatedDouble = Double.parseDouble(df.format(randomFloat));
							
							//Check unique value
							if(isPrimary || isUnique)
							{
								List<String> dbList = getColumnListFromDB(tableName, columnName);
								
								if(dbList.contains(generatedDouble))
								{
									continue;
								}
								else
								{	
									sb1.append(generatedDouble);
									break;
								}
							}
							else
							{
								sb1.append(generatedDouble);
								break;
							}
							}	
							

							/*Random randomGenerator = new Random();
							int randomInt = randomGenerator.nextInt();
							double randomFloat = Math.abs(randomGenerator.nextDouble() * randomInt);
							DecimalFormat df = new DecimalFormat(".###");
							sb1.append(df.format(randomFloat));*/
						}
					}

				}
				sb1.append(")");
				//System.out.println("generated statement-------"+sb1);

			}

		} finally {
			stmt.close();
			rst.close();
		}

		return sb1.toString();

	}

	/**
	 * @Description Retrieves the last record in the corresponding table and increments its value by 1 and returns it
	 * @param tableName
	 * @param columnName
	 * @return
	 */
	private int getColumnValuePrimaryKey(String tableName, String columnName) {
		int lastValue = 0;
		String lastRecord = getLastRecord(tableName, columnName);
		if (lastRecord != null) {
			lastValue = Integer.parseInt(lastRecord)+1;
		}else
		{
			lastValue = 1;
		}

	return lastValue;
	}

	/**
	 * @Description Generates the value for the foreign key column based on the parent table values
	 * @param tableName
	 * @param columnName
	 * @param generatedInteger
	 * @return
	 */
	private int getColumnValueForeignKey(String tableName, String columnName) {
		int generatedInteger = 0;
		Map<String, String> refMap = checkReferences(tableName);
		for (String colNames : refMap.keySet()) {
			if (columnName
					.equalsIgnoreCase(colNames)) {
				String[] values = refMap.get(
						colNames).split(",");
				String refTableName = values[0];
				Boolean isEmpty = isTableEmpty(refTableName);
				if (isEmpty) {
					generatedInteger = getInteger();
				} else {
					generatedInteger = Integer.valueOf(getForeignKeyValue(refTableName,columnName));
				}
			}

		}
		return generatedInteger;
	}
	
	/**
	 * @Description Retrieves the last record value of the corresponding column
	 * @param tableName
	 * @param columnName
	 * @return
	 */
	private String getLastRecord(String tableName,String columnName)
	{
		Statement stmt = null;
		ResultSet rst= null;
		String lastValue = null;
		
		tableName = dbPrefix+ tableName;
		String query = "SELECT TOP 1 "+columnName+" FROM "+tableName+" ORDER BY "+columnName+" DESC";
		
		try
		{
			stmt = connection.createStatement();
			rst = stmt.executeQuery(query);
			
			
			while(rst.next())
			{
				lastValue = rst.getString(1);
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				rst.close();
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return lastValue;
	}
	
	
	/**
	 * @Description Retrieves the corresponding column data from DB and returns it
	 * @param tableName
	 * @param columnName
	 * @return
	 */
	private List<String> getColumnListFromDB(String tableName,String columnName)
	{
		Statement stmt = null;
		ResultSet rst= null;
		List<String> dbList = new ArrayList<String>();
		tableName = dbPrefix+ tableName;
		String query = "Select "+columnName+" FROM "+tableName;
		
		try
		{
		stmt = connection.createStatement();
		rst = stmt.executeQuery(query);
		
		while(rst.next())
		{
			dbList.add(rst.getString(1));
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return dbList;		
	}
	
	/**
	 * @Description Gives the names of the primary tables in the data model
	 * @param dataModel
	 * @return
	 */
	public Set<String> getPrimaryTable(String dataModel)
	{
		Set<String> parentTableNames = new HashSet<String>();
		Statement stmt = null;
		ResultSet rst= null;
		List<String> tableNameList = new ArrayList<String>();
		List<String> refTableNameList = new ArrayList<String>();
		//String referenceTableName = "idatagendb.dev2."+dataModel+"_MasterReferencesTable";
		String referenceTableName = "idatagendb.dev2."+MASTERREFERENCETABLE;
		
		String query = "Select TableName,ReferenceTable FROM "+referenceTableName+" WHERE DataModel = '"+dataModel+"'";
		
		try
		{
		stmt = connection.createStatement();
		rst = stmt.executeQuery(query);
		
		while(rst.next())
		{
			tableNameList.add(rst.getString(1));
			refTableNameList.add(rst.getString(2));
		}
		
		for(String tableName:tableNameList)
		{
			if(refTableNameList.contains(tableName))
			{
				continue;
			}
			else
			{
				parentTableNames.add(tableName);
			}
		}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return parentTableNames;
	}
	
	/**
	 * @Description Method to pick up the random value from the master look up table given the column name of look up table
	 * @param columnName
	 * @return
	 * @throws Exception
	 */
	public String generateRandomDataFromMasterLookUpTable(String columnName)
			throws Exception {
		Random randomNamesGenerator = new Random();
		ArrayList<Object> nameList = new ArrayList<Object>();
		String randomValue = null;
		if(lookUpMap.isEmpty())
		{
		lookUpMap = getLookupData(MASTERLOOKUPTABLE);
		}
		Set<String> masterColumns = lookUpMap.keySet();

		for (String column : masterColumns) {
			if (columnName.equalsIgnoreCase(column)) {

				if (lookUpMap.containsKey(column)) {
					nameList.addAll(lookUpMap.get(column));
				}

				int nameListSize = nameList.size();
				int index = randomNamesGenerator.nextInt(nameListSize);
				randomValue = nameList.get(index).toString();
				break;
			}
		}

		return randomValue;
	}

	// method to generate random Number
	public static int getRandomNumber() {
		int randomInt = 0;
		Random randomGenerator = new Random();
		randomInt = randomGenerator.nextInt(CHAR_LIST.length());

		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}
	}

	// method to generate random integer
	public int getInteger() {
		int randomInt = 0;
		randomInt = dataFactory.getNumberBetween(1,(int) Math.pow(2, 16));
		return randomInt;
	}

	// method to generate random String
	public String generateRandomString() {

		StringBuffer randStr = new StringBuffer();
		for (int i = 0; i < RANDOM_STRING_LENGTH; i++) {
			int number = getRandomNumber();
			char ch = CHAR_LIST.charAt(number);
			randStr.append(ch);
		}
		return randStr.toString();
	}

	public Date getDate() {
		Date date = new Date();
		Date minDate = dataFactory.getDate(2000, 1, 1);
		Date maxDate = new Date();

		date = dataFactory.getDateBetween(minDate, maxDate);

		return date;
	}

	public String getAddress() {
		String address = dataFactory.getAddress();
		return address;
	}

	// method to add the given column from master lookup table to a map given
	// master table name
	/**
	 * @Description Retrieves all the data from the look up table and returns it in a map
	 * @param masterTableName
	 * @return
	 * @throws Exception
	 */
	public Map<String, ArrayList<Object>> getLookupData(String masterTableName)
			throws Exception {
		masterTableName = dbPrefix+ masterTableName;
		String fetchMasterTable = "select * from " + masterTableName;
		Map<String, ArrayList<Object>> masterTableMap = new HashMap<String, ArrayList<Object>>();

		try {
			Statement stmt = connection.createStatement();
			ResultSet rst = stmt.executeQuery(fetchMasterTable);
			ResultSetMetaData metaData = rst.getMetaData();

			String[] masterColumnNames = new String[metaData.getColumnCount()];

			for (int m = 1; m <= metaData.getColumnCount(); m++) {
				masterColumnNames[m - 1] = metaData.getColumnName(m);
			}

			for (int n = 0; n < metaData.getColumnCount(); n++) {
				ArrayList<Object> namesList = new ArrayList<Object>();

				String fetchNamesQuery = "select " + masterColumnNames[n]
						+ " from " + masterTableName;
				stmt = connection.createStatement();
				rst = stmt.executeQuery(fetchNamesQuery);

				while (rst.next()) {
					if (rst.getString(1) != null) {
						namesList.add(rst.getString(1));
					}

				}
				//System.out.println(namesList);
				masterTableMap.put(masterColumnNames[n], namesList);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return masterTableMap;

	}
	
	
	/**
	 * @Description Exports the data from the table and writes it to a text file in the corresponding path
	 * @param tableName
	 * @param folderPath
	 * @return
	 */
	public Boolean writeTableDataToFile(String tableName,String folderPath)
	{
		File file;
        FileWriter fw;
        BufferedWriter bw;
        StringBuilder columnNames = new StringBuilder("");
        Statement stmt = null;
		ResultSet rst = null;
		String sqlQuery = "select * from " +dbPrefix+ tableName;
		try {
			 file = new File(folderPath+"\\\\"+tableName+".txt");
			 fw = new FileWriter(file.getAbsoluteFile());
			 bw = new BufferedWriter(fw);
	
			 stmt = connection.createStatement();
			 rst = stmt.executeQuery(sqlQuery);
			 
			 //Write Column Names to file
			 ResultSetMetaData metaData = rst.getMetaData();
			 int colCount = metaData.getColumnCount();
			 for (int i = 1; i <= colCount; i++) {
				String columnName = metaData.getColumnName(i);
				columnNames.append(columnName).append(",");
			}
			
			String fileHeader = columnNames.substring(0,columnNames.length()-1);
			//System.out.println("File header :  "+fileHeader);
			bw.write(fileHeader);
			bw.newLine();
			
			//Write Data to file
			while(rst.next())
			{
				StringBuilder dataString = new StringBuilder("");
				for (int i = 1; i <= colCount; i++) {
					String columnType = metaData.getColumnTypeName(i);
					if(columnType.equalsIgnoreCase("INT")||columnType.equalsIgnoreCase("double precision"))
					{
						dataString.append(rst.getString(i)).append(",");	
					
					}
					else
					{
						dataString.append("'").append(rst.getString(i)).append("'").append(",");
					}
					
					
				}
				String data = dataString.substring(0, dataString.length()-1);
				//System.out.println("Data Value: "+data);
				bw.write(data);
				bw.newLine();
				dataString = null;
			}
		       System.out.println("Data written to files");				
			bw.close(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				rst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return true;
	}
	
	/**
	 * @Description Truncates the corresponding table
	 * @param tableName
	 * @return
	 */
	public Boolean truncateDataModel(String tableName)
 {
		Statement stmt = null;
		String sqlQuery = "TRUNCATE TABLE " + dbPrefix + tableName;
		try {
			stmt = connection.createStatement();
			stmt.executeUpdate(sqlQuery);

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}
	
	/**
	 * @Description Checks whether the table is empty or not and returns the corresponding boolean value
	 * @param tableName
	 * @return
	 */
	public Boolean isTableEmpty(String tableName)
	{
		Statement stmt = null;
		ResultSet rs = null;
		int count = 0;
		Boolean isTableEmpty = false;
		String query = "SELECT CASE WHEN count(*)>0 THEN count(*) ELSE -1 END FROM "+dbPrefix+tableName;
		
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(query);
			
			while(rs.next())
			{
				count = rs.getInt(1);
			}
			
			if(count==-1)
			{
				isTableEmpty = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return isTableEmpty;
	}
	
	/**
	 * @Description Retrieves the reference tables of a particular table and returns them in a list
	 * @param tableName
	 * @return
	 */
	public List<String> getReferences(String tableName)
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;

		List<String> refTables = new ArrayList<String>();
		String referenceTableName = "idatagendb.dev2."+MASTERREFERENCETABLE;
		String query = "SELECT ReferenceTable FROM "+referenceTableName+ " WHERE TableName = ? ";
		
		try {
			stmt = connection.prepareStatement(query);
			stmt.setString(1, tableName);
			rs = stmt.executeQuery();

			while(rs.next())
			{
				refTables.add(rs.getString(1));
			}
			
			if(refTables.isEmpty() || refTables.contains(null))
			{
				refTables = null;
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
			return refTables;
	}
	
	/**
	 * @Description Get a random value from the corresponding column of the table 
	 * @param tableName
	 * @param columnName
	 * @return
	 */
	public String getForeignKeyValue(String tableName,String columnName)
 {
		List<String> columnList = new ArrayList<String>();
		String value = null;
		columnList = getColumnListFromDB(tableName, columnName);

		int listSize = columnList.size();
		if (listSize > 0) {
			int randomNumb = dataFactory.getNumberBetween(0, listSize);
			value = columnList.get(randomNumb);
		}

		return value;

	}
	
	/**
	 * @Description Drops the given table
	 * @param tableName
	 * @return
	 */
	public Boolean deleteTable(String tableName) {
		String DeleteTableQuery = "Drop Table " + dbPrefix + tableName;
		try {
			Statement stmt = connection.createStatement();
			//ResultSet rst = stmt.executeQuery(DeleteTableQuery);
			stmt.executeUpdate(DeleteTableQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		return true;
	}
	
	/**
	 * @Description Removes the rows corresponding to the table name and data model from the MasterReferencesTable
	 * @param dataModel
	 * @param tableName
	 * @return
	 */
	public Boolean removeTablesFromMasterRef(String dataModel,String tableName) {
		String referenceTableName = "idatagendb.dev2.MasterReferencesTable";
		String DeleteTableQuery = "DELETE FROM "+referenceTableName +" WHERE DataModel = '"+dataModel+"' AND TableName='"+tableName+"'";
		//delete from MasterReferencesTable where DataModel='dm9'
		try {
			Statement stmt = connection.createStatement();
			//ResultSet rst = stmt.executeQuery(DeleteTableQuery);
			stmt.executeUpdate(DeleteTableQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		return true;
	}
	

	public static void main(String args[]) {

		ConnectionDetail cd = new ConnectionDetail("BLRWFD6681.igatecorp.com",
				"5000", "GS_MGMT1", "dev2", "dev234");
		ConnectionManager cm = new ConnectionManager();
		Connection conn = cm.getConnection();

		/* dd.getAllUserTables(); */
		cm.closeConnection(conn);
		// List<ColumnDetail> l =
		// d.parseAndGetList("CREATE TABLE G111 (id INTEGER PRIMARY KEY AUTOINCREMENT, C1 CHAR (10), C2 CHAR (11), C3 CHAR (11))");
		// for (ColumnDetail tablecolumnDetail : l) {
		//
		// System.out.println(tablecolumnDetail.getColumnName()+" "+tablecolumnDetail.getColumnType());
		// }
	}

}
