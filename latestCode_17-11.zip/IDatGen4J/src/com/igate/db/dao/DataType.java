package com.igate.db.dao;

/*
 * In this interface all the data types are set for creating table 
 */
public interface DataType {

	/*String INTEGER = "INTEGER";
	String BIGINT = "BIGINT";
	String VARCHAR = "VARCHAR";
	String DATE = "DATE";
	String DATETIME = "DATETIME";*/
	
	String INT = "INT";	
	String VARCHAR = "VARCHAR(100)";
	String TIMESTAMP = "TIMESTAMP";
	String DATETIME = "DATETIME";
	String FLOAT = "FLOAT";
	String DATE = "DATE";
	
}
