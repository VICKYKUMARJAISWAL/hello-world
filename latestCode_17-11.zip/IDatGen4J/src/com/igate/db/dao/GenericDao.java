package com.igate.db.dao;

import java.util.List;

import com.igate.dto.ColumnDetail;

public interface GenericDao {

	public List<ColumnDetail>getTableInfo(String tableName);
}
