package com.igate.db.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.igate.db.manager.ConnectionManager;

public class GetRefDetailsDAO {

	/*public Map<String, List<String>> getEntity() {

		Map<String, List<String>> map = null;
		try {

			map = new HashMap<String, List<String>>();

			Connection conn = new ConnectionManager().getConnection();

			System.out.println("Connect");
			DatabaseMetaData md = conn.getMetaData();
			ResultSet rs = md.getTables(null, null, "%", null);

			while (rs.next()) {
				//
				String table_name = rs.getString(3);
				System.out.println("Table Name : " + rs.getString(3));

				// Create a result set
				Statement statement = conn.createStatement();
				ResultSet results = statement.executeQuery("SELECT * FROM "
						+ table_name);
				// Get resultset metadata
				ResultSetMetaData metadata = results.getMetaData();
				int columnCount = metadata.getColumnCount();
				System.out.println(table_name + " columns : " + columnCount);

				// Get the column names; column indices start from 1
				List<String> list = new ArrayList<String>();
				for (int i = 1; i <= columnCount; i++) {
					String columnName = metadata.getColumnName(i);
					list.add(columnName);
					System.out.println(columnName);
				}
				map.put(table_name, list);
				// list = null;

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return map;
	}*/

	/*
	 * To get all the tables from the database
	 */
	public static List<String> getTables() {

		List<String> list = null;
		Connection conn = null;
		try {

			list = new ArrayList<String>();
			conn = ConnectionManager.getConnection(); // new
			//System.out.println("Connect");
			String query = " select convert(varchar(100),o.name) AS table_name from idatagendb..sysobjects o where type = 'U' order by table_name";
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {

				//System.out.println("GetRefDetailsDAO Table Names----------" + rs.getString(1));
				list.add(rs.getString(1));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return list;
	}

	/*
	 * To get column names corresponding to the selected Table from combo box1
	 */

	public List<String> getColumnNames(String tableName) {

		List<String> list = new ArrayList<String>();
		Connection conn = null;
		try {
			conn = ConnectionManager.getConnection();
			
			String table_name = "idatagendb.."+tableName;
			System.out.println("Connect :" +tableName );
			
			Statement statement = conn.createStatement();
			
			ResultSet results = statement.executeQuery("SELECT * FROM  "+ table_name);//idatagendb..emptest"	);//
			// Get resultset metadata
			ResultSetMetaData metadata = results.getMetaData();
			int columnCount = metadata.getColumnCount();
			//System.out.println(" columns here GetRefDetailsDAO~~~~~~~~~~~~~~~~~~~~ : " + columnCount);

			// Get the column names; column indices start from 1
			
			for (int i = 1; i <= columnCount; i++) {
				String columnName = metadata.getColumnName(i);
				list.add(columnName);
				System.out.println(columnName);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return list;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*GetRefDetailsDAO ref = new GetRefDetailsDAO();
		Map<String, List<String>> map = ref.getEntity();
		System.out.println("Printing all table and column:---------------");
		for (String id : map.keySet()) {
			System.out.println(id);

			List<String> values = map.get(id);
			for (String value : values) {
				System.out.print(value + "\t");
			}
			System.out.println("\n");
		}

		List list1 = ref.getColumnNames("Employee");
		System.out.println("-------" + list1);*/
	}

}
