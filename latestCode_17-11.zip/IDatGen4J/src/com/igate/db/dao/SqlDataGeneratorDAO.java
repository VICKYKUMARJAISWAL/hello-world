package com.igate.db.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.igate.db.manager.ConnectionManager;

public class SqlDataGeneratorDAO {
	ConnectionManager conMgr = new ConnectionManager();
	String[] queries;
	Connection con;
	Statement stmt;

	public boolean executeBatchSqlFile(String[] strQueries) {
		boolean isQueryExecuted = false;
		this.queries = strQueries;
		try {
			con = conMgr.getConnection();
			stmt = con.createStatement();
			System.out.println("queries size :" + queries.length);
			for (String query : queries) {

				System.out.println("Query before executed : " + query);
				// JZ0BE: BatchUpdateException: Error occurred while executing
				// batch statement: Incorrect syntax near ';'.
				// Added to remove Exception
				query = query.replaceAll(";$", "");
				System.out.println("Query before executed removing semicolon: "
						+ query);

				stmt.addBatch(query);
				// stmt.executeBatch();
				isQueryExecuted = true;

				System.out.println("Query executed : " + query);

			}
			stmt.executeBatch();
		} catch (SQLException e) {
			{
				isQueryExecuted = false;
				e.printStackTrace();
				try {
					con.rollback();
				} catch (SQLException e1) {
					System.out.println("EXCEPTION WHILE ROLLING Back ");
					e1.printStackTrace();
				}
			}
		}
		// e.printStackTrace();
		finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				System.out.println("EXCEPTION : While closing the connection");
				e.printStackTrace();
			}

		}
		return isQueryExecuted;

	}
}
