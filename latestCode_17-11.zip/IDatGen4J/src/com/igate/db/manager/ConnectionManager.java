package com.igate.db.manager;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.management.openmbean.OpenDataException;


import com.sybase.jdbc3.jdbc.SybDriver;

public class ConnectionManager {
	private static SybDriver sybDriver = null;
	private static Connection conn = null;
	private static String url = null;
	
	private static String userName="dev2";
	private static String password="dev234";
	private static String serverName="blrwfd6681";
	private static String dbName="idatagendb";
	private static DatabaseMetaData dbmd;
	private static ResultSet resultSet;

	static{
		try {
			sybDriver = (SybDriver) Class.forName("com.sybase.jdbc3.jdbc.SybDriver").newInstance();
			System.out.println("Driver Loaded");
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection()  {
		//boolean flag=false;
		/*serverName = test.getServerName();
		dbName = test.getDbName();
		userName = test.getUserName();
		password = test.getPassword();*/
		
		url = "jdbc:sybase:Tds:"+serverName+":5000?ServiceName="+dbName;
		System.out.println("url "+url);
		try {
			conn = DriverManager.getConnection(url, userName, password);
			/*if(conn!= null){
				resultSet=conn.getMetaData().getCatalogs();*/
				/*while(resultSet.next()){
					//System.out.println("dbname "+resultSet.getString(1));
					if(resultSet.getString(1).equals(dbName)){
						//System.out.println("Database exixts");
						flag=true;
						break;
					}else{
						//System.out.println("Db doesnot exists");
						continue;
					}
				}*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//throw new Exception("Failed to connect");
		}
		return conn;
	}
	
	public void closeConnection(Connection connnecton){
		if( null != connnecton){
			try {
				connnecton.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			connnecton = null;
		}
	}
}
