package com.igate.dto;

import java.sql.Date;

import com.igate.constants.GroupType;

public class AssetClass extends GroupRecord{

	private int tableId;
	
	public AssetClass(GroupType gtype){
		super(gtype);
	}
	public AssetClass(String name, int parentId){
		super(GroupType.ASSETCLASS);		
		super.setName(name);
		super.setParentId(parentId);
	}
	public int getTableId() {
		return tableId;
	}
	public void setTableId(int tableId) {
		this.tableId = tableId;
	}
	
	
	
	
}
