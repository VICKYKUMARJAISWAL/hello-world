package com.igate.dto;

public class ColumnDetail {

	private String columnName;
	private String columnType;
	private String columnConstraint;
	private boolean isNullable = true;	
	private boolean isdbColumn = false;
	private boolean isdummy = false;
	private ColumnDetail mappedColumn;
	
	
	public boolean isdummy() {
		return isdummy;
	}

	public void setdummyAs(boolean isdummy) {
		this.isdummy = isdummy;
	}

	public ColumnDetail(){
		mappedColumn = null;
	}
	
	public void mappedTo(ColumnDetail dbcolumn){
		this.mappedColumn = dbcolumn;
	}
	
	public ColumnDetail getMappedColumn(){
		return mappedColumn;
	}
	
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getColumnType() {
		return columnType;
	}
	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}
	
	public String getColumnConstraint() {
		return columnConstraint;
	}

	public void setColumnConstraint(String columnConstraint) {
		this.columnConstraint = columnConstraint;
	}


	
	public boolean isNullable(){
		return this.isNullable;
	}
	
	public boolean isPresentInDB(){
		return isdbColumn;
	}
	public void setAsDbColumn(boolean dbcolumn){
		this.isdbColumn = dbcolumn;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((columnName == null) ? 0 : columnName.hashCode());
		result = prime * result
				+ ((columnType == null) ? 0 : columnType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ColumnDetail other = (ColumnDetail) obj;
		if (columnName == null) {
			if (other.columnName != null)
				return false;
		} else if (!columnName.equals(other.columnName))
			return false;
			
		return true;
	}
	
	
	public String toString(){
		return this.columnName;
	}
	
}
