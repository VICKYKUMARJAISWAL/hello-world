package com.igate.dto;

public class ConnectionDetail {

	private String userName;
	private String hostName;
	private String password;
	private String port;
	private String dbName;
	
	
	public ConnectionDetail(String hostName,String port,String dbName,String userName, String password) {
		super();
		this.userName = userName;
		this.hostName = hostName;
		this.password = password;
		this.port = port;
		this.dbName = dbName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	
	
	
	
	
	
}
