package com.igate.dto;

import com.igate.constants.FileType;

public class FileInputType {

	private String file;
	private String delimeter;
	private FileType fileType;
	
	
	
	public FileInputType(String file, String delimeter, FileType fileType) {
		super();
		this.file = file;
		this.delimeter = delimeter;
		this.fileType = fileType;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getDelimeter() {
		return delimeter;
	}
	public void setDelimeter(String delimeter) {
		this.delimeter = delimeter;
	}
	public FileType getFileType() {
		return fileType;
	}
	public void setFileType(FileType fileType) {
		this.fileType = fileType;
	}
	
	
}
