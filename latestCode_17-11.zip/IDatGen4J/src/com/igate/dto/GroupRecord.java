package com.igate.dto;

import java.sql.Date;

import com.igate.constants.GroupType;

public class GroupRecord {

	private int id;
	private String name;
	private int parentId;
	private Date creationDate;
	private String createdBy;
	private GroupType type;
	
	public GroupRecord(GroupType gtype){
		this.type = gtype;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getParentId() {
		return parentId;
	}
	public void setParentId(int parent_id) {
		this.parentId = parent_id;
	}
	
	public String toString(){
		return getName();
	}
	public void setType(GroupType gtype){
		this.type = gtype;
	}
	public GroupType getType(){
		return this.type;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

}
