package com.igate.mapper;

import java.util.List;

import com.idategen.data.reader.CSVFileReader;
import com.idategen.data.reader.DataResultSet;
import com.idategen.data.reader.FileReaderManager;
import com.igate.datagen.exceptions.InvalidFileFormatException;
import com.igate.dto.ColumnDetail;
import com.igate.dto.FileInputType;
import com.igate.service.ServiceManager;

public class DbAndFileMapper extends SourceDestinationMapper{

	//Outputs
	
	
	
	private List<ColumnDetail> mergedcolumn;
	private CompareResultDetail compareResultDetail;
	
	//Inputs
	private String tableName;
	private FileInputType fileInputType;
	ServiceManager sm;
	public DbAndFileMapper(String tableName,FileInputType inpufile,ServiceManager sm){
		this.fileInputType = inpufile;
		this.tableName = tableName;
		this.sm = sm;	
		
		//doProcess();
	}
	
	private CompareResultDetail compare(){
		
		
		return new CompareResultDetail();
	}
	
	
	public CompareResultDetail doProcess(){
		
		// Calculate the culumn detail
		compareResultDetail = new CompareResultDetail();
		compareResultDetail.setDestinationColumns(sm.getAllColumns(tableName));
		// read the file and get the data
		FileReaderManager frm;
		try {
			frm = new CSVFileReader(fileInputType.getFile(), fileInputType.getFileType(), fileInputType.getDelimeter());
			compareResultDetail.setSourceDataResult(frm.read()); 
						
		} catch (InvalidFileFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return compareResultDetail;
	}
	
		
}
