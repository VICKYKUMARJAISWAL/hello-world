package com.igate.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.text.TabExpander;

import com.idategen.data.reader.DataResultSet;
import com.idategen.data.writer.CSVFileWriter;
import com.idategen.data.writer.FileWriteManager;
import com.igate.constants.FileType;
import com.igate.constants.GroupType;
import com.igate.dao.factory.DaoFactory;
import com.igate.datagen.exceptions.AlterColumnException;
import com.igate.datagen.exceptions.InvalidFileFormatException;
import com.igate.db.command.DaoCommand;
import com.igate.db.manager.ConnectionManager;
import com.igate.db.manager.DaoManager;
import com.igate.dto.AssetClass;
import com.igate.dto.ColumnDetail;
import com.igate.dto.ConnectionDetail;
import com.igate.dto.FileInputType;
import com.igate.dto.GroupRecord;
import com.igate.mapper.CompareResultDetail;
import com.igate.mapper.DbAndExternalDbMapper;
import com.igate.mapper.DbAndFileMapper;
import com.igate.mapper.SourceDestinationMapper;
import com.sybase.jdbc3.utils.TruncationConverter;

public class ServiceManager {

	DaoManager dm;
	ConnectionDetail externalDbConnectiondetail;
	
	String dbPrefix = "idatagendb.dev2.";
	Boolean isGenerated = false;

	private static Map<String, String> dependencyMap = new LinkedHashMap<String, String>();
	private static Map<String, Integer> dependencyTablesMap = new LinkedHashMap<String, Integer>();

	public ServiceManager() {
		dm = DaoFactory.createDaoManager();
	}

	public ServiceManager(ConnectionDetail conndetail) {
		this.externalDbConnectiondetail = conndetail;
		dm = DaoFactory.createDaoManager(conndetail);
	}

	public String testConnection(ConnectionDetail connnectioninfo) {
		ConnectionManager cm = new ConnectionManager();
		Connection conn = cm.getConnection();
		if (null == conn)
			return "failure";
		else {
			cm.closeConnection(conn);
		}
		return "sucess";
	}

	/*
	 * public String[] getAllTabble(){
	 * 
	 * }
	 */

	public List<GroupRecord> getAllParentGroups() {

		List<GroupRecord> glist = (List<GroupRecord>) dm
				.executeAndClose(new DaoCommand() {

					@Override
					public Object execute(DaoManager daoManager) {
						// TODO Auto-generated method stub
						return daoManager.getGroupDAO()
								.getAllSubCategoryById(0);
					}
				});
		return glist;
	}

	public List<GroupRecord> getAllGroupItems() {

		List<GroupRecord> glist = (List<GroupRecord>) dm
				.executeAndClose(new DaoCommand() {

					@Override
					public Object execute(DaoManager daoManager) {
						// TODO Auto-generated method stub
						return daoManager.getGroupDAO().getAllGroupRecords();
					}
				});
		return glist;
	}

	public GroupRecord addGroup(final String gname) {

		GroupRecord gr = (GroupRecord) dm.executeAndClose(new DaoCommand() {

			@Override
			public Object execute(DaoManager daoManager) {
				// TODO Auto-generated method stub
				GroupRecord gr = new GroupRecord(GroupType.GROUP);
				gr.setName(gname);
				gr.setParentId(0);
				return daoManager.getGroupDAO().addGroup(gr);
			}
		});
		return gr;
	}

	public GroupRecord addSubGroup(final GroupRecord parentgroup,
			final String subgroupname) {
		GroupRecord gr = (GroupRecord) dm.executeAndClose(new DaoCommand() {

			@Override
			public Object execute(DaoManager daoManager) {
				// TODO Auto-generated method stub
				GroupRecord subgroup = new GroupRecord(GroupType.GROUP);
				subgroup.setName(subgroupname);
				subgroup.setParentId(parentgroup.getId());
				return daoManager.getGroupDAO().addGroup(subgroup);
			}
		});
		return gr;
	}

	public GroupRecord addAssetClass(final GroupRecord parentgroup,
			final String assetclassname) {
		GroupRecord asetclass = (GroupRecord) dm
				.executeAndClose(new DaoCommand() {

					@Override
					public Object execute(DaoManager daoManager) {
						// TODO Auto-generated method stub
						GroupRecord aclass = new AssetClass(assetclassname,
								parentgroup.getId());
						// aclass.setName(assetclassname);
						// aclass.setParentId(parentgroup.getId());
						aclass.setType(GroupType.ASSETCLASS);
						return daoManager.getGroupDAO().addAssetClass(aclass);
					}
				});
		return asetclass;
	}

	public List<List<String>> getAssetData(final List<ColumnDetail> columnlist,
			final List params, final String tablename) {

		List<List<String>> assetdata = (List<List<String>>) dm
				.executeAndClose(new DaoCommand() {

					@Override
					public Object execute(DaoManager daoManager) {
						// TODO Auto-generated method stub
						// GroupRecord aclass = new
						// AssetClass(assetclassname,parentgroup.getId());
						// aclass.setName(assetclassname);
						// aclass.setParentId(parentgroup.getId());
						// aclass.setType(GroupType.ASSETCLASS);
						return daoManager.getGroupDAO().getDataList(columnlist,
								params, tablename);
					}
				});
		return assetdata;
	}

	public List<ColumnDetail> getAllColumns(final String tablename) {
		List<ColumnDetail> glist = dm.getDDLDAO().getTableInfo(tablename);
		return glist;
	}

	public CompareResultDetail doCompareAndGetResult(String tablename,
			String filepath, String delm, FileType ftype) {
		FileInputType inputype = new FileInputType(filepath, delm, ftype);
		DbAndFileMapper dfmapper = new DbAndFileMapper(tablename, inputype,
				this);
		return dfmapper.doProcess();
	}

	public CompareResultDetail doCompareWithExternDBAndGetResult(
			String assettablename, String command) {
		// FileInputType inputype = new FileInputType(filepath, delm, ftype);
		SourceDestinationMapper dfmapper = new DbAndExternalDbMapper(
				assettablename, this, command);
		return dfmapper.doProcess();
	}

	public DataResultSet executeCommandAndgetDataResultSet(final String command) {
		try {
			DataResultSet drs = (DataResultSet) dm
					.executeAndCloseExternalCommand(new DaoCommand() {

						@Override
						public Object execute(DaoManager daoManager) {
							return daoManager.getExternalDAO()
									.executeCommandAndgetDataResultSet(command);
						}
					});
			return drs;
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}

	public List<Integer> uploadData(final List<ColumnDetail> filecolumnlist,
			final DataResultSet filedata, final String tablename) {
		try {
			List<Integer> glist = (List<Integer>) dm
					.executeAndClose(new DaoCommand() {

						@Override
						public Object execute(DaoManager daoManager) {
							// TODO Auto-generated method stub
							try {
								return daoManager.getGroupDAO().uploadRecords(
										filecolumnlist, filedata, tablename);
							} catch (AlterColumnException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								return null;
							}
						}
					});
			return glist;
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}

	public void exportIntoFile(FileType filetype, String delim,
			Vector<Vector<Object>> datavector, List<ColumnDetail> columnlist,
			String filepath) {
		FileInputType inputype = new FileInputType(filepath, delim, filetype);
		FileWriteManager fwm = null;
		try {
			fwm = new CSVFileWriter(filepath, filetype, delim, datavector,
					columnlist);
			fwm.export();
		} catch (InvalidFileFormatException ifx) {
			ifx.printStackTrace();
		}
		// get the object by filetype
	}

	/**
	 * @Description retrieves the metaData of the table from the dao and returns
	 *              the same
	 * @param tableName
	 * @return
	 */
	public List<ColumnDetail> getMetaData(String tableName) {
		Map<String, String> metaDataMap = new HashMap<String, String>();
		Map<String, String> constraintsMap = new HashMap<String, String>();
		List<ColumnDetail> metaDataList = new ArrayList<ColumnDetail>();

		try {
			//Method for getting result set 
			metaDataMap = dm.getDDLDAO().getMetaData(tableName);
			
			//Method for getting the constraints
			constraintsMap = dm.getDDLDAO().getTableConstraints(tableName);
			
			for (Map.Entry<String, String> metaData : metaDataMap.entrySet()) {
				ColumnDetail columnDetails = new ColumnDetail();
				columnDetails.setColumnName(metaData.getKey());
				columnDetails.setColumnType(metaData.getValue());
				
				Set<String> constraintsColumns = constraintsMap.keySet();
				for(String constraintColumn:constraintsColumns)
				{
					if(metaData.getKey().equalsIgnoreCase(constraintColumn))
					{
						columnDetails.setColumnConstraint(constraintsMap.get(constraintColumn));
					}
				}
				
				metaDataList.add(columnDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return metaDataList;
	}

	public static void main(String args[]) {

		ConnectionDetail cd = new ConnectionDetail("BLRWFD6681.igatecorp.com",
				"5000", "GS_MGMT1", "dev2", "dev234");
	}

	// retrieves the records from the file uploaded
	public String[] getRecordsFromFile(String fileName) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(
				new FileInputStream(fileName)));
		StringBuilder sqlString = new StringBuilder("");
		String headerString = null;
		String line;

		int index = 0;
		while ((line = br.readLine()) != null) {
			if (index == 0) {
				headerString = line;
			} else {
				sqlString = sqlString.append(line).append(";");
			}
			index++;
		}
		br.close();

		return new String[] { headerString, sqlString.toString() };
	}

	/**
	 * @Description Builds the insert query from the records in flat file.
	 *              Assume file name is same as table name
	 * @param fileName
	 * @throws Exception
	 * @throws SQLException
	 */
	public Boolean buildInsertQuery(String filePath, String tableName)
			throws SQLException, Exception {

		String records[] = getRecordsFromFile(filePath);
		String headerString = records[0];
		String recordValues = records[1];
		String[] values = recordValues.split(";");
		for (String rec : values) {
			String insertQuery = "INSERT INTO " + dbPrefix+tableName + "("
					+ headerString + ") " + "VALUES(" + rec + ")";
			insertValues(insertQuery, 0);
		}

		return true;
	}
	
	
	/**
	 * @Description Inserts data as batches into the table by handling its corresponding references
	 * @param tableName
	 * @param noOfRec
	 * @return
	 * @throws Exception
	 */
	public Boolean insertValuesInBatches(String tableName,int noOfRec) throws Exception
	{
		Boolean isInserted = false;
		List<String> refTables = dm.getDDLDAO().getReferences(tableName);
		if (!dependencyTablesMap.containsKey(tableName)) {
			dependencyTablesMap.put(tableName,noOfRec);
		}
		
		if(refTables == null || refTables.isEmpty())
		{
			isInserted = generateRandomBatch(tableName, noOfRec);
			if (isInserted) {
				dependencyTablesMap.remove(tableName);
			}
		}
		else
		{
			int noOfReferences = refTables.size();
			
			for(String refTable:refTables)
			{
				/*Object parentTable = dependencyTablesMap.keySet().toArray()[0];
				noOfRec = dependencyTablesMap.get(parentTable);*/
				for(String table:dependencyTablesMap.keySet()){
					noOfRec = dependencyTablesMap.get(table);
					break;
				}
				int noOfRecords = (noOfRec*10)/100;
				if(dm.getDDLDAO().isTableEmpty(refTable))
				{
					isInserted = insertValuesInBatches(refTable, noOfRecords);
				}
				if(isInserted)
				{
					continue;	
				}
				noOfReferences--;		
			}
			
			if(noOfReferences==0)
			{
				isInserted = generateRandomBatch(tableName,dependencyTablesMap.get(tableName));
				if (isInserted) {
					dependencyTablesMap.remove(tableName);
				}
			}
			
			if (!dependencyTablesMap.isEmpty()) {
				ListIterator<Map.Entry<String, Integer>> iterator = new ArrayList<Map.Entry<String, Integer>>(
						dependencyTablesMap.entrySet()).listIterator(dependencyTablesMap
						.size());

				
				while(iterator.hasPrevious())
				{
					Map.Entry<String, Integer> tableMap = iterator.previous();
					isInserted = insertValuesInBatches(tableMap.getKey(), tableMap.getValue());
					if (isInserted == true) {
						break;
					}
				}
				
			}
			
			
		}
		
		return isInserted;
	}

	/**
	 * @Description Inserts the record into table after checking all the
	 *              necessary conditions
	 * @param noOfRecs TODO
	 * @throws SQLException
	 * @throws Exception
	 */
	public Boolean insertValues(String insertQuery, int noOfRecs) throws SQLException,
			Exception {

		Boolean isInserted = false;
		String tableName = null;
		ArrayList<String> arr = new ArrayList<String>();
		Map<String, String> referenceTable = new HashMap<String,String>();

		tableName = getTableName(insertQuery, "INTO", "\\(");

		referenceTable = checkReferences(tableName);

		if (!dependencyMap.containsKey(tableName + "Map")) {
			dependencyMap.put(tableName + "Map", insertQuery);
		}

		if (referenceTable == null || referenceTable.isEmpty()) {
			isInserted = dm.getDDLDAO().insertTables(insertQuery);
			if (isInserted) {
				dependencyMap.remove(tableName + "Map");
			}
		} else {
			int noOfReferences = referenceTable.size();
			for (Map.Entry<String, String> ref : referenceTable.entrySet()) {

				String foreignKeyColumn = ref.getKey();
				String referenceData = ref.getValue();

				String refColumnValue = getReferenceValue(insertQuery,
						foreignKeyColumn);

				String[] refValues = referenceData.split(",");
				arr.add(0, refValues[0]);
				arr.add(1, refValues[1]);
				arr.add(2, refColumnValue);

				Boolean valueExists = dm.getDDLDAO().checkValueExists(arr);
				System.out.println(valueExists);

				noOfReferences = noOfReferences - 1;

				if (valueExists) {
					if (noOfReferences != 0) {
						continue; // Does not let you insert unless all the
									// references exist
					}
					isInserted = dm.getDDLDAO().insertTables(insertQuery);

					if (isInserted) {
						dependencyMap.remove(tableName + "Map");
					}
				} else {
					
					//Generate random records for the dependent table
					
					String refTable = refValues[0];
					int noOfRecords = (noOfRecs*10)/100;
					
					if(dm.getDDLDAO().isTableEmpty(refTable))
					{
					Boolean isGenerated = generateRandomRecords(refTable, noOfRecords);
					}
					
					String insertDependantQuery = dm.getDDLDAO()
							.buildRandomDataQuery(refTable,
									refValues[1] + "=" + refColumnValue);
					insertValues(insertDependantQuery, noOfRecs);

				}

			}

			if (!dependencyMap.isEmpty() && isGenerated==true) {
				ListIterator<Map.Entry<String, String>> iterator = new ArrayList<Map.Entry<String, String>>(
						dependencyMap.entrySet()).listIterator(dependencyMap
						.size());

				while (iterator.hasPrevious()) {
					Map.Entry<String, String> tableMap = iterator.previous();

					if (tableMap.getValue() != null) {
						Boolean returnValue = insertValues(tableMap.getValue(), noOfRecs);
						if (returnValue == true) {
							break;
						}
					}
				}
			}
		}
		return true;
	}

	/**
	 * @Description Extracts the table name from the respective query and
	 *              returns it
	 * @param query
	 * @param prefix
	 * @param postFix
	 * @return String - table name
	 */
	public static String getTableName(String query, String prefix,
			String postFix) {
		String tableName = null;
		Pattern pattern = Pattern.compile("(?<=" + prefix + ").*?(?=" + postFix
				+ ")");
		Matcher matcher = pattern.matcher(query);
		while (matcher.find()) {
			tableName = matcher.group().trim().toString();
		}
		return tableName;
	}

	/**
	 * @Description checks if references exist for the given table and retrieves
	 *              them
	 * @param tableName
	 * @return
	 */
	private Map<String, String> checkReferences(String tableName) {
		Map<String, String> referenceTable = dm.getDDLDAO().checkReferences(
				tableName);

		return referenceTable;
	}

	/**
	 * @Description Gets the value of the foreign key which has to be inserted
	 * @param insertQuery
	 * @return
	 */
	public static String getReferenceValue(String insertQuery,
			String foreignKeyColumn) {
		int index = 0;
		int columnIndex = 0;
		List<String> subStrings = new ArrayList<String>();

		Pattern pattern = Pattern.compile("\\(([^)]*)\\)");
		Matcher matcher = pattern.matcher(insertQuery);
		while (matcher.find()) {
			subStrings.add(matcher.group(1));
		}

		String headerString = subStrings.get(0).toString();
		String dataString = subStrings.get(1).toString();

		String[] headerColumns = headerString.split(",");
		for (String columnName : headerColumns) {
			if (foreignKeyColumn.equalsIgnoreCase(columnName)) {
				columnIndex = index;
			} else {
				index++;
			}
		}

		String[] dataColumn = dataString.split(",");
		System.out.println(dataColumn[columnIndex]);
		return dataColumn[columnIndex];

	}
	
	/**
	 * @Description Retrieves the primary tables of the dataModel and generates records. Then calls function to write the DB records to the file
	 * @param dataModel
	 * @param noOfRec
	 * @param folderPath
	 * @return
	 */
	public Boolean generateRecords(String dataModel,int noOfRec,String folderPath)
	
	{
		long starttime = System.currentTimeMillis();
		Boolean isGenerated = false;
		//Truncate the data model
		if(dataModel!=null)
		{
		truncateDataModel(dataModel);
		}
		
		Set<String> tableNameList = dm.getDDLDAO().getPrimaryTable(dataModel);
		try {
			for(String tableName:tableNameList)
			{
			isGenerated = insertValuesInBatches(tableName,noOfRec);
			// isGenerated = generateRandomRecords(tableName,noOfRec);
			}
			long insertingTime = System.currentTimeMillis();
			System.out.println("Insertion time--"+(insertingTime-starttime));
			writeTableDataToFile(dataModel,folderPath);
		} catch (Exception e) {
			e.printStackTrace();
			isGenerated = false;
		}
		long endtime = System.currentTimeMillis();
		System.out.println("ConsumedTime--"+(endtime-starttime));
		return isGenerated;
	}
	
	/**
	 * @Description Generates random records based on the tableName input and inserts them into the DB, one at a time
	 * @throws Exception
	 * @Description Inserts the records randomly generated using the data
	 *              generator
	 */
	public Boolean generateRandomRecords(String tableName,int noOfRec)
			throws Exception {
		isGenerated = false;
		int counter = noOfRec;
		for (int i = 0; i < noOfRec; i++) {
			String insertQuery = dm.getDDLDAO().buildRandomDataQuery(tableName,null);
			
			Boolean isInserted = insertValues(insertQuery, noOfRec);

			if(isInserted==true)
			{
				counter--;
				continue;
			}
			else
			{
				i--;
				continue;
			}
		}
		if(counter==0)
		{
			isGenerated = true;
		}
		//Write table data to file
		return isGenerated;
	}
	
	/**
	 * @Description Generates the insert queries depending and inserts them as a batch
	 * @param tableName
	 * @param noOfRec
	 * @return
	 * @throws Exception
	 */
	public Boolean generateRandomBatch(String tableName,int noOfRec) throws Exception
	{
		Boolean isInserted = false;
		List<String> queryList = new ArrayList<String>();
		for (int i = 0; i < noOfRec; i++) {
			String insertQuery = dm.getDDLDAO().buildRandomDataQuery(tableName,null);
			queryList.add(insertQuery);
		}
		
		Boolean isTruncated = dm.getDDLDAO().truncateDataModel(tableName);
		if(isTruncated)
		{
		String[] insertQueries = queryList.toArray(new String[queryList.size()]);
		isInserted = dm.getDDLDAO().insertBatchIntoTable(insertQueries);
		}
		
		return isInserted;
	}
	
	/**
	 * @Description Calls DAO layer function to get tables of a particular data model
	 * @param dataModel
	 * @return
	 */
	public Set<String> getTables(String dataModel) {
		Set<String> tableNameList = dm.getDDLDAO().getTables(dataModel);

		return tableNameList;
	}
	
	
	/**
	 * @Description Retrieves the list of primary tables in the data model
	 * @param dataModel
	 * @return Set<String>
	 */
	public Set<String> getPrimaryTable(String dataModel)
	{
		Set<String> primaryTablesList = dm.getDDLDAO().getPrimaryTable(dataModel);

		return primaryTablesList;
	}

	/**
	 * @Description Retrieves the tables of the data model and exports the table data into its corresponding file.
	 * @param dataModel
	 * @param folderPath
	 */
	public void writeTableDataToFile(String dataModel,String folderPath) {
		Set<String> tableNameList = dm.getDDLDAO().getTables(dataModel);
		for (String tableName : tableNameList) {
			dm.getDDLDAO().writeTableDataToFile(tableName,folderPath);
		}
	}

	/**
	 * @Description Extracts the header column names and column data from the query
	 * @param randomRecordsList
	 * @return
	 * @throws Exception
	 */
	public String[] displayRandomRecords(List<String> randomRecordsList)
			throws Exception {
		StringBuilder sqlString = new StringBuilder("");
		String headerString = null;
		String dataString = null;

		for (String insertQuery : randomRecordsList) {
			List<String> subStrings = new ArrayList<String>();
			Pattern pattern = Pattern.compile("\\(([^)]*)\\)");
			Matcher matcher = pattern.matcher(insertQuery);
			while (matcher.find()) {
				subStrings.add(matcher.group(1));
			}

			headerString = subStrings.get(0).toString();
			dataString = subStrings.get(1).toString();
			sqlString.append(dataString + ";");
		}
		return new String[] { headerString, sqlString.toString() };
	}

	/**
	 * @Description Compares the column names of the table in DB with the column
	 *              names in file and returns true if both are same
	 * @param fileName
	 * @param tableName
	 * @return
	 */
	public Boolean doCompareFileAndDb(String fileName, String tableName) {
		String records[];
		Boolean isCompatible = true;
		try {
			records = getRecordsFromFile(fileName);
			String headerString = records[0];
			String[] fileColumnNames = headerString.split(",");

			List<ColumnDetail> metaDataList = getMetaData(tableName);
			List<String> dbColumnNames = new ArrayList<String>();

			for (ColumnDetail columnDetail : metaDataList) {
				dbColumnNames.add(columnDetail.getColumnName());
			}

			for (String fileColumnName : fileColumnNames) {
				if (dbColumnNames.contains(fileColumnName)) {
					continue;
				} else {
					isCompatible = false;
					break;
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return isCompatible;
	}
	
	/**
	 * @Description Extracts the data Model names and retruns them in a set
	 * @return
	 */
	public Set<String> getDataModels()
	{
			Set<String> modelNames = dm.getDDLDAO().getDataModels();
			return modelNames;
	}
	
	/**
	 * @Description Retrieves the tables of a particular data model and truncates all the tables.
	 * @param dataModel
	 */
	public void truncateDataModel(String dataModel)
	{
		Set<String> tableList = dm.getDDLDAO().getTables(dataModel);
		
		for(String tableName:tableList)
		{
			dm.getDDLDAO().truncateDataModel(tableName);
		}
		
		
	}
	
	
	/**
	 * @Description Drops the given table 
	 * @param tableName
	 * @return
	 */
	public Boolean deleteTable(String tableName) {
		Boolean isDropped = dm.getDDLDAO().deleteTable(tableName);
		return isDropped;
	}
	
	/**
	 * @Description Removes the rows corresponding to the table name and data model from the masterReference table
	 * @param dataModel
	 * @param tableName
	 * @return
	 */
	public Boolean removeTablesFromMasterRef(String dataModel,String tableName){
		Boolean isRemoved=dm.getDDLDAO().removeTablesFromMasterRef(dataModel,tableName);
		return isRemoved;
		
	}
	
	
/*	public void truncateDataModel(String dataModel)
	{
		Set<String> tableList = dm.getDDLDAO().getTables(dataModel);
		List<String> truncatedTables = new ArrayList<String>();
		int noOfTables = truncatedTables.size();
		
		for(String tableNames:tableList)
		{
			truncatedTables.add(tableNames);
		}
		
		for(int i=0;i<noOfTables;i++)
		{
		for(String tableName:tableList)
		{
			Boolean isTruncated = dm.getDDLDAO().truncateDataModel(tableName);
			if(isTruncated)
			{
				truncatedTables.remove(tableName);
			}
			else
			{
				continue;
			}
		
			
		}
		}

	}
*/
}
