package com.test;

import java.awt.SecondaryLoop;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Date;

public class ReflectionTest {

	
	
	public static void main(String args[]) throws InterruptedException{
		
		try {
			Class clazz = Class.forName("java.lang.String");
			Constructor[] cons = clazz.getConstructors();
			for(int i = 0; i < cons.length; i++){
				System.out.println(cons[i].getName());
			}
			
			Method[] methods = clazz.getMethods();
			for(int i = 0; i < methods.length; i++){
				System.out.println(methods[i].getName());
				Method method = methods[i];
				//method.
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Date sd = new Date();
		String cmd = "select * from MAT_DB_LANGUAGE sc";
		String substr =cmd.substring(cmd.lastIndexOf("from")+"from".length()).trim() ;
		String tname = substr.split("\\s+")[0];
		System.out.println("tnam = "+tname);
		System.out.println("substr = "+substr);
		
		String s = "xyz123";
		System.out.println(s.toUpperCase());
		
		
		
		
//		for(int i = 0; i < 1000000; i++){
//			System.out.println(""+i);
//		}
//		Date ed = new Date();
//		System.out.println((ed.getTime() - sd.getTime())/1000);
		
		//long sec = (ed.getTime() - sd.getTime())/1000;
		//System.out.println("diff = "+sec);
				
				
	}
}
