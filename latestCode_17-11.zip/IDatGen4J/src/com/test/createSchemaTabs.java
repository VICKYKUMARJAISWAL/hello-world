package com.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import org.sqlite.SQLiteDataSource;
import org.sqlite.SQLiteJDBCLoader;

public class createSchemaTabs {
	
	

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String schemaFile = "D:/schema.sql";
		
		String[] sqlCmds = readSql(schemaFile);
		
		createTable(sqlCmds);
		
		referenceChk(sqlCmds);
		
		//insertTables();
		
		
		

	    //String tableName = "records";

	  //  List<String> columnNames = BUDataColumnsFinder.getColumnNames(tableName, schemaFile);

	}
	
	
	public static String[] readSql(String schema) throws IOException {
	    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(schema)));
	    String sqlString = "";
	    String line;
	    while ((line = br.readLine()) != null) {
	    	sqlString = sqlString + line;
	    }
	    br.close();
	    sqlString = sqlString.replaceAll("`", "");
	    System.out.println("Schema File Lines: "+sqlString);
	    //return sqlString;
	    String sqlSubs[] = sqlString.split(";");
	    return sqlSubs;
	}
	
	
	//Function to chk for references keyword
	
	public static void referenceChk(String[] sqlsubs){
		
		for(int i=0;i<sqlsubs.length;i++)
		{
			if(sqlsubs[i].contains("REFERENCES")){
				System.out.println(sqlsubs[i]);
			}
			else
				System.out.println(sqlsubs[i]);
		}
	}

	public static  Connection connected() throws Exception {
        boolean initialize = SQLiteJDBCLoader.initialize();

        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl("jdbc:sqlite:D:/idatagen/idatagendb.db");
        Connection conn = dataSource.getConnection();
        System.out.println("connected");
        return conn;

    }
	
	
	public static boolean createTable(String[] sqlCmds) throws SQLException, Exception{
		
		try
		{
			Connection conn = connected();
			for(int i=0;i<sqlCmds.length;i++)
			conn.createStatement().executeUpdate(sqlCmds[i]);
			
		}catch(SQLException se)
		{ 
			se.printStackTrace();
		}
		catch(Exception e)
		{ 
			e.printStackTrace();
		}
		return true;
		
	}
	
	
	
}
