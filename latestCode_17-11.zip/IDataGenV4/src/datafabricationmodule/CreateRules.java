/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datafabricationmodule;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import tdg.MainFrame;

/**
 *
 * @author sh834131
 */
public class CreateRules extends javax.swing.JPanel {

    static CreateRules myCreateRules = null;
    
    public static CreateRules getInstance(){
        if(myCreateRules == null){
            myCreateRules = new CreateRules();
        }
        return(myCreateRules);
    }
   
    
    public void reload(){
    	//myCreateRules = new CreateRules();
    	ruleList = new ArrayList<>();
    	// toTalNoOfLength = t;
    	 lengthCompleted = 0;
    	 curselectionitem = 0;
    	 rulePanelYOffset = 30;
    	 panelCounter = 0;
    	 initgroups();
    	 dataPanel.removeAll();
    	 generateSampleTextField.setText("");
    	 InitDataPanel();
         ruleList.add(entryPanel1);
    }
    
    /**
     * Creates new form CreateRules
     */
    private CreateRules() {
        initComponents();
        //initgroups();
    }
    
    
    
    private void InitDataPanel(){
    	initgroups();
    	//javax.swing.GroupLayout dataPanelLayout = new javax.swing.GroupLayout(dataPanel);
    	 //entryPanel1 = new datafabricationmodule.EntryPanel(toTalNoOfLength-lengthCompleted);
    	removeButton = new JButton();
    	addButton = new JButton();
    	
    	
    	 removeButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
         removeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("minus.png"))); // NOI18N
         removeButton.setPreferredSize(new java.awt.Dimension(18, 18));
         removeButton.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 removeButtonActionPerformed(evt);
             }
         });

         addButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
         addButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("plus.png"))); // NOI18N
         addButton.setPreferredSize(new java.awt.Dimension(18, 18));
         addButton.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 addButtonActionPerformed(evt);
             }
         });
    	
    	javax.swing.GroupLayout buttonsPanelLayout = new javax.swing.GroupLayout(buttonsPanel);
        buttonsPanel.setLayout(buttonsPanelLayout);
        buttonsPanelLayout.setHorizontalGroup(
            buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(buttonsPanelLayout.createSequentialGroup()
                .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(removeButton, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        buttonsPanelLayout.setVerticalGroup(
            buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(buttonsPanelLayout.createSequentialGroup()
                .addGroup(buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(removeButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );

        buttonsPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {addButton, removeButton});

    	
      entryPanel1 = new datafabricationmodule.EntryPanel();
      entryPanel1.setBackground(new java.awt.Color(0, 102, 153));
      dataPanel.setLayout(dataPanelLayout);
      dataPanelLayout.setHorizontalGroup(
          dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addGroup(dataPanelLayout.createSequentialGroup()
              .addGap(273, 273, 273)
              .addComponent(entryPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(buttonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
              .addContainerGap(389, Short.MAX_VALUE))
      );
      dataPanelLayout.setVerticalGroup(
          dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
          .addGroup(dataPanelLayout.createSequentialGroup()
              .addGap(36, 36, 36)
              .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                  .addComponent(buttonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                  .addComponent(entryPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
              .addContainerGap(1139, Short.MAX_VALUE))
      );

      dataPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {buttonsPanel, entryPanel1});

      jScrollPane1.setViewportView(dataPanel);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

    	jPanel1 = new javax.swing.JPanel();
        FieldNameLabel = new javax.swing.JLabel();
        fieldNoLabel = new javax.swing.JLabel();
        fieldNumberTextField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        fieldNameTextField = new javax.swing.JTextField();
        totalLengthTextField = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        generateSampleTextField = new javax.swing.JTextField();
        generateSampleButton = new javax.swing.JButton();
        doneButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        dataPanel = new javax.swing.JPanel();
        buttonsPanel = new javax.swing.JPanel();
       // removeButton = new javax.swing.JButton();
      //  addButton = new javax.swing.JButton();
      //  entryPanel1 = new datafabricationmodule.EntryPanel();
      //  ruleList.add(entryPanel1);
        setBackground(new java.awt.Color(0, 102, 153));
        setMaximumSize(new java.awt.Dimension(1060, 600));
        setName("createRulesForm"); // NOI18N
        setPreferredSize(new java.awt.Dimension(1060, 600));

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        FieldNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        FieldNameLabel.setText("Field Name");

        fieldNoLabel.setForeground(new java.awt.Color(255, 255, 255));
        fieldNoLabel.setText("Field No.");

        fieldNumberTextField.setEditable(false);
        fieldNumberTextField.setPreferredSize(new java.awt.Dimension(6, 23));
        fieldNumberTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNumberTextFieldActionPerformed(evt);
            }
        });

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Total Length");

        fieldNameTextField.setEditable(false);
        fieldNameTextField.setPreferredSize(new java.awt.Dimension(6, 23));

        totalLengthTextField.setEditable(false);
        totalLengthTextField.setPreferredSize(new java.awt.Dimension(6, 23));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(fieldNoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fieldNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67)
                .addComponent(FieldNameLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fieldNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totalLengthTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {fieldNumberTextField, totalLengthTextField});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(fieldNoLabel)
                    .addComponent(fieldNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FieldNameLabel)
                    .addComponent(fieldNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(totalLengthTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(0, 102, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        generateSampleTextField.setEditable(false);        
        generateSampleTextField.setPreferredSize(new java.awt.Dimension(6, 23));
        

        generateSampleButton.setText("Generate Sample");
        generateSampleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generateSampleButtonActionPerformed(evt);
            }
        });

        doneButton.setText("Done");
        doneButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doneButtonActionPerformed(evt);
            }
        });

        cancelButton.setText("Cancel");
        cancelButton.setPreferredSize(new java.awt.Dimension(57, 23));
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(generateSampleButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(generateSampleTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(doneButton, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(doneButton)
                        .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(generateSampleTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(generateSampleButton)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cancelButton, doneButton});

        jScrollPane1.setBackground(new java.awt.Color(0, 102, 153));
        jScrollPane1.setBorder(null);
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        
        
        dataPanel.setBackground(new java.awt.Color(0, 102, 153));
        dataPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        dataPanel.setName("dataPanel"); // NOI18N
        dataPanel.setPreferredSize(new java.awt.Dimension(800, 1203));

        buttonsPanel.setBackground(new java.awt.Color(0, 102, 153));
        buttonsPanel.setPreferredSize(new java.awt.Dimension(72, 23));
        
        System.out.println("CreateRules.initComponents() -- button panel y == "+buttonsPanel.getY());

//        removeButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
//        removeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("minus.png"))); // NOI18N
//        removeButton.setPreferredSize(new java.awt.Dimension(18, 18));
//        removeButton.addActionListener(new java.awt.event.ActionListener() {
//            public void actionPerformed(java.awt.event.ActionEvent evt) {
//                removeButtonActionPerformed(evt);
//            }
//        });
//
//        addButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
//        addButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("plus.png"))); // NOI18N
//        addButton.setPreferredSize(new java.awt.Dimension(18, 18));
//        addButton.addActionListener(new java.awt.event.ActionListener() {
//            public void actionPerformed(java.awt.event.ActionEvent evt) {
//                addButtonActionPerformed(evt);
//            }
//        });

//        javax.swing.GroupLayout buttonsPanelLayout = new javax.swing.GroupLayout(buttonsPanel);
//        buttonsPanel.setLayout(buttonsPanelLayout);
//        buttonsPanelLayout.setHorizontalGroup(
//            buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//            .addGroup(buttonsPanelLayout.createSequentialGroup()
//                .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
//                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
//                .addComponent(removeButton, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
//        );
//        buttonsPanelLayout.setVerticalGroup(
//            buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//            .addGroup(buttonsPanelLayout.createSequentialGroup()
//                .addGroup(buttonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//                    .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
//                    .addComponent(removeButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
//                .addGap(0, 0, 0))
//        );
//
//        buttonsPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {addButton, removeButton});

      //  InitDataPanel();
        

       
//        javax.swing.GroupLayout dataPanelLayout = new javax.swing.GroupLayout(dataPanel);
//        dataPanel.setLayout(dataPanelLayout);
//        dataPanelLayout.setHorizontalGroup(
//            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//            .addGroup(dataPanelLayout.createSequentialGroup()
//                .addGap(273, 273, 273)
//                .addComponent(entryPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
//                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
//                .addComponent(buttonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
//                .addContainerGap(389, Short.MAX_VALUE))
//        );
//        dataPanelLayout.setVerticalGroup(
//            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//            .addGroup(dataPanelLayout.createSequentialGroup()
//                .addGap(36, 36, 36)
//                .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//                    .addComponent(buttonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
//                    .addComponent(entryPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
//                .addContainerGap(1139, Short.MAX_VALUE))
//        );
//
//        dataPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {buttonsPanel, entryPanel1});
//
//        jScrollPane1.setViewportView(dataPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        
   
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1014, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43))
        );

        getAccessibleContext().setAccessibleParent(this);
    }// 
   
            
    
    private void fieldNumberTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNumberTextFieldActionPerformed
        // TODO add your handling code here:
    }
    private void generateSampleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNumberTextFieldActionPerformed
        // TODO add your handling code here:
    	//generateSampleTextField
    	
    	dataFabricatorPanel dfpanel = dataFabricatorPanel.getInstance();
    	//JOptionPane.showMessageDialog(null, "columnname = "+fieldNameTextField.getText()+" rule size = "+ruleList.size());
    	String sampledata = dfpanel.getGeneratedSample(ruleList);
    	generateSampleTextField.setText(sampledata);
    }
    
            
    private void initgroups(){
       dataPanelLayout =  new javax.swing.GroupLayout(dataPanel);
        pgroup = dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING);
    }
    
    int x = 10;
   
    
    
    private boolean isValidPrevEntry(){
    	if(ruleList.isEmpty())
    		return true;
    	EntryPanel preventryPanel = (EntryPanel) ruleList.get(ruleList.size()-1);
    	String lengthselected = preventryPanel.getLengthComboSelectedItem();
    	if(null == lengthselected || lengthselected.isEmpty())
    		return false;
    	 int selectlen = Integer.parseInt(lengthselected);
    	 String datatype = preventryPanel.getDataTypeComboSelectedItem();
    	 if(null == datatype || datatype.startsWith("select"))
    		 return false;
    	 curselectionitem = selectlen;
    	// lengthCompleted += selectlen;
    	 return true;
    }
    private int curselectionitem = 0;
    int rulePanelYOffset = 30;
    private static int panelCounter = 0;
    
    
    
    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        // TODO add your handling code here:
        panelCounter++;
        if(!isValidPrevEntry()){
    		JOptionPane.showMessageDialog(null, "Please select valid entry");
    	}
        if(toTalNoOfLength-(lengthCompleted+curselectionitem) <= 0){
    		JOptionPane.showMessageDialog(null, "Total length of rule has been defined");
    		return;
    	}
    	lengthCompleted += curselectionitem;
        EntryPanel entryPanel = new EntryPanel(toTalNoOfLength-lengthCompleted);
        //EntryPanel entryPanel = new EntryPanel();
        entryPanel.setName("entryPanel"+panelCounter);
        ruleList.add(entryPanel);
        dataPanel.setLayout(dataPanelLayout);
        dataPanelLayout.setHorizontalGroup(
            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataPanelLayout.createSequentialGroup()
                .addGap(273, 273, 273)
                .addGroup(pgroup.addComponent(entryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        dataPanelLayout.setVerticalGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataPanelLayout.createSequentialGroup()
                .addGap(36+rulePanelYOffset, 36+rulePanelYOffset, 36+rulePanelYOffset)
                .addComponent(entryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        rulePanelYOffset+=30;
        //JOptionPane.showMessageDialog(null, "buttonsPanel.getBounds().y = "+buttonsPanel.getBounds().y);
       // buttonsPanel.setBounds(buttonsPanel.getBounds().x, buttonsPanel.getBounds().y + 30, buttonsPanel.getBounds().width, buttonsPanel.getBounds().height);
        System.out.println("CreateRules.addButtonActionPerformed() -- button panel y == "+buttonsPanel.getY()+" hashcode == "+buttonsPanel.hashCode());
        //buttonsPanel.setBounds(buttonsPanel.getBounds().x, buttonsPanel.getBounds().y + 30, buttonsPanel.getBounds().width, buttonsPanel.getBounds().height);
        buttonsPanel.setBounds(buttonsPanel.getBounds().x, 500 + 30, buttonsPanel.getBounds().width, buttonsPanel.getBounds().height);
        System.out.println("CreateRules.addButtonActionPerformed() -- After adding .. button panel y == "+buttonsPanel.getY());
        dataPanel.revalidate();
        dataPanel.repaint();
    }//GEN-LAST:event_addButtonActionPerformed

    private void removeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeButtonActionPerformed
        // TODO add your handling code here:
        for(int i = 1; i < dataPanel.getComponentCount();i++){
            System.out.println("dataPanel.getComponent("+i+").getName() == "+dataPanel.getComponent(i).getName());
            if(dataPanel.getComponent(i).getName()== null){
                continue;
            }
            if(dataPanel.getComponent(i).getName().equals("entryPanel"+panelCounter)){
                dataPanel.remove(dataPanel.getComponent(i));
                panelCounter--;
                ruleList.remove(ruleList.size()-1);
                rulePanelYOffset-=30;
                buttonsPanel.setBounds(buttonsPanel.getBounds().x, buttonsPanel.getBounds().y - 30, buttonsPanel.getBounds().width, buttonsPanel.getBounds().height);
                dataPanel.revalidate();
                dataPanel.repaint();
            }
        }
    }//GEN-LAST:event_removeButtonActionPerformed
    
    
    
    
    
    
  /*  private void addRulesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addRulesButtonActionPerformed
    	
    	if(!isValidPrevEntry()){
    		JOptionPane.showMessageDialog(null, "Please select valid entry");
    	}
    	// int selectlen = 
    	//JOptionPane.showMessageDialog(null, "toTalNoOfLength = "+toTalNoOfLength+" lengthCompleted = "+lengthCompleted+" curselectionitem = "+curselectionitem);
    	if(toTalNoOfLength-(lengthCompleted+curselectionitem) <= 0){
    		JOptionPane.showMessageDialog(null, "You have completed the selection");
    		return;
    	}
    	lengthCompleted += curselectionitem;
        EntryPanel entryPanel = new EntryPanel(toTalNoOfLength-lengthCompleted);
        
        ruleList.add(entryPanel);
        dataPanel.setLayout(dataPanelLayout);
        dataPanelLayout.setHorizontalGroup(
            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataPanelLayout.createSequentialGroup()
                        .addGap(170, 170, 170)
                        .addGroup(pgroup.addComponent(entryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                 )                    
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        dataPanelLayout.setVerticalGroup(
            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollBar1, javax.swing.GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE)
            .addGroup(dataPanelLayout.createSequentialGroup()
                .addGap(45+x, 45+x, 45+x)
                .addComponent(entryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)                
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        x+=30;
        dataPanel.revalidate();
        dataPanel.repaint();
    }//GEN-LAST:event_addRulesButtonActionPerformed*/

    private void generateSampleTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generateSampleTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_generateSampleTextFieldActionPerformed

    
    private void doneButtonActionPerformed(java.awt.event.ActionEvent evt) {
    	dataFabricatorPanel dfpanel = dataFabricatorPanel.getInstance();
    	//JOptionPane.showMessageDialog(null, "columnname = "+fieldNameTextField.getText()+" rule size = "+ruleList.size());
    	dfpanel.addToMap(fieldNameTextField.getText().trim(), ruleList);
    	 // getMainSubPanel().setVisible(true);
    	  MainFrame mf = MainFrame.getInstance();
          CardLayout card = (CardLayout)mf.getMainSubPanel().getLayout();
       //   dataFabricatorPanel dpanel = new dataFabricatorPanel();
       //   dataFabricatorPanel.getInstance().reload();
          card.show(mf.getMainSubPanel(), "dataFabricatorCard"); 
    }
    
    
    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
      MainFrame.getInstance().getMainSubPanel().setVisible(false);
        CardLayout card = (CardLayout)MainFrame.getInstance().getMainSubPanel().getLayout();
        card.show(MainFrame.getInstance().getMainSubPanel(), null);
    }//GEN-LAST:event_cancelButtonActionPerformed

    public JTextField getFieldNumberTextField(){
        return(fieldNumberTextField);
    }
    
    public JTextField getFileNameTextField(){
        return(fieldNameTextField);
    }
    
    public void setTotalLength(String val){
    	totalLengthTextField.setText(val);
    	toTalNoOfLength = Integer.parseInt(val);
    	entryPanel1.setComboVal(toTalNoOfLength-lengthCompleted);
    	
    }
    public JTextField getTotalLengthTextField(){
        return(totalLengthTextField);
    }
        
        
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel FieldNameLabel;
    private javax.swing.JButton addButton;
    private javax.swing.JPanel buttonsPanel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JPanel dataPanel;
    private javax.swing.JButton doneButton;
    private datafabricationmodule.EntryPanel entryPanel1;
    private javax.swing.JLabel fieldNoLabel;
    private javax.swing.JTextField fieldNumberTextField;
    private javax.swing.JTextField fieldNameTextField;
    private javax.swing.JButton generateSampleButton;
    private javax.swing.JTextField generateSampleTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton removeButton;
    private javax.swing.JTextField totalLengthTextField;
    // End of variables declaration//GEN-END:variables


    private int toTalNoOfLength;
    private int lengthCompleted = 0;
    
    
    private GroupLayout.ParallelGroup pgroup; 
    private javax.swing.GroupLayout dataPanelLayout;
    
    private List<EntryPanel> ruleList = new ArrayList<>();
    
    
    
}
