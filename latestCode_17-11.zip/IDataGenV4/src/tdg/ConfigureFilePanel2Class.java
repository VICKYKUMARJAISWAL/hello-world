/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tdg;

import java.awt.CardLayout;
import java.awt.Point;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultCellEditor;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.tree.DefaultMutableTreeNode;

import com.igate.constants.FileType;
import com.igate.dto.ColumnDetail;
import com.igate.service.ServiceManager;


/**
 *
 * @author sh834131
 */
public class ConfigureFilePanel2Class extends javax.swing.JPanel {

    /**
     * Creates new form ConfigureFilePanel2Class
     */
    
     static ConfigureFilePanel2Class myScreen2 = null;
    
    public static ConfigureFilePanel2Class getInstance(){
        if(myScreen2 == null){
            myScreen2 = new ConfigureFilePanel2Class();
        }
        return(myScreen2);
    }
   
    
    private ConfigureFilePanel2Class() {
        initComponents();
        JTableHeader header = jTable2.getTableHeader();
        header.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
               jTable2HeaderMouseClicked(evt);
           }
        });
    }
    
    private TransformDataDialog transformDialog;

    public void setTransformDataDialogVisibble(boolean status){
    	this.transformDialog.setVisible(status);
    }
    private void jTable2HeaderMouseClicked(java.awt.event.MouseEvent evt) {  
       Point point = evt.getPoint();
       int currentselectcolumn = jTable2.columnAtPoint(point);
       int prevmodifiedcolumnindex = TransformDataDialog.getPreviousModifiedColumnIndex();
       if(prevmodifiedcolumnindex != -1 && (currentselectcolumn != prevmodifiedcolumnindex)){
    	   int selectedOption = JOptionPane.showConfirmDialog(null, "You have modified "+jTable2.getColumnName(prevmodifiedcolumnindex)+" confirm to save it","confirm",JOptionPane.YES_NO_OPTION);
    	   if(selectedOption == JOptionPane.YES_OPTION){
    		   TransformDataDialog.setPreviousModifiedColumnIndex(-1);
    	   }else{    		   
    		   reFillColumnData(prevmodifiedcolumnindex);
    		   TransformDataDialog.setPreviousModifiedColumnIndex(-1);
    	   }
    	   
       }
       transformDialog = new TransformDataDialog(MainFrame.getInstance(), true);
       transformDialog.setSelectedColumnTextField(jTable2.getColumnName(currentselectcolumn)+"@"+currentselectcolumn);
       transformDialog.setVisible(true);
       //JOptionPane.showMessageDialog(jTable1, "Column header #" + column + " is clicked");
    }
    
    
    private void initParamTable(){
    	jParamTableModel = new DefaultTableModel();
    	jTable1.setModel(jParamTableModel);
    	 String [] columns=new String [] { "Field Name", "Operator", "Value", "Condition" };
    	 for(int i = 0; i < columns.length; i++){
    		 jParamTableModel.addColumn(columns[i]);
    	 }
    	  jTable1.setGridColor(new java.awt.Color(0, 0, 0));
          jScrollPane1.setViewportView(jTable1);    	
    }
   
    private void initFieldColumn(int rownum){
	    	if(rownum == 1){
	          DefaultListModel<ColumnDetail> list2  =  ConfigureFilePanel1Class.getInstance().getSelectedColumnListModel();
	          int size = list2.getSize();
	          ColumnDetail dummy = new ColumnDetail();
	          dummy.setColumnName("select field");
	          dummy.setdummyAs(true);
	          // Clear the combo box 
	          for(int i=fieldCombo.getItemCount()-1;i>=0;i--){
	        	  fieldCombo.removeItemAt(i);
	          }
	          fieldCombo.addItem(dummy);
	          System.out.println("list2 size "+size);
	           for(int i = 0; i < size; i++){
	               System.out.println("Adding to combo item "+i+"== "+list2.getElementAt(i));
	               fieldCombo.addItem(list2.get(i));
	           }
	           TableColumn mappedcolumn = jTable1.getColumnModel().getColumn(0);
	           mappedcolumn.setCellEditor(new DefaultCellEditor(fieldCombo));
	           DefaultTableCellRenderer renderer =
	   				new DefaultTableCellRenderer();
	           mappedcolumn.setCellRenderer(renderer);
	    	}
    	
           jTable1.getModel().setValueAt(fieldCombo.getItemAt(0), rownum-1, 0);
           fieldCombo.addItemListener(new ItemListener() {
   			
   			@Override
   			public void itemStateChanged(ItemEvent e) {
   				onFieldComboSelect(e);
   			}
   		});
    }
    
    private void initConditionField(int rownum){
    	conditionCombo = new JComboBox<>();
        String [] conditionoperators = {"select","and","or"}; 
       // System.out.println("list2 size "+size);
         for(int i = 0; i < conditionoperators.length; i++){
             //System.out.println("item "+i+"== "+list2.getElementAt(i));
        	 conditionCombo.addItem(conditionoperators[i]);
         }
         conditionCombo.setSelectedIndex(0);
         TableColumn mappedcolumn = jTable1.getColumnModel().getColumn(3);
         mappedcolumn.setCellEditor(new DefaultCellEditor(conditionCombo));
         DefaultTableCellRenderer renderer =
 				new DefaultTableCellRenderer();
         mappedcolumn.setCellRenderer(renderer);
         jTable1.getModel().setValueAt(conditionCombo.getItemAt(0),rownum-1,3);
         conditionCombo.addItemListener(new ItemListener() {
    			
			@Override
			public void itemStateChanged(ItemEvent e) {
				onConditionComboSelect(e);
				
			}
         });
    }
    
    private void initOperatorField(int rowno){
  	  JComboBox<String> opcombo = new JComboBox<>();
       // String [] Arithimeticoperators = {"=","<",">"};
  	String [] Arithimeticoperators = {"=","<",">","!=",">=","<=","like","not null","is null","between","in"};
       // System.out.println("list2 size "+size);
         for(int i = 0; i < Arithimeticoperators.length; i++){
             //System.out.println("item "+i+"== "+list2.getElementAt(i));
             opcombo.addItem(Arithimeticoperators[i]);
         }
         opcombo.setSelectedIndex(0);
         TableColumn mappedcolumn = jTable1.getColumnModel().getColumn(1);
         mappedcolumn.setCellEditor(new DefaultCellEditor(opcombo));
         DefaultTableCellRenderer renderer =
 				new DefaultTableCellRenderer();
         mappedcolumn.setCellRenderer(renderer);
         jTable1.getModel().setValueAt(opcombo.getItemAt(0),rowno-1,1);
  }
    
    public void addParamTableRow(){
    	int selectedrow = jTable1.getSelectedRow();
    	int totalrow = jTable1.getRowCount();
    	if((selectedrow+1) == totalrow){ 
    		jParamTableModel.addRow(new Object[]{null,null,null,null});
    		initFieldColumn(jParamTableModel.getRowCount());
    	}
    }
    public void initParamTableRowData(boolean isfirstTime){
		jParamTableModel.setRowCount(0);
		jParamTableModel.addRow(new Object[]{null,null,null,null});
		initFieldColumn(jParamTableModel.getRowCount());
    }
    
    public void clearForm(){
    	System.out.println("ConfigureFilePanel2Class.clearForm()");
    	jParamTableModel.setRowCount(0);
    	jdataTableModel.setRowCount(0);
    	jdataTableModel.setColumnCount(0);
    	jTextField1.setText("");
    	jCheckBoxIgnoreParam.setSelected(false);
    }
    
    private void initDataTabble(){
    	jdataTableModel = new DefaultTableModel();
    	jTable2.setModel(jdataTableModel);
    }
    private void populateRetriveDatacolumn(List<ColumnDetail> columnlist){
    	
    	jdataTableModel.setColumnCount(0);
    	 for(int i = 0; i < columnlist.size(); i++){
    		 jdataTableModel.addColumn(columnlist.get(i));
    	 }
    }
    
    private void fillRetriveData(List<List<String>> assetdata){
    	jdataTableModel.getDataVector().removeAllElements();
    	for(int i = 0; i < assetdata.size(); i++){
    		List<String> line = assetdata.get(i);
    		Object[] rowdata = line.toArray();
    		jdataTableModel.addRow(rowdata);
    	}
    }

    private void onFieldComboSelect(ItemEvent event){
    	 System.out.println(event.getStateChange());
    	if (event.getStateChange() == ItemEvent.SELECTED) {
            ColumnDetail item = (ColumnDetail)event.getItem();
            // do something with object
            //System.out.println(item);
            if(item.isdummy())
            	return;
            initOperatorField(jParamTableModel.getRowCount());
            initConditionField(jParamTableModel.getRowCount());
        }
    }
    	
    private void onConditionComboSelect(ItemEvent event){
   	 System.out.println(event.getStateChange());
   	if (event.getStateChange() == ItemEvent.SELECTED) {
           String item = (String)event.getItem();
           // do something with object
           System.out.println("onConditionComboSelect item = "+item);
           if(item.startsWith("select"))
        	   return;
           addParamTableRow();
       }
   }
    
    
    private void initComponents() {

        QueryPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        RetrieveButton = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        CloseButton = new javax.swing.JButton();
        ExportButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        BackButton = new javax.swing.JButton();
        fieldCombo = new JComboBox<>();
        jCheckBoxIgnoreParam = new javax.swing.JCheckBox(); 

        setBackground(new java.awt.Color(0, 102, 153));
        setForeground(new java.awt.Color(255, 204, 204));
        setPreferredSize(new java.awt.Dimension(1060, 600));

        QueryPanel.setBackground(new java.awt.Color(0, 102, 153));
        QueryPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jTable1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        initParamTable();
    
        jTable1.setGridColor(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(jTable1);

        RetrieveButton.setText("Retrieve");
        RetrieveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RetrieveButtonActionPerformed(evt);
            }
        });
        
        jCheckBoxIgnoreParam.setBackground(new java.awt.Color(0, 102, 153)); 
        jCheckBoxIgnoreParam.setForeground(new java.awt.Color(255, 255, 255)); 
        jCheckBoxIgnoreParam.setText("Ignore Parameters"); 


        javax.swing.GroupLayout QueryPanelLayout = new javax.swing.GroupLayout(QueryPanel);
        QueryPanel.setLayout(QueryPanelLayout);
        QueryPanelLayout.setHorizontalGroup(
            QueryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(QueryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(QueryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(QueryPanelLayout.createSequentialGroup()
                .addComponent(jCheckBoxIgnoreParam) 
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE) 
                .addComponent(RetrieveButton)
                .addGap(34, 34, 34))
            .addGroup(QueryPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 995, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        QueryPanelLayout.setVerticalGroup(
            QueryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(QueryPanelLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(QueryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RetrieveButton)
                    .addComponent(jCheckBoxIgnoreParam))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        initDataTabble();
      
        jScrollPane2.setViewportView(jTable2);

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Total Records Retrieved");

        jTextField1.setEditable(false);
        jTextField1.setName("TextBoxNoOfRecords"); // NOI18N
        jTextField1.setPreferredSize(new java.awt.Dimension(6, 18));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1000, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(0, 102, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel2.setForeground(new java.awt.Color(255, 204, 204));

        CloseButton.setText("Close");
        CloseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CloseButtonActionPerformed(evt);
            }
        });

        ExportButton.setText("Export");
        ExportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExportButtonActionPerformed(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Delimiter");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "comma", "pipe", "hash", "semicolon" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        BackButton.setText("Back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ExportButton)
                .addGap(18, 18, 18)
                .addComponent(CloseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {BackButton, CloseButton, ExportButton});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(CloseButton)
                        .addComponent(ExportButton)
                        .addComponent(BackButton))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {BackButton, CloseButton, ExportButton});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(QueryPanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(QueryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    
    
   
    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void ExportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExportButtonActionPerformed
    	// TODO add your handling code here:
    	
    	// Confirm if last modified column has to be saved or not
    	int prevmodifiedcolumnindex =  TransformDataDialog.getPreviousModifiedColumnIndex();
    	 if(prevmodifiedcolumnindex != -1){
      	   int selectedOption = JOptionPane.showConfirmDialog(null, "You have modified "+jTable2.getColumnName(prevmodifiedcolumnindex)+" confirm to save it","confirm",JOptionPane.YES_NO_OPTION);
      	   if(selectedOption == JOptionPane.YES_OPTION){
      		   TransformDataDialog.setPreviousModifiedColumnIndex(-1);
      	   }else{    		   
      		   reFillColumnData(prevmodifiedcolumnindex);
      		   TransformDataDialog.setPreviousModifiedColumnIndex(-1);
      	   }
         }
    	
    	
    	// Open file dialog box to save
    	int returnVal = MainFrame.getInstance().getconfigureFile2FileChooser().showOpenDialog(this);
    	File file = null;
    	if (returnVal == JFileChooser.APPROVE_OPTION) {

    	 file = MainFrame.getInstance().getconfigureFile2FileChooser().getSelectedFile();

    	try {

    	// What to do with the file, e.g. display it in a TextArea

    	System.out.println("file.getAbsolutePath() == "+file.getAbsolutePath());

    	} catch (Exception ex) {

    	System.out.println("problem accessing file"+ex.getMessage());

    	}

    	} else {

    	System.out.println("File access cancelled by user.");

    	}
    	String combodelim = (String)jComboBox1.getSelectedItem();
    	String delimval = DialogUtil.getDelimChar(combodelim);
    	Vector<Vector<Object>> datavector = jdataTableModel.getDataVector();
    	ServiceManager sm = new ServiceManager();
    	// exportIntoFile(FileType filetype, String delim, Vector<Vector<Object>> datavector, List<ColumnDetail> columnlist, String filepath ){
    	sm.exportIntoFile(FileType.CSV, delimval, datavector, dataColuumnList, file.getAbsolutePath());
    	JOptionPane.showMessageDialog(null, "File created successfully!");
    	//Get All the data from table
    	//dataColuumnList

    }//GEN-LAST:event_ExportButtonActionPerformed

    private void CloseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CloseButtonActionPerformed
        MainFrame.getInstance().getMainSubPanel().setVisible(false);
        CardLayout card = (CardLayout)MainFrame.getInstance().getMainSubPanel().getLayout();
        card.show(MainFrame.getInstance().getMainSubPanel(), null);
    }//GEN-LAST:event_CloseButtonActionPerformed

    private List<ColumnDetail> getElements(DefaultListModel<ColumnDetail> model){
    	List<ColumnDetail> columnlist = new ArrayList<>();
    	for(int i = 0; i < model.getSize(); i++){
    		ColumnDetail cd = model.get(i);
    		columnlist.add(cd);
    	}
    	return columnlist;
    }
    
    private void setNoOfRecordText(int noofrecord){
    	jTextField1.setText(noofrecord+"");
    }
    
    private boolean validateNextRow(Vector row,int i ){
    	ColumnDetail cd = (ColumnDetail)row.get(0);
		if(cd.isdummy()){
			JOptionPane.showMessageDialog(null, "row value is required at "+(i+1));
			return false;
		}
			
		String operator = (String) row.get(1);
		String value = (String) row.get(2);
		
		if(value == null || value.isEmpty()){
			JOptionPane.showMessageDialog(null, "Please mention a value for "+cd.getColumnName()+" at row "+(i+1));
			return false;
		}
    	return true;
    }
    private String getParamString(){
    	StringBuilder param = new StringBuilder();
    	//TableModel tmodel = jTable1.getModel();
    	int rowcount = jParamTableModel.getRowCount();
    	if(rowcount == 0)
    		return "NA";
    	Vector tabledata = jParamTableModel.getDataVector();
    	for(int i = 0; i < rowcount; i++){
    		Vector row = (Vector)tabledata.get(i);
    		ColumnDetail cd = (ColumnDetail)row.get(0);
    		if(cd.isdummy())
    			continue;
    		String operator = (String) row.get(1);
    		String value = (String) row.get(2);
    		
    		if(value == null || value.isEmpty()){
    			JOptionPane.showMessageDialog(null, "Please mention a value for "+cd.getColumnName()+" at row "+(i+1));
    			return "ERROR";
    		}
    		
    		if(operator.equals("between")){
    			value = value.toUpperCase();
    			
    			String []subparams = value.trim().split("AND");
    			if(subparams.length != 2){
    				JOptionPane.showMessageDialog(null, "BETWEEN should contain two values");
        			return "ERROR";
    			}
    			value = "'"+subparams[0].trim()+"' and '"+subparams[1].trim()+"'";
    				
    		}
    		else{
    			value = "'"+value+"'";
    		}
    		
    		param.append(cd.getColumnName())
			 .append(" ")
			 .append(operator)
			 .append(" ")
			// .append("'")
			 .append(value);
    		// .append("'");
			 
    		String condition = (String) row.get(3);
    		if(null == condition || condition.isEmpty() || "select".equalsIgnoreCase(condition)){
    			break;
    		}else{    			
    			// Let's check whether next row is avialable or not
    			if( (i+1) < rowcount){
    				if(validateNextRow((Vector)tabledata.get(i+1),i)){
    					param.append(" ")
      				  .append(condition)
      				  .append(" ");
    				}else{
    					JOptionPane.showMessageDialog(null, "Some error occurs");
    					return "ERROR";
    				}
    			}else{
    				// The condition column should be ignored
    			}
    		}
    	}
    	System.out.println(param.toString());
    	return param.toString();
    }
    
    
    
    
    private void reFillColumnData(int columnIndex){
    	
    	int rowcount = assetDataList.size();
    	for(int i = 0; i < rowcount; i++){
    		List<String> row = assetDataList.get(i);
    		jTable2.setValueAt(row.get(columnIndex), i, columnIndex);
    	}
    }
    
    
    
    private List<List<String>> assetDataList = null;
    private void RetrieveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RetrieveButtonActionPerformed
    	// Get the param List
    	//Let's assume param is null
    	//clearda
    	
    	MainFrame mf = MainFrame.getInstance();
    	ConfigureFilePanel1Class cf = ConfigureFilePanel1Class.getInstance();
    	DefaultMutableTreeNode selectedNode = mf.getSelectedNode();
    	
    	if(null == selectedNode){
    		JOptionPane.showMessageDialog(null, "There is a bug as we r not getting selected node");
    		return;
    	}
    	String tablename = selectedNode.getUserObject().toString();
    	// Get the list of columns
    	DefaultListModel<ColumnDetail> selectedlistmodel = cf.getSelectedColumnListModel();
    	if(selectedlistmodel == null || selectedlistmodel.getSize() == 0){
    		JOptionPane.showMessageDialog(null, "Debug issue:: Not getting any list data from config page 1");
    		return;
    	}
    	
    	 dataColuumnList = getElements(selectedlistmodel);
    	//JOptionPane.showMessageDialog(null, "columnlist = "+dataColuumnList.size());
    	
    	//Get the param String
    	 List<String> paramlist = new ArrayList<>();
    	 if(jCheckBoxIgnoreParam.getModel().isSelected()){
    		// JOptionPane.showMessageDialog(null, "jCheckBoxIgnoreParam enabled");
    		 paramlist = null;
    	 }else{
    		// JOptionPane.showMessageDialog(null, "jCheckBoxIgnoreParam disabled");
    		 String param = getParamString();
    		 System.out.println("Getting param as = "+param);
    	    	if("ERROR".equals(param))
    	    		return;
    	    	
    	    	if(null == param || "".equals(param) || "NA".equals(param) ){
    	    		paramlist = null;
    	    	}else{
    	    		paramlist.add(param);
    	    	}
    	    	System.out.println("Getting param as = "+param);
    	 }
    	
    	
    	populateRetriveDatacolumn(dataColuumnList);
    	ServiceManager sm = new ServiceManager();
    	assetDataList = sm.getAssetData(dataColuumnList, paramlist, tablename);
    	// Let's fill the retrive column
    //	JOptionPane.showMessageDialog(null, "assetdatalist = "+assetdatalist.size());
    	setNoOfRecordText(assetDataList.size());
    	fillRetriveData(assetDataList);
    	//initParamTableRowDat--a();
    	
    }//GEN-LAST:event_RetrieveButtonActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
       CardLayout card = (CardLayout)MainFrame.getInstance().getMainSubPanel().getLayout();
       card.show(MainFrame.getInstance().getMainSubPanel(), "configureFile1Card");
    }//GEN-LAST:event_BackButtonActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    // To set table cell as a combo box
      
    public DefaultTableModel getDataTableModel(){
    	return this.jdataTableModel;
    }
    public JTable getDataTable(){
    	return this.jTable2;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private javax.swing.JButton CloseButton;
    private javax.swing.JButton ExportButton;
    private javax.swing.JPanel QueryPanel;
    private javax.swing.JButton RetrieveButton;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JCheckBox jCheckBoxIgnoreParam;
    private List<ColumnDetail> dataColuumnList;
    // End of variables declaration//GEN-END:variables
    
    private DefaultTableModel jParamTableModel;
    private DefaultTableModel jdataTableModel;
    
    
    private  JComboBox<ColumnDetail> fieldCombo = new JComboBox<>();
    private  JComboBox<String> conditionCombo = new JComboBox<>();
}
