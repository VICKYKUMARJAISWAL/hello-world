package tdg;

import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.igate.dto.GroupRecord;

public class DialogUtil {

	
	public static void loadGroupCombo(JComboBox comboBox){
		MainFrame frame = MainFrame.getInstance();
    	List<GroupRecord> groups = frame.getAll1stLevleGroup();
    	GroupRecord[] arrayofgroups = groups.toArray(new GroupRecord[groups.size()]);
    	DefaultComboBoxModel<GroupRecord> cmodel = new DefaultComboBoxModel<>(arrayofgroups);
    	comboBox.setModel(cmodel);
    	comboBox.setSelectedIndex(0);
    	
	}
	
	public static void loadSubGroupCombo(JComboBox comboBox, GroupRecord selectedgroup,JLabel subgrouplebel){
		MainFrame frame = MainFrame.getInstance();
    	List<GroupRecord> groups = frame.getAllSubGroups(selectedgroup);
    //	JOptionPane.showMessageDialog(null, "size = "+groups.size());
    	if(null == groups || groups.isEmpty()){
    		subgrouplebel.setVisible(false);
    		comboBox.setVisible(false);
    		return;
    	}
    //	JOptionPane.showMessageDialog(null, "let's make it true");
    	subgrouplebel.setVisible(true);
    	comboBox.setVisible(true);
    	GroupRecord[] arrayofgroups = groups.toArray(new GroupRecord[groups.size()]);
    	DefaultComboBoxModel<GroupRecord> cmodel = new DefaultComboBoxModel<>(arrayofgroups);
    	comboBox.setModel(cmodel);
    	comboBox.setSelectedIndex(0);
	}
	 public static String getDelimChar(String delstr){
	    	String defaultdelmchar = ",";
	    	if(null == delstr || delstr .isEmpty()) return defaultdelmchar;
	    	if(delstr.equalsIgnoreCase("comma")) return defaultdelmchar;
	    	if(delstr.equalsIgnoreCase("pipe")) return "|";
	    	if(delstr.equalsIgnoreCase("hash")) return "#";
	    	if(delstr.equalsIgnoreCase("semicolon")) return ";";
	    	return defaultdelmchar;
	    }
	 
	 public static boolean isValidText(String val){
		 
		// boolean result = false;
		 
		 if(null == val || val.isEmpty())
			 return false;
		 return true;
		 
		// return result;
		 
		 
	 }
	 
	 
	 public static boolean isValidInt(String val){
		 
		// boolean result = false;
		 try{
			 
			 Integer.parseInt(val);
			 return true;
		 }catch(NumberFormatException nx){
			 return false;
		 }
		
			
	 }
	 
	
	 
	 
}
