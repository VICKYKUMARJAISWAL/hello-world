package tdg;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.igate.db.manager.ConnectionManager;
import com.igate.dto.ConnectionDetail;

public class GetRefDetails {

	public Map<String, List<String>> getEntity() throws SQLException, Exception {

		Map<String, List<String>> map = null;
		Connection conn = null;
		try {

			map = new HashMap<String, List<String>>();

			conn = new ConnectionManager().getConnection();


			System.out.println("Connect");
			DatabaseMetaData md = conn.getMetaData();
			ResultSet rs = md.getTables(null, null, "%", null);

			while (rs.next()) {
				//
				String table_name = rs.getString(3);
				System.out.println("Table Name : " + rs.getString(3));

				// Create a result set
				Statement statement = conn.createStatement();
				ResultSet results = statement.executeQuery("SELECT * FROM "
						+ table_name);
				// Get resultset metadata
				ResultSetMetaData metadata = results.getMetaData();
				int columnCount = metadata.getColumnCount();
				System.out.println(table_name + " columns : " + columnCount);

				// Get the column names; column indices start from 1
				List<String> list = new ArrayList<String>();
				for (int i = 1; i <= columnCount; i++) {
					String columnName = metadata.getColumnName(i);
					list.add(columnName);
					System.out.println(columnName);
				}
				map.put(table_name, list);
				// list = null;

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			conn.close();
		}

		return map;
	}
	
	/*
	 * To get all the tables from the database
	 */
	public List<String> getTables() {

		List <String>list = null;
		try {

			list = new ArrayList<String>();

			Connection conn = new ConnectionManager().getConnection();
			System.out.println("Connect");
			DatabaseMetaData md = conn.getMetaData();
			ResultSet rs = md.getTables(null, null, "%", null);

			while (rs.next()) {
				String table_name = rs.getString(3);
				System.out.println("Table Name : " + rs.getString(3));
				list.add(table_name);			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	/*
	 * To get column names corresopnding to the selected Table from combo box1
	 */

	public List<String> getColumnNames(String TableName) {

		List<String> list = new ArrayList<String>();
		try {
			Connection conn = new ConnectionManager().getConnection();
			
			String table_name = TableName;
			System.out.println("Connect :" +table_name );

			// Create a result set
			Statement statement = conn.createStatement();
			ResultSet results = statement.executeQuery("SELECT * FROM "	+ table_name);
			// Get resultset metadata
			ResultSetMetaData metadata = results.getMetaData();
			int columnCount = metadata.getColumnCount();
			System.out.println(table_name + " columns : " + columnCount);

			// Get the column names; column indices start from 1
			
			for (int i = 1; i <= columnCount; i++) {
				String columnName = metadata.getColumnName(i);
				list.add(columnName);
				System.out.println(columnName);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub

		GetRefDetails ref = new GetRefDetails();
		Map<String, List<String>> map = ref.getEntity();
		System.out.println("Printing all table and column:---------------");
		for (String id : map.keySet()) {
			System.out.println(id);

			List<String> values = map.get(id);
			for (String value : values) {
				System.out.print(value + "\t");
			}
			System.out.println("\n");
		}
		
		List list1 = ref.getColumnNames("Employee");
		System.out.println("-------"+list1);
	}*/

}
