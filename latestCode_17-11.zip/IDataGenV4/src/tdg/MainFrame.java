/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tdg;



import java.awt.CardLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import tdg.AddAssetClassDialog;
import tdg.AddGroupDialog;
import tdg.AddSubGroupDialog;
import tdg.ConfigureFilePanel1Class;
import tdg.ConfigureFilePanel2Class;
import tdg.DefineFieldsPanel;
import SchemaCreation.EntryPanel;

import com.igate.constants.GroupType;
import com.igate.db.dao.GetRefDetailsDAO;
import com.igate.dto.ColumnDetail;
import com.igate.dto.GroupRecord;
import com.igate.service.ServiceManager;

import datafabricationmodule.dataFabricatorPanel;

/**
 *
 * @author sh834131
 */
public class MainFrame extends javax.swing.JFrame {

    private static MainFrame myMainFrame = null;
    private static String currentCard = "";
    
    public static MainFrame getInstance(){
        if(myMainFrame == null){
            myMainFrame = new MainFrame();
        }
        return(myMainFrame);
    }
    
    javax.swing.tree.DefaultMutableTreeNode rootNode1;
    static javax.swing.tree.DefaultMutableTreeNode rootNode2;
    protected DefaultTreeModel treeModel;
    protected static DefaultTreeModel treeModel1;
   
    //Two backup Maps. Needs to be updated when any update happen in group tree in the GUI
    private Map<Integer, javax.swing.tree.DefaultMutableTreeNode> mygroupmapById = new HashMap<>();
    private Map<String, GroupRecord> groupMapByName = new HashMap<>();
    
    public List<GroupRecord> getAll1stLevleGroup(){
    	return getAllSubGroups0(null);    	    	
    }
    
    public List<GroupRecord> getAllSubGroups(GroupRecord parent){
    	return getAllSubGroups0(parent);
    }
    private List<GroupRecord> getAllSubGroups0(GroupRecord parent){
    	List<GroupRecord> groups = new ArrayList<>();
    	int parentId = 0;
    	if(null != parent) parentId = parent.getId();
    	
    	Set<Entry<String, GroupRecord>>  entryset = groupMapByName.entrySet();
    	Iterator<Entry<String,GroupRecord>> itr =  entryset.iterator();
    	while(itr.hasNext()){
    		Entry<String, GroupRecord> entry = itr.next();
    		GroupRecord gr = entry.getValue();
    		if(gr.getType() == GroupType.GROUP && gr.getParentId() == parentId){
    			groups.add(gr);
    		}
    	}
    	return groups;
    }
    
    public Map<String, GroupRecord> getGroupMapByName(){
    	return groupMapByName;
    }
    
    public  Map<Integer, javax.swing.tree.DefaultMutableTreeNode> getGroupMapNodeById(){
    	return mygroupmapById;
    }
    
    public  GroupRecord getGroupRecordDetailByName(String name){
    	return groupMapByName.get(name);
    }
    
    public boolean isGroupPresent(String gname){
    	
    	if(null == groupMapByName.get(gname)) return false;
    	return true;
    }
    public GroupRecord getGroupByName(String gname){
    	
    	return groupMapByName.get(gname);
    }
    
    public void putIntoGroupTree(GroupRecord gr){
    	javax.swing.tree.DefaultMutableTreeNode childnode = new javax.swing.tree.DefaultMutableTreeNode(gr);
    	javax.swing.tree.DefaultMutableTreeNode pnode = mygroupmapById.get(gr.getParentId());
    	//System.out.println("inside putIntoGroupTree:: "+gr.getId()+","+gr.getName()+","+gr.getParentId());
    	if(null == pnode){
    		// need to do some kind of refresh
    	//	System.out.println("inside putIntoGroupTree:: Not getting any parent noe");
    	}
    	else{
    		//System.out.println("inside putIntoGroupTree:: getting any parent noe"+pnode.toString());
    		addObject(pnode, childnode, true);
        	mygroupmapById.put(gr.getId(), childnode);
        	groupMapByName.put(gr.getName(),gr);
    	}
    }
    
    private DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent,
		DefaultMutableTreeNode child, boolean shouldBeVisible) {
	    // It is key to invoke this on the TreeModel, and NOT DefaultMutableTreeNode
	    treeModel.insertNodeInto(child, parent, parent.getChildCount());
	    //System.out.println(""+child.toString()+", "+parent.toString()+","+parent.getChildCount()+","+child.getPath().length);
	    
	    // Make sure the user can see the lovely new node.
	    if (shouldBeVisible) {
	    	jTree1.scrollPathToVisible(new TreePath(child.getPath()));
	    }
	    jScrollPanel1.setViewportView(jTree1);
	    return child;
    }
    /**
     * Creates new form MainFrame
     */
    private MainFrame() {
        initComponents();
         getMainSubPanel().setVisible(false);
     	 jScrollPanel1.setVisible(true);
         jScrollPanel2.setVisible(false);
       
    }

    private void initComponents() {

    	jSchemaLabel= new javax.swing.JLabel();

        defineFieldsFileChooser = new javax.swing.JFileChooser();
        configureFile2FileChooser = new javax.swing.JFileChooser();
        dataFabricatorPanel1 = new datafabricationmodule.dataFabricatorPanel();
        dataFabricatorFileChooser = new javax.swing.JFileChooser();
        mainPanel = new tdg.MainPanel();
        jTreePanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPanel1 = new javax.swing.JScrollPane();
     //   jTree1 = new javax.swing.JTree();
        mainSubPanel = new javax.swing.JPanel();
        configureFilePanel2OuterPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        configureFilePanel2Class2 = ConfigureFilePanel2Class.getInstance();
        configureFilePanel1OuterPanel = new javax.swing.JPanel();
        configureFilePanel1Class2 = ConfigureFilePanel1Class.getInstance();
        defineFieldsOuterPanel = new javax.swing.JPanel();
        defineFieldsPanel1 = DefineFieldsPanel.getInstance();
        createRulesPanel = new javax.swing.JPanel();
        createRules1 = datafabricationmodule.CreateRules.getInstance();
        dataFabricatorOuterPanel = new javax.swing.JPanel();
        dataFabricatorPanel2 = new datafabricationmodule.dataFabricatorPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        UserMenu = new javax.swing.JMenu();
        ConfigurerMenuItem = new javax.swing.JMenuItem();
        Exit = new javax.swing.JMenuItem();
        AdminMenu = new javax.swing.JMenu();
        jMenuItemAddGroup = new javax.swing.JMenuItem();
        jMenuItemAddSubGroup = new javax.swing.JMenuItem();
        jMenuItemAddClass = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItemDataFabrication = new javax.swing.JMenuItem();
        HelpMenu = new javax.swing.JMenu();
        jMenuItemAbout = new javax.swing.JMenuItem();
        jMenuItemDataSchema=new javax.swing.JMenuItem();
        jMenuItemModifySchema=new javax.swing.JMenuItem();
        
        //Jtree2
        jLayeredPane1 = new javax.swing.JLayeredPane();
        mainSubPanel1=new javax.swing.JPanel();
        jTreePanel2 = new javax.swing.JPanel();        
        jScrollPanel2 = new javax.swing.JScrollPane();
        
        jScrollPanel2.setVisible(false);

        jTreePanel2.setBackground(new java.awt.Color(0, 102, 153));
        jTreePanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTreePanel2.setName("JTreePanel"); // NOI18N
        
        // This is the root Node
        rootNode2 = new javax.swing.tree.DefaultMutableTreeNode("idatagendb");
     
        //This piece is code is added for adding individual tables to respective models
        
        getchildnodes();
      
        
        EntryPanelClass1 = EntryPanel.getInstance();
        mainPanel = new tdg.MainPanel();
        entryOuterPanel= new javax.swing.JPanel();
        
        dataInsertionOuterPanel=new javax.swing.JPanel();
        DataInsertionPanelClass=new SchemaCreation.DataInsertion().getInstance();
        
        modifySchemaOuterPanel=new javax.swing.JPanel();
        modifySchemaPanelClass=new SchemaCreation.ModifySchema().getInstance();
        
        createRulesPanel = new javax.swing.JPanel();
        createRules1 = datafabricationmodule.CreateRules.getInstance();
        dataFabricatorOuterPanel = new javax.swing.JPanel();
        dataFabricatorPanel2 = datafabricationmodule.dataFabricatorPanel.getInstance();

        configureFile2FileChooser.setDialogType(javax.swing.JFileChooser.SAVE_DIALOG);
        dataFabricatorFileChooser.setDialogType(javax.swing.JFileChooser.SAVE_DIALOG);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Test Data Generator");
        setResizable(false);

        mainPanel.setBackground(new java.awt.Color(0, 102, 153));
        mainPanel.setLayout(new java.awt.BorderLayout(20, 0));

        jTreePanel1.setBackground(new java.awt.Color(0, 102, 153));
        jTreePanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTreePanel1.setName("JTreePanel"); // NOI18N
           
        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("IGate_logo.png"))); // NOI18N
        jLabel1.setOpaque(true);

        mainSubPanel1.setBackground(new java.awt.Color(0, 102, 153));
        mainSubPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        mainSubPanel1.setLayout(new java.awt.CardLayout());
        
        
        rootNode1 = new javax.swing.tree.DefaultMutableTreeNode("Groups");
        //treeModel = new DefaultTreeModel(rootNode1);
        treeModel = new DefaultTreeModel(rootNode2);
        jTree1 = new javax.swing.JTree(treeModel);
        jTree1.setEditable(true);
        jTree1.getSelectionModel().setSelectionMode(
        		TreeSelectionModel.SINGLE_TREE_SELECTION);
        jTree1.setShowsRootHandles(true);
        mygroupmapById.put(0, rootNode1);
        ServiceManager sm = new ServiceManager();
        List<GroupRecord> level1goups = sm.getAllGroupItems();
        
        for (GroupRecord groupRecord : level1goups) {
        	groupMapByName.put(groupRecord.getName(),groupRecord);
        	javax.swing.tree.DefaultMutableTreeNode childnode = new javax.swing.tree.DefaultMutableTreeNode(groupRecord);
        	javax.swing.tree.DefaultMutableTreeNode pnode = mygroupmapById.get(groupRecord.getParentId());
        	if(null == pnode){
        		//System.out.println("Exception "+groupRecord);
        		continue;
        	}
        	pnode.add(childnode);
        	mygroupmapById.put(groupRecord.getId(), childnode);
		}
        ImageIcon leafIcon = new ImageIcon(getClass().getResource("leaf_icon.png"));//createImageIcon(imageURL,"leaf node icon");
        if (leafIcon != null) {
            DefaultTreeCellRenderer renderer =
            new DefaultTreeCellRenderer();
            renderer.setLeafIcon(leafIcon);
            jTree1.setCellRenderer(renderer);
        }
        
        jScrollPanel1.setViewportView(jTree1);
        jTree1.getSelectionModel().addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
            	
                selectedNode = (DefaultMutableTreeNode) jTree1.getLastSelectedPathComponent();
                if(currentCard.equals("") || currentCard.equals("configureFile1Card") &&  selectedNode.isLeaf()){
                	ServiceManager sm = new ServiceManager();
                	List<ColumnDetail> clist = sm.getAllColumns(selectedNode.getUserObject().toString());
                	
                	//System.out.println("clist from MainFrame ============"+clist);
                	ConfigureFilePanel1Class configpage1 = ConfigureFilePanel1Class.getInstance();
                	DefaultListModel<ColumnDetail> model = (DefaultListModel<ColumnDetail>)configpage1.getList1().getModel();
                	model.clear();
                	configpage1.getSelectedColumnListModel().clear(); // added by Smita
                	for (ColumnDetail cd : clist) {
                		model.addElement(cd);
					}
                	//System.out.println("model==================>"+model);
                	
                }
            }
        });

        jScrollPanel1.setViewportView(jTree1);

        javax.swing.GroupLayout jTreePanelLayout = new javax.swing.GroupLayout(jTreePanel1);
        jTreePanel1.setLayout(jTreePanelLayout);
        jTreePanelLayout.setHorizontalGroup(
            jTreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jTreePanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jTreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jTreePanelLayout.setVerticalGroup(
            jTreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jTreePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jScrollPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        

        jScrollPanel2.setViewportView(jTree2);

        javax.swing.GroupLayout jTreePanelLayout1 = new javax.swing.GroupLayout(jTreePanel2);
        jTreePanel2.setLayout(jTreePanelLayout);
        jTreePanelLayout1.setHorizontalGroup(
        		jTreePanelLayout1.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jTreePanelLayout1.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jTreePanelLayout1.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jTreePanelLayout1.setVerticalGroup(
        		jTreePanelLayout1.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jTreePanelLayout1.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jScrollPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(70, Short.MAX_VALUE))
        );

       /*  mainPanel.add(jTreePanel2,java.awt.BorderLayout.WEST);
                  
         
        //mainSubPanel1.add(jTreePanel1, "JtreePanel1");
        mainPanel.add(jTreePanel1,java.awt.BorderLayout.WEST);*/
        
        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
		jLayeredPane1.setLayout(jLayeredPane1Layout);
		jLayeredPane1Layout.setHorizontalGroup(jLayeredPane1Layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jScrollPanel1,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				.addComponent(jScrollPanel2,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		jLayeredPane1Layout.setVerticalGroup(jLayeredPane1Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jLayeredPane1Layout
									.createSequentialGroup()
										.addComponent(jScrollPanel1,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jScrollPanel2,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE)));
		jLayeredPane1.setLayer(jScrollPanel1,javax.swing.JLayeredPane.DEFAULT_LAYER);
		jLayeredPane1.setLayer(jScrollPanel2,javax.swing.JLayeredPane.DEFAULT_LAYER);
            
        
		javax.swing.GroupLayout jPanelLayout1 = new javax.swing.GroupLayout(mainSubPanel1);
		mainSubPanel1.setLayout(jPanelLayout1);
		jPanelLayout1.setHorizontalGroup(
				jPanelLayout1.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout1.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanelLayout1.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE))
                .addContainerGap(19, Short.MAX_VALUE))
        );
		jPanelLayout1.setVerticalGroup(
				jPanelLayout1.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout1.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        mainPanel.add(mainSubPanel1,java.awt.BorderLayout.WEST);
        
        mainSubPanel.setBackground(new java.awt.Color(0, 102, 153));
        mainSubPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        mainSubPanel.setLayout(new java.awt.CardLayout());

        configureFilePanel2OuterPanel.setBackground(new java.awt.Color(0, 102, 153));
        configureFilePanel2OuterPanel.setForeground(new java.awt.Color(0, 102, 153));
        configureFilePanel2OuterPanel.setPreferredSize(new java.awt.Dimension(1060, 600));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Specify conditions in Queriable Grid, Fetch records and Export");

        javax.swing.GroupLayout configureFilePanel2OuterPanelLayout = new javax.swing.GroupLayout(configureFilePanel2OuterPanel);
        configureFilePanel2OuterPanel.setLayout(configureFilePanel2OuterPanelLayout);
        configureFilePanel2OuterPanelLayout.setHorizontalGroup(
            configureFilePanel2OuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(configureFilePanel2OuterPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(configureFilePanel2Class2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(configureFilePanel2OuterPanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        configureFilePanel2OuterPanelLayout.setVerticalGroup(
            configureFilePanel2OuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(configureFilePanel2OuterPanelLayout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(configureFilePanel2Class2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainSubPanel.add(configureFilePanel2OuterPanel, "configureFile2Card");

        configureFilePanel1OuterPanel.setBackground(new java.awt.Color(0, 102, 153));
        configureFilePanel1OuterPanel.setPreferredSize(new java.awt.Dimension(1060, 600));

        javax.swing.GroupLayout configureFilePanel1OuterPanelLayout = new javax.swing.GroupLayout(configureFilePanel1OuterPanel);
        configureFilePanel1OuterPanel.setLayout(configureFilePanel1OuterPanelLayout);
        configureFilePanel1OuterPanelLayout.setHorizontalGroup(
            configureFilePanel1OuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, configureFilePanel1OuterPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(configureFilePanel1Class2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        configureFilePanel1OuterPanelLayout.setVerticalGroup(
            configureFilePanel1OuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(configureFilePanel1OuterPanelLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(configureFilePanel1Class2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainSubPanel.add(configureFilePanel1OuterPanel, "configureFile1Card");

        defineFieldsOuterPanel.setBackground(new java.awt.Color(0, 102, 153));
        defineFieldsOuterPanel.setPreferredSize(new java.awt.Dimension(1060, 600));

        javax.swing.GroupLayout defineFieldsOuterPanelLayout = new javax.swing.GroupLayout(defineFieldsOuterPanel);
        defineFieldsOuterPanel.setLayout(defineFieldsOuterPanelLayout);
        defineFieldsOuterPanelLayout.setHorizontalGroup(
            defineFieldsOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(defineFieldsOuterPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(defineFieldsPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        defineFieldsOuterPanelLayout.setVerticalGroup(
            defineFieldsOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(defineFieldsOuterPanelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(defineFieldsPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 634, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainSubPanel.add(defineFieldsOuterPanel, "defineFieldsCard");

       
        createRulesPanel.setBackground(new java.awt.Color(0, 102, 153));
        createRulesPanel.setName("createRulesPanel"); // NOI18N
        createRulesPanel.setPreferredSize(new java.awt.Dimension(1060, 600));

        createRules1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        createRules1.setName("createRules1"); // NOI18N

        javax.swing.GroupLayout createRulesPanelLayout = new javax.swing.GroupLayout(createRulesPanel);
        createRulesPanel.setLayout(createRulesPanelLayout);
        createRulesPanelLayout.setHorizontalGroup(
            createRulesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, createRulesPanelLayout.createSequentialGroup()
                .addContainerGap(50, Short.MAX_VALUE)
                .addComponent(createRules1, javax.swing.GroupLayout.PREFERRED_SIZE, 973, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
        );
        createRulesPanelLayout.setVerticalGroup(
            createRulesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, createRulesPanelLayout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addComponent(createRules1, javax.swing.GroupLayout.PREFERRED_SIZE, 656, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );

        mainSubPanel.add(createRulesPanel, "createRulesCard");

        dataFabricatorOuterPanel.setBackground(new java.awt.Color(0, 102, 153));
        dataFabricatorOuterPanel.setPreferredSize(new java.awt.Dimension(1060, 600));

        javax.swing.GroupLayout dataFabricatorOuterPanelLayout = new javax.swing.GroupLayout(dataFabricatorOuterPanel);
        dataFabricatorOuterPanel.setLayout(dataFabricatorOuterPanelLayout);
        dataFabricatorOuterPanelLayout.setHorizontalGroup(
            dataFabricatorOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataFabricatorOuterPanelLayout.createSequentialGroup()
                .addComponent(dataFabricatorPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        dataFabricatorOuterPanelLayout.setVerticalGroup(
            dataFabricatorOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataFabricatorOuterPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dataFabricatorPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainSubPanel.add(dataFabricatorOuterPanel, "dataFabricatorCard");

       /* jSchemaLabel.setText("Load the Data Model");
        jSchemaLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jSchemaLabel.setForeground(new java.awt.Color(255, 255, 255));*/
      //Add Schema card
        entryOuterPanel.setBackground(new java.awt.Color(0, 102,153));
        entryOuterPanel.setPreferredSize(new java.awt.Dimension(1060, 600));        
              
              javax.swing.GroupLayout CreateSchemaOuterPanelLayout = new javax.swing.GroupLayout(entryOuterPanel);
              entryOuterPanel.setLayout(CreateSchemaOuterPanelLayout);
              CreateSchemaOuterPanelLayout.setHorizontalGroup(CreateSchemaOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                  .addGroup(CreateSchemaOuterPanelLayout.createSequentialGroup()
                  .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE)
                  .addComponent(EntryPanelClass1,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
                  .addContainerGap()
                  .addGroup(CreateSchemaOuterPanelLayout.createSequentialGroup()
                  //.addComponent(jSchemaLabel,javax.swing.GroupLayout.PREFERRED_SIZE, 388,javax.swing.GroupLayout.PREFERRED_SIZE)
                  .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE))
              ));
              CreateSchemaOuterPanelLayout.setVerticalGroup(CreateSchemaOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                  .addGroup(CreateSchemaOuterPanelLayout.createSequentialGroup()
                  .addGap(28, 28, 28)
                  //.addComponent(jSchemaLabel)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(EntryPanelClass1,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)                      
                  .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE))
              );

              mainSubPanel.add(entryOuterPanel, "entrypanelcard");
              
              dataInsertionOuterPanel.setBackground(new java.awt.Color(0, 102,153));
              dataInsertionOuterPanel.setPreferredSize(new java.awt.Dimension(1060, 600));        
                    
                    javax.swing.GroupLayout DataInsertionOuterPanelLayout = new javax.swing.GroupLayout(dataInsertionOuterPanel);
                    dataInsertionOuterPanel.setLayout(DataInsertionOuterPanelLayout);
                    DataInsertionOuterPanelLayout.setHorizontalGroup(DataInsertionOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(DataInsertionOuterPanelLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE)
                        .addComponent(DataInsertionPanelClass,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap()
                        .addGroup(DataInsertionOuterPanelLayout.createSequentialGroup()
                        .addComponent(jSchemaLabel,javax.swing.GroupLayout.PREFERRED_SIZE, 388,javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE))
                    ));
                    DataInsertionOuterPanelLayout.setVerticalGroup(DataInsertionOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(DataInsertionOuterPanelLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jSchemaLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DataInsertionPanelClass,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)                      
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE))
                    );

                    mainSubPanel.add(dataInsertionOuterPanel, "dataInsertioncard");
                    
                    modifySchemaOuterPanel.setBackground(new java.awt.Color(0, 102,153));
                    modifySchemaOuterPanel.setPreferredSize(new java.awt.Dimension(1060, 600));        
                          
                          javax.swing.GroupLayout ModifySchemaOuterPanelLayout = new javax.swing.GroupLayout(modifySchemaOuterPanel);
                          modifySchemaOuterPanel.setLayout(ModifySchemaOuterPanelLayout);
                          ModifySchemaOuterPanelLayout.setHorizontalGroup(ModifySchemaOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                              .addGroup(ModifySchemaOuterPanelLayout.createSequentialGroup()
                              .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE)
                              .addComponent(modifySchemaPanelClass,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addContainerGap()
                              .addGroup(ModifySchemaOuterPanelLayout.createSequentialGroup()
                              //.addComponent(jSchemaLabel,javax.swing.GroupLayout.PREFERRED_SIZE, 388,javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE))
                          ));
                          ModifySchemaOuterPanelLayout.setVerticalGroup(ModifySchemaOuterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                              .addGroup(ModifySchemaOuterPanelLayout.createSequentialGroup()
                              .addGap(28, 28, 28)
                              //.addComponent(jSchemaLabel)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(modifySchemaPanelClass,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)                      
                              .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE))
                          );

                          mainSubPanel.add(modifySchemaOuterPanel, "modifyschemacard");
              
        mainPanel.add(mainSubPanel, java.awt.BorderLayout.EAST);

        jMenuBar1.setBackground(new java.awt.Color(0, 102, 153));
        jMenuBar1.setForeground(new java.awt.Color(0, 102, 153));

        UserMenu.setText("User");

        ConfigurerMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        ConfigurerMenuItem.setText("Configure File");
        ConfigurerMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfigurerMenuItemActionPerformed(evt);
            }
        });
        UserMenu.add(ConfigurerMenuItem);

        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });
        UserMenu.add(Exit);

        jMenuBar1.add(UserMenu);

        AdminMenu.setText("Admin");

        jMenuItemAddGroup.setText("Add Asset Group");
        jMenuItemAddGroup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemAddGroupActionPerformed(evt);
            }
        });
        AdminMenu.add(jMenuItemAddGroup);
        
        AdminMenu.setEnabled(false);
        UserMenu.setEnabled(false);
        
        jMenuItemAddSubGroup.setText("Add Asset Sub Group");
        jMenuItemAddSubGroup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemAddSubGroupActionPerformed(evt);
            }
        });
        AdminMenu.add(jMenuItemAddSubGroup);

        jMenuItemAddClass.setText("Add Asset Class");
        jMenuItemAddClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemAddClassActionPerformed(evt);
            }
        });
        AdminMenu.add(jMenuItemAddClass);

        jMenuItem1.setText("Define Fields");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        AdminMenu.add(jMenuItem1);

        jMenuItemDataFabrication.setText("Data Fabrication");
        jMenuItemDataFabrication.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemDataFabricationActionPerformed(evt);
            }
        });
        AdminMenu.add(jMenuItemDataFabrication);

        jMenuBar1.add(AdminMenu);

        HelpMenu.setText("SchemaCreation");

        
        jMenuItemAbout.setText("Add Schema");
        jMenuItemAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	AddSchemaMenuItemActionPerformed(evt);
            }
        });
        
        HelpMenu.add(jMenuItemAbout);
        
        jMenuItemModifySchema.setText("Drop Schema");
        jMenuItemModifySchema.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	ModifyDataSchemaMenuItemActionPerformed(evt);
            }
        });
        
        HelpMenu.add(jMenuItemModifySchema);
        jMenuItemModifySchema.setEnabled(true);
        
        jMenuItemDataSchema.setText("Generate Data");
        jMenuItemDataSchema.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	AddDataSchemaMenuItemActionPerformed(evt);
            }
        });
        
        HelpMenu.add(jMenuItemDataSchema);

        jMenuBar1.add(HelpMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);    
     }// </editor-fold>//GEN-END:initComponents

 
	// ADD ASSET GROUP MENU SELECTED
    private void jMenuItemAddGroupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemAddGroupActionPerformed
    	
    	// TODO add your handling code here:
       // AddGroupDialog.getInstance().setVisible(true);
    	 AddGroupDialog groupDialog = new AddGroupDialog(MainFrame.getInstance(), true);
    	 groupDialog.setVisible(true);
    	 jScrollPanel1.setVisible(true);
         jScrollPanel2.setVisible(false);
    }//GEN-LAST:event_jMenuItemAddGroupActionPerformed

    private void jMenuItemAddSubGroupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemAddSubGroupActionPerformed
    
    	// TODO add your handling code here:
    	AddSubGroupDialog subdialog = new AddSubGroupDialog(MainFrame.getInstance(), true);
    	subdialog.setVisible(true);
    	jScrollPanel1.setVisible(true);
        jScrollPanel2.setVisible(false);
    	/*AddSubGroupDialog subdialog = AddSubGroupDialog.getInstance();
    	subdialog.loadGroupCombo();
    	subdialog.setVisible(true);*/
    }//GEN-LAST:event_jMenuItemAddSubGroupActionPerformed

    private void jMenuItemAddClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemAddClassActionPerformed
    	
        
    	// TODO add your handling code here:
        // AddAssetClassDialog.getInstance().setVisible(true);
    	AddAssetClassDialog assetclass = new AddAssetClassDialog(MainFrame.getInstance(), true);
    	assetclass.setVisible(true);
    	
    }//GEN-LAST:event_jMenuItemAddClassActionPerformed

    private void ConfigurerMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfigurerMenuItemActionPerformed
       jScrollPanel1.setVisible(true);
       jScrollPanel2.setVisible(false);
    	getMainSubPanel().setVisible(true);
       ConfigureFilePanel1Class.getInstance().clearForm();
       CardLayout card = (CardLayout)getMainSubPanel().getLayout();
       card.show(getMainSubPanel(), "configureFile1Card");         //configureFile1
       currentCard = "configureFile1Card";
    }//GEN-LAST:event_ConfigurerMenuItemActionPerformed

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
          System.exit(0);
    }//GEN-LAST:event_ExitActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
    	jScrollPanel1.setVisible(true);
        jScrollPanel2.setVisible(false);
    	// TODO add your handling code here:
    	DefineFieldsPanel.getInstance().clearForm();
        getMainSubPanel().setVisible(true);
        CardLayout card = (CardLayout)getMainSubPanel().getLayout();
        card.show(getMainSubPanel(), "defineFieldsCard"); 
        currentCard = "defineFieldsCard";
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItemDataFabricationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemDataFabricationActionPerformed
    	jScrollPanel1.setVisible(true);
        jScrollPanel2.setVisible(false);
    	dataFabricatorPanel.getInstance().clearForm();
		getMainSubPanel().setVisible(true);
	    CardLayout card = (CardLayout)getMainSubPanel().getLayout();
	    card.show(getMainSubPanel(), "dataFabricatorCard"); 
    }//GEN-LAST:event_jMenuItemDataFabricationActionPerformed
    
    private void AddSchemaMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN- FIRST:event_ConfigurerMenuItemActionPerformed           
    	jScrollPanel1.setVisible(false);
    	jScrollPanel2.setVisible(true);
    	
    	getMainSubPanel().setVisible(true);
        EntryPanelClass1.getInstance().clearForm();
        CardLayout card = (CardLayout)getMainSubPanel().getLayout();
        card.show(getMainSubPanel(), "entrypanelcard");            
        currentCard="entrypanelcard";
//configureFile1
       }//GEN-LAST:event_ConfigurerMenuItemActionPerformed
    
    private void AddDataSchemaMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN- FIRST:event_ConfigurerMenuItemActionPerformed           
    	jScrollPanel1.setVisible(false);
        jScrollPanel2.setVisible(true);
        
    	getMainSubPanel().setVisible(true);
        DataInsertionPanelClass.getInstance().clearForm();
        DataInsertionPanelClass.getComboBox();
        CardLayout card = (CardLayout)getMainSubPanel().getLayout();
        card.show(getMainSubPanel(), "dataInsertioncard");            
        currentCard="dataInsertioncard";
//configureFile1
       }//GEN-LAST:event_ConfigurerMenuItemActionPerformed
    
    private void ModifyDataSchemaMenuItemActionPerformed(java.awt.event.ActionEvent evt) {
    	jScrollPanel1.setVisible(false);
        jScrollPanel2.setVisible(true);
        
    	getMainSubPanel().setVisible(true);
    	modifySchemaPanelClass.getComboBox();
        CardLayout card = (CardLayout)getMainSubPanel().getLayout();
        card.show(getMainSubPanel(), "modifyschemacard");            
        currentCard="modifyschemacard";
    }
    
    public DefaultMutableTreeNode getSelectedTreeItem(){
    	TreePath currentSelection = jTree1.getSelectionPath();
        if (currentSelection != null) {
          DefaultMutableTreeNode currentNode = (DefaultMutableTreeNode) (currentSelection.getLastPathComponent());
          return currentNode;
        }
        return null;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                  //  System.out.println("info.getClassName()"+info.getClassName());
                    
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               MainFrame.getInstance().setVisible(true);
            }
        });
    }
   public javax.swing.JPanel getMainPanel(){
        return this.mainPanel;
    }
     public javax.swing.JPanel getMainSubPanel(){
        return this.mainSubPanel;
    }
     public javax.swing.JPanel getMainSubPanel1(){
         return this.mainSubPanel;
     }
     
     public javax.swing.JFileChooser getdefineFieldsFileChooser(){
        return this.defineFieldsFileChooser;
    }
     
     public javax.swing.JFileChooser getconfigureFile2FileChooser(){
        return this.configureFile2FileChooser;
    }
    
     public  DefaultMutableTreeNode getSelectedNode(){
     	return  selectedNode;
      }
     public javax.swing.JFileChooser getDataFabricatorFileChooser(){
         return this.dataFabricatorFileChooser;
     }
     /** Returns an ImageIcon, or null if the path was invalid. */
    protected ImageIcon createImageIcon(String path,
                                           String description) {
        java.net.URL imgURL = getClass().getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL, description);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
      
    
    public static void getchildnodes(){
        
        Set<String> dataModelList = new ServiceManager().getDataModels();
        DefaultMutableTreeNode table;
        for (String dataModel : dataModelList) {
        	
        	DefaultMutableTreeNode model = new DefaultMutableTreeNode(dataModel);
        	rootNode2.add(model);
        	//To get list of tables
        	Set<String> tableNameList = new ServiceManager().getTables(dataModel);
        	
        	for(String tableName:tableNameList)
        	{
        		tableName = tableName.substring(tableName.indexOf("_")+1,tableName.length());
        		model.add(table = new DefaultMutableTreeNode(tableName));
        		
        	}
		}
        
        treeModel1 = new DefaultTreeModel(rootNode2);
        jTree2 = new javax.swing.JTree(treeModel1);
        jTree2.setEditable(true);
        jTree2.getSelectionModel().setSelectionMode(
        		TreeSelectionModel.SINGLE_TREE_SELECTION);
        jTree2.setShowsRootHandles(true);
/*        
        
    	treeModel1.reload(rootNode2);
    	
    	
    	return rootNode2; */
    }
    
    /*private void jTree1TreeExpanded(javax.swing.event.TreeExpansionEvent evt) {                                    
        // TODO add your handling code here:
    	treeModel1.reload(getchildnodes());
    }*/
    
    
    
    private javax.swing.JMenu AdminMenu;
    private javax.swing.JMenuItem ConfigurerMenuItem;
    private javax.swing.JMenuItem Exit;
    private javax.swing.JMenu HelpMenu;
    private javax.swing.JMenu UserMenu;
    private javax.swing.JFileChooser configureFile2FileChooser;
    private tdg.ConfigureFilePanel1Class configureFilePanel1Class2;
    private javax.swing.JPanel configureFilePanel1OuterPanel;
    private tdg.ConfigureFilePanel2Class configureFilePanel2Class2;
    private javax.swing.JPanel configureFilePanel2OuterPanel;
    private javax.swing.JFileChooser defineFieldsFileChooser;
    private javax.swing.JPanel defineFieldsOuterPanel;
    private tdg.DefineFieldsPanel defineFieldsPanel1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItemDataSchema;
    private javax.swing.JMenuItem jMenuItemModifySchema;
    private javax.swing.JMenuItem jMenuItemAbout;
    private javax.swing.JMenuItem jMenuItemAddClass;
    private javax.swing.JMenuItem jMenuItemAddGroup;
    private javax.swing.JMenuItem jMenuItemAddSubGroup;
    private javax.swing.JMenuItem jMenuItemDataFabrication;
    private javax.swing.JScrollPane jScrollPanel1;
    private javax.swing.JTree jTree1;
    private javax.swing.JPanel jTreePanel1;
    private tdg.MainPanel mainPanel;
    private javax.swing.JPanel mainSubPanel;
    DefaultMutableTreeNode selectedNode;
    
   //Variables for jtree2
    
    private javax.swing.JScrollPane jScrollPanel2;
    private static javax.swing.JTree jTree2;
    private javax.swing.JPanel jTreePanel2;
   
    private javax.swing.JPanel mainSubPanel1;
    private javax.swing.JLayeredPane jLayeredPane1;
    
    //Create schema variables
    //private tgd.MainPanel mainPanel;
    private javax.swing.JLabel jSchemaLabel;
    private javax.swing.JPanel entryOuterPanel;
    private EntryPanel EntryPanelClass1;
    
    private javax.swing.JPanel modifySchemaOuterPanel;
    private SchemaCreation.ModifySchema modifySchemaPanelClass;
    
    private javax.swing.JPanel dataInsertionOuterPanel;
    private SchemaCreation.DataInsertion DataInsertionPanelClass;
    //Added fields for DF
    private javax.swing.JFileChooser dataFabricatorFileChooser;
    private javax.swing.JPanel dataFabricatorOuterPanel;
    private datafabricationmodule.dataFabricatorPanel dataFabricatorPanel1;
    private datafabricationmodule.dataFabricatorPanel dataFabricatorPanel2;
    private javax.swing.JPanel createRulesPanel;
    private datafabricationmodule.CreateRules createRules1;
}
