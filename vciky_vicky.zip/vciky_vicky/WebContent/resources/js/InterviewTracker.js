
$(document).ready(function(){
       $('#interviewTrack').click(function(){
    	$('#resultDiv').hide();
		var resource= $('#resourceName').val();
		var interviewDate=$('#datepicker').val();
		var clientMgr=$('#clientManager').val();
		var technology =$('#technologyStack').val();
		var projectId=$('#teamInterviewedFor').val();
		var interViewRound=$('#roundNumber').val();
		var interviewStatus=$('#status').val();
		var interviewLoc=$('#location').val();
		var interviewMode=$('#modeOfInterview').val();
		if(resource == 0 || resource.length == 0 || resource == undefined ){
			$('#resultDiv').html("Please Select Resource Name.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(interviewDate == 0 || interviewDate.length == 0 || interviewDate == undefined ){
			$('#resultDiv').html("Please Select Date of Interview.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(clientMgr == 0 || clientMgr.length == 0 || clientMgr == undefined ){
			$('#resultDiv').html("Please Enter Client Manager Name.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(technology == 0 || technology.length == 0 || technology == undefined ){
			$('#resultDiv').html("Please Enter Technology Stack.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(projectId == 0 || projectId.length == 0 || projectId == undefined ){
			$('#resultDiv').html("Please Select Project Name.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(interViewRound == 0 || interViewRound.length == 0 || interViewRound == undefined ){
			$('#resultDiv').html("Please Select Interview Rounds.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(interviewStatus == 0 || interviewStatus.length == 0 || interviewStatus == undefined ){
			$('#resultDiv').html("Please Select Interview Status.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(interviewLoc == 0 || interviewLoc.length == 0 || interviewLoc == undefined ){
			$('#resultDiv').html("Please Select Interview Location.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(interviewMode == 0 || interviewMode.length == 0 || interviewMode == undefined ){
			$('#resultDiv').html("Please Select Interview Mode.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		var data=$('form').serialize();
		$("#fade").show();
		$("#PleaseWait").show();
		$.ajax({
			url:"/GSMP/addInterViewDetials",
			data:data,
			type:"POST",
			success:function(respData){
				if(respData=="Data Updated Successfully!"){
					$('#resultDiv').removeClass('errorTD').addClass('successTD');
				}else{
					$('#resultDiv').removeClass('successTD').addClass('errorTD');
				}
				$('#resultDiv').show();
				$('#resultDiv').html(respData);
				$("#fade").hide();
				$("#PleaseWait").hide();
			},
			error:function(request,status,error){
				$("#fade").hide();
				$("#PleaseWait").hide();
			}
		});
	});
});