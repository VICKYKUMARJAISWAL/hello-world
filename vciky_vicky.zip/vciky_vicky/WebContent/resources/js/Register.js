$(document).ready(function(){
	 $("#contactNo").keydown(function (e) {
	        // Allow: backspace, delete, tab, escape, enter and .
	        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
	             // Allow: Ctrl+A, Command+A
	            (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || 
	             // Allow: home, end, left, right, down, up
	            (e.keyCode >= 35 && e.keyCode <= 40)) {
	                 // let it happen, don't do anything
	                 return;
	        }
	        // Ensure that it is a number and stop the keypress
	        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
	            e.preventDefault();
	        }
	    });
	 
	/* $("#password").on('input', function(){
		 if(!pattern.test($(this).val())){
			 	$('#resultDiv').html("Password should not have more than 12 charecters!!");
				$('#resultDiv').addClass('errorTD');
				$('#resultDiv').show();
				return false;
		 }
	    });*/
	 
	 $("#userId").keydown(function (e) {
	        // Allow: backspace, delete, tab, escape, enter and .
	        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
	             // Allow: Ctrl+A, Command+A
	            (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || 
	             // Allow: home, end, left, right, down, up
	            (e.keyCode >= 65 && e.keyCode <= 90)) {
	                 // let it happen, don't do anything
	                 return;
	        }
	        // Ensure that it is a number and stop the keypress
	        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
	            e.preventDefault();
	        }
	    });
	 
	 $('#fname, #mname, #lname').keydown(function(event){
		  // Allow controls such as backspace
		  var arr = [9,8,16,17,20,35,36,37,38,39,40,45,46];

		  // Allow letters
		  for(var i = 65; i <= 90; i++){
		    arr.push(i);
		  }

		  // Prevent default if not in array
		  if(jQuery.inArray(event.which, arr) === -1){
		    event.preventDefault();
		  }
		});
	 
	$('#regSubButton').click(function(event){
		var emailId=$('#emailId').val();
		var password=$('#password').val();
		var confPassword=$('#confpassword').val();
		var userId=$('#userId').val();
		var fname=$('#fname').val();
		var lastName=$('#lname').val();
		var contactNo=$('#contactNo').val();
		//var pattern = /^.*(?=.{6,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/;
		//var userIdPattern = /^[a-z0-9_-]{4,15}$/;
		if(userId==""|| userId==null){
			$('#resultDiv').html("Please Enter UserId!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}else if (!validateUserId(userId)){ //bug fixe
			$('#resultDiv').html("Please Enter your Employee id with intails !!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(password==""|| password==null){
			$('#resultDiv').html("please enter password!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}else if (/*!pattern.test(password*/!validatePassword(password)) {
			$('#resultDiv').html("Please Enter Proper Password!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}else if (password!=confPassword) {
			$('#resultDiv').html("Password and Confirm Password is not matching!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(fname==""|| fname==null){
			$('#resultDiv').html("please enter firstName!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(lastName =="" || lastName == null){
			$('#resultDiv').html("Please Enter Last Name!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(contactNo==""|| contactNo==null ||contactNo.length!=10 ){
			$('#resultDiv').html("please enter contactNo!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}else if(contactNo<=0){
			$('#resultDiv').html("please enter proper contactNo!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		if(!validatePhone(contactNo)){
			$('#resultDiv').html("please enter valid contactNo!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
		}
		if(emailId==""|| emailId==null){
			$('#resultDiv').html("please enter email id!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			
			return false;
		}
		if(!validateEmail(emailId)){
			$('#resultDiv').html("please enter valid email id!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
			
		}
		var data=$('form').serialize();
		$("#fade").show();
		$("#PleaseWait").show();
		$.ajax({
			url:"/GSMP/addUser",
			data:data,
			type:"POST",
			success:function(respData){
				if(respData=="Data Saved Successfully!"){
					$('#resultDiv').removeClass('errorTD').addClass('successTD');
					$('#userId').val('');
					$('#password').val('');
					$('#confpassword').val('');
					$('#fname').val('');
					$('#mname').val('');
					$('#lname').val('');
					$('#contactNo').val('');
					$('#emailId').val('');
				}else{
					$('#resultDiv').removeClass('successTD').addClass('errorTD');
				}
				
				$('#resultDiv').show();
				$('#resultDiv').html(respData);
				$("#fade").hide();
				$("#PleaseWait").hide();
			},
			error:function(request,status,error){
				alert(request.responseText);
				$("#fade").hide();
				$("#PleaseWait").hide();
			}
		});
	});
});