$(document).ready(function(){
	
	
		//JavaScript function to add user page
$('#userAddButton').click(function(event){	
	
			$('#resultDiv').removeClass('errorTD').addClass('successTD');
			$('#firstname').val('');
			$('#middlename').val('');
			$('#lastname').val('');
			$('#role').val('');
			getUserPage();
		
		
	
});



function getUserPage() {
   //alert("Hi")
	$('#addUser').load('/GSMP/loadAdminUser');
	}


});

function populateAdminUserData(userId) {
	
	$('#addUser').load('/GSMP/editAdminUser?id='+userId);
}



