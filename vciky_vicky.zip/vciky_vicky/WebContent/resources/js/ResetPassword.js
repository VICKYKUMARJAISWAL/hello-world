$(document).ready(function(){
	$('#regSubButton').click(function(event){
		var emailId=$('#emailId').val();
		alert(emailId);
	});
});