
var duration;
var startDt;
var endDt;
var duration;
var datatable;
var values=new Array();
var values1=new Array();
var newArray= new Array();
var trainingid;


$(document).ready(function(){
	  $("#startDate,#endDate").datepicker({
		dateFormat: "dd/mm/yyyy",
	   // showOn: "button",
	    buttonImage: "resources/images/cal.jpg",
	    buttonImageOnly: true,
	    showOn: "both",
	 });
		
	 
	/* $("#tableidload").load(function(){
	        alert("load function loaded");
	        var xhttp;
			  if (window.XMLHttpRequest) 
			  {
			    // code for modern browsers
			    xhttp = new XMLHttpRequest();
			    } 
			  else 
			    
			    {
			    // code for IE6, IE5
			    xhttp = new ActiveXObject("Microsoft.XMLHTTP");
			  }
	    });*/
	  
	  
	$("#contentType,#courseName,#categoryId,#trainingModeId,#venue,#startDate,#endDate,#startTime,#endTime,#duration,#remark").mouseenter(function(e)
	{
		//alert("inside the ");
		$('#resultDiv').hide();
	});
	
	
	  
	$('#trainingSubButton').click(function(event){
		
		//alert("i am in save button");
        //var errorMessage="";
		
        var contentType= $('#contentType option:selected').text();
      //  alert(contentType);
        
		var courseName=$('#courseName').val();
		//alert("course:"+courseName);
		
		var trainingCategory= $("#categoryId option:selected").text();
		//alert("trainingCategory"+trainingCategory);
		
		var trainingMode=$("#trainingModeId option:selected").text();
		//alert("trainingMode"+trainingMode);
		
		var venue=$("#venue option:selected").text();
		//alert("venue"+venue);
		
		//var venue=$('#venue :selected').text();
		
		var startDate=$('#startDate').val();
		
		alert("start date is"+startDate);
	   //var startd=compareDatesStart(startDate,'-');
	   
		
		var endDate=$('#endDate').val();
		alert("end date alert is"+endDate);
		
		
		/*var startTime=$("#startTime option:selected").text();
		alert(startTime);*/
		
		 startTime=$("#startTime").val();
		//alert("starttime"+startTime);
		
		//var starthour=compareTimesStart(startTime,':');
	      //alert(starthour);
		
		/*var endTime=$("#endTime option:selected").text();
		var endhour=compareTimesEnd(endTime,':');*/
		//alert(endhour);
		
		 endTime=$("#endTime").val();
		//alert("endtime"+endTime);
		
		/*var value=compareTimes(startTime,endTime);
	    alert("it is value"+value);*/
	    
	    
		var duration=$('#duration').val();
		//alert(duration);
		
		var remark=$('#remark').val();
		//alert(remark);
		
		//var startMeridiem=$('#startMeridiem  :selected').text();
		
	    //var endMeridiem=$('#endMeridiem  :selected').text();
		
		if(contentType==""|| contentType==null){
//			errorMessage=errorMessage+"Please enter contentType, ";
			$('#resultDiv').html("<span style='color:red'>Please enter contentType.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		
		if(contentType=="Select ContentType"){
//			errorMessage=errorMessage+"Please enter contentType, ";
			$('#resultDiv').html("<span style='color:red'>Please enter contentType.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		
		/*if(contentType!="Select ContentType" || contentType!=null)
		{
		alert("inside content check");
		
		}*/
	
		if(courseName==""|| courseName==null){
			$('#resultDiv').html("<span style='color:red'>Please enter CourseName.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			
			return false;
		}

		if(trainingCategory=="Select Category"){
//			errorMessage=errorMessage+"Please select a training category, ";
		    $('#resultDiv').html("<span style='color:red'>Please select a training category.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(trainingMode=="Select Mode"){
//			errorMessage=errorMessage+"Please select a training mode, ";
		
			$('#resultDiv').html("<span style='color:red'>Please select a training mode.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		if(venue=="Select Venue"){
			$('#resultDiv').html("<span style='color:red'>Please enter venue.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
/*		if(venue=="Select Venue"){
//			errorMessage=errorMessage+"Please select a training mode, ";
		$('#resultDiv').html("<span style='color:red'>Please select training venue.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}*/
		
		if(startDate==""|| startDate==null){
//			errorMessage=errorMessage+"Please enter start date, ";
			$('#resultDiv').html("<span style='color:red'>Please enter start date.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();	
			return false;
		}
			/*if(startd==0)
				{
				alert("inside the start date check");
				$('#resultDiv').html("<span style='color:red'> start date must be greater than or equal to todays date</span>");
				$('#resultDiv').addClass('errorTD');
				$('#resultDiv').show();	
				return false;
				}*/
		//alert("Ends 1:" + endDate);
				
		if(endDate==""|| endDate==null){
//			errorMessage=errorMessage+"Please enter end date, ";
			$('#resultDiv').html("<span style='color:red'>Please enter end date.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} 
		if(compareDates(startDate,endDate,'/') == 0) {
//			errorMessage=errorMessage+"Start Date must be less than or equal to End Date, ";
			$('#resultDiv').html("<span style='color:red'>Start Date must be less than or equal to End Date.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
		    return false;
		}

		duration1= parseInt(endDt)-parseInt(startDt);
		alert("Duration1 is"+duration1);
		if(duration==""|| duration==null){			
			$('#resultDiv').html("<span style='color:red'>Please enter duration.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(duration!=duration1)
			{
			$('#resultDiv').html("<span style='color:red'>Please enter correct duration.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
			
			}
		
		//alert("Ends 2:" + endDate);
		
		if(startTime=="" || startTime==null){
//			errorMessage=errorMessage+"Please enter start time, ";
			$('#resultDiv').html("<span style='color:red'>Please enter start time.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} 
		/*if(startMeridiem=="Select Meridiem"){
			$('#resultDiv').html("Please enter Meridiem");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} */
		if(endTime=="" || endTime==null ){
//			errorMessage=errorMessage+"Please enter end time, ";
			$('#resultDiv').html("<span style='color:red'>Please enter end time.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} 
		
		
		
		/*if(endMeridiem=="Select Meridiem"){
			$('#resultDiv').html("Please enter Meridiem.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} */
		
		/*if(compareTimes(startTime,startMeridiem,endTime,endMeridiem,':') == 0) {
			$('#resultDiv').html("Start time must be less than or equal to End time.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
		return false;
		}*/
		
		if(compareTimes(startTime,endTime) == 0) {
//			errorMessage=errorMessage+"Start time must be less than or equal to End time, ";
			//alert(endTime);
			$('#resultDiv').html("<span style='color:red'>Start time must be less than or equal to End time.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
		    return false;
		}
		
		
		/*if(duration!=value)
			{
			alert("i am in duration check");
			$('#resultDiv').html("<span style='color:red'>Please enter correct duration.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;	
			}*/
		
		if(remark==""|| remark==null){
//			errorMessage=errorMessage+"Please enter remark, ";
			$('#resultDiv').html("<span style='color:red'>Please enter remark.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		$('#resultDiv').removeClass('errorTD').addClass('successTD');

		//alert("validation completdd");
		var data=$('form').serialize();                               
		//alert(data);
		$.ajax({
			url:"/GSMP/addTraining123",
			data:data,
			type:"POST",
			success:function(respData){
				if(respData=="Data Saved Successfully!"){
					//alert("i am in saving");
					
					$('#resultDiv').removeClass('errorTD').addClass('successTD');
					$('#courseName').val('');
					$('#categories').val('');
					$('#modes').val('');
					$('#venue').val('');
					$('#startDate').val('');
					$('#endDate').val('');
					$('#duration').val('');
					$('#contentType').val('');
					$('#remark').val('');
					setTimeout(function(){location.reload();}, 1000);
				}else{
//					$('#resultDiv').html("<span style='color:red'>"+errorMessage+"</span>");
//					$('#resultDiv').show();
					//alert(" in am in errro saving");
					$('#resultDiv').removeClass('successTD').addClass('errorTD');
				}
				
				$('#resultDiv').show();
				$('#resultDiv').html(respData);
			},
			error:function(request,status,error){
				//alert("i am in error");
				//alert(status);
				//alert(error);
				//alert(request.responseText);
			}
		});
	
	});

	
	
	$('#trainingupdateButton').click(function(event){
		
		//alert("validation started");
		//code added by Ajaya 1st Sept15
		//var contentType= $('#contentType option:selected').text();
		
		var contentType=$("#contentType").val();
        //alert(contentType);
        
		var courseName=$('#courseName').val();
		//alert("course:"+courseName);
		
		var trainingCategory= $("#categoryId option:selected").text();
		//alert("trainingCategory"+trainingCategory);
		
		var trainingMode=$("#trainingModeId option:selected").text();
		//alert("trainingMode"+trainingMode);
		
		//var venue=$("#venue option:selected").text();
		
		var venue=$("#venue option:selected").text();
		//alert("venue"+venue);
		
		//var venue=$('#venue :selected').text();
		
		var startDate=$('#startDate').val();
		//alert(startDate);
		
		var endDate=$('#endDate').val();
		//alert(endDate);
		
		var startTime=$("#startTime").val();
		//alert(startTime);
		
		var endTime=$("#endTime").val();
		//alert(endTime);
		
		//var startMeridiem=$('#startMeridiem  :selected').text();
			
	    //var endMeridiem=$('#endMeridiem  :selected').text();
		
		var duration=$('#duration').val();
		//alert(duration);
		
		var remark=$('#remark').val();
		//alert(remark);
		
		
		
		if(courseName==""|| courseName==null){
			$('#resultDiv').html("<span style='color:red'>Please enter CourseName.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			
			return false;
		}

		if(trainingCategory=="Select Category"){
//			errorMessage=errorMessage+"Please select a training category, ";
		    $('#resultDiv').html("<span style='color:red'>Please select a training category.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(trainingMode=="Select Mode"){
//			errorMessage=errorMessage+"Please select a training mode, ";
		
			$('#resultDiv').html("<span style='color:red'>Please select a training mode.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(venue==""|| venue==null){
			//alert("inside venue");
			$('#resultDiv').html("<span style='color:red'>Please enter venue.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
/*		if(venue=="Select Venue"){
//			errorMessage=errorMessage+"Please select a training mode, ";
		$('#resultDiv').html("<span style='color:red'>Please select training venue.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}*/
		
		if(startDate==""||startDate==null){
//			errorMessage=errorMessage+"Please enter start date, ";
			$('#resultDiv').html("<span style='color:red'>Please enter start date.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();	
			return false;
		}
				
		//alert("Ends 1:" + endDate);
				
		if(endDate==""||endDate==null){
//			errorMessage=errorMessage+"Please enter end date, ";
			$('#resultDiv').html("<span style='color:red'>Please enter end date.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} 
		if(compareDates(startDate,endDate,'/') == 0) {
//			errorMessage=errorMessage+"Start Date must be less than or equal to End Date, ";
			$('#resultDiv').html("<span style='color:red'>Start Date must be less than or equal to End Date.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
		return false;
		}

		
		//alert("Ends 2:" + endDate);
		
		if(startTime=="Select Time"){
//			errorMessage=errorMessage+"Please enter start time, ";
			$('#resultDiv').html("<span style='color:red'>Please enter start time.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} 
		/*if(startMeridiem=="Select Meridiem"){
			$('#resultDiv').html("Please enter Meridiem");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} */
		if(endTime=="Select Time"){
//			errorMessage=errorMessage+"Please enter end time, ";
			$('#resultDiv').html("<span style='color:red'>Please enter end time.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} 
		/*if(endMeridiem=="Select Meridiem"){
			$('#resultDiv').html("Please enter Meridiem.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		} */
		
		/*if(compareTimes(startTime,startMeridiem,endTime,endMeridiem,':') == 0) {
			$('#resultDiv').html("Start time must be less than or equal to End time.");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
		return false;
		}*/
		
		if(compareTimes(startTime,endTime) == 0) {
//			errorMessage=errorMessage+"Start time must be less than or equal to End time, ";
			//alert(endTime);
			$('#resultDiv').html("<span style='color:red'>Start time must be less than or equal to End time.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
		    return false;
		}
		
		if(duration==""|| duration==null){
//			errorMessage=errorMessage+"Please enter duration, ";
			$('#resultDiv').html("<span style='color:red'>Please enter duration.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(contentType==""|| contentType==null){
//			errorMessage=errorMessage+"Please enter contentType, ";
			$('#resultDiv').html("<span style='color:red'>Please enter contentType.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(remark==""|| remark==null){
//			errorMessage=errorMessage+"Please enter remark, ";
			$('#resultDiv').html("<span style='color:red'>Please enter remark.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		$('#resultDiv').removeClass('errorTD').addClass('successTD');

		//alert("validation completdd");
		
		
		
		var data=$('form').serialize();
		    //alert(data);
		    $.ajax({
			url:"/GSMP/updateTraining",
			data:data,
			type:"POST",
			success:function(respData){
				if(respData=="Training Updated Successfully!"){
					$('#resultDiv').removeClass('errorTD').addClass('successTD');
					$('#courseName').val('');
					$('#categories').val("Select Category");
					$('#modes').val(0);
					$('#venue').val('');
					$('#startDate').val('');
					$('#endDate').val('');
					$('#duration').val('');
					$('#contentType').val('');
					$('#remark').val('');
					setTimeout(function(){location.reload();}, 1000);
				}else{
					$('#resultDiv').removeClass('successTD').addClass('errorTD');
				}
				
				$('#resultDiv').show();
				$('#resultDiv').html(respData);
			},
			error:function(request,status,error){
				//alert(request.responseText);
			}
		});
	});
	
	 
  /*  $("#trainingDelButton").click(function(event){
    	
    	
    	alert("delete button coming");
  	  var selected_id=null;
		if($('input[type=checkbox]:checked').length == 0)
		{
		    alert ("ERROR! Please Select Atleast One Record to Delete");
		    
		}else{
		var r1 = confirm("Are You Sure you want to Delete?");
		if (r1 == true) {
			selected_id = [];
	        $.each($("input[name='training']:checked"), function(){ 

	        	selected_id.push($(this).val());
	        	$(this).closest('tr').remove();
	        });
	        //alert("selected id's are: " + selected.join(","));
	        selected_id.join(",");    
		} 
  	  
		            var data=$('form').serialize();
	               $.ajax({
	        			url:"/GSMP/deletetraining?ids="+selected_id,
	            	    data:data,
	        			type:"POST",
	        			success:function(respData){
	        				if(respData=="training Deleted Successfully!"){
	        					$('#resultDiv').removeClass('errorTD').addClass('successTD');
	        					setTimeout(function(){location.reload();}, 1000);
	        					
	        					
	        				}else{
	        					$('#resultDiv').removeClass('successTD').addClass('errorTD');
	        				}
	        				
	        				$('#resultDiv').show();
	        				$('#resultDiv').html(respData);
	        				
	        			},
	        			error:function(request,status,error){
	        				
	        				alert(request.responseText);
	        			}
	        		
		    	  
		      
    			})
			}
  	    			     
    })*/
    
});

function Delete()
{
	    	alert("delete button coming");
	  	  var selected_id=null;
			if($('input[type=checkbox]:checked').length == 0)
			{
			    alert ("ERROR! Please Select Atleast One Record to Delete");
			    
			}else{
			var r1 = confirm("Are You Sure you want to Delete?");
			if (r1 == true) {
				selected_id = [];
		        $.each($("input[name='training']:checked"), function(){ 
		        	alert("selected id is"+$(this).val());
		        	selected_id.push($(this).val());
		        	
		        	//$(this).closest('tr').remove();
		        });
		        //alert("selected id's are: " + selected.join(","));
		        selected_id.join(",");    
			} 
	  	  
			            var data=$('form').serialize();
		                $.ajax({
		        			url:"/GSMP/deletetraining?ids="+selected_id,
		            	    data:data,
		        			type:"POST",
		        			success:function(respData){
		        				if(respData=="Training Deleted Successfully!"){
		        					$('#resultDiv').removeClass('errorTD').addClass('successTD');
		        					setTimeout(function(){location.reload();}, 1000);
		        					
		        					
		        				}else{
		        					$('#resultDiv').removeClass('successTD').addClass('errorTD');
		        				}
		        				
		        				$('#resultDiv').show();
		        				$('#resultDiv').html(respData);
		        				
		        			},
		        			error:function(request,status,error){
		        				
		        				alert(request.responseText);
		        			}
		        			      
	    			});
				}
	  	    			     
	
}

/*function getcheckeddata()
{
	alert("inside the checkeddata");
	
	$('#example input[type=checkbox]:checked').each(function() { 

		   var row = $(this).parent().parent();
		   var rowcells = row.find('td');
		   
		   alert("rowcells"+rowcells.data());
		   
		   rowcells.each(function() 
			   {
			   tdhtml = $(this).html();
			   }); 
		   
		   alert("data html"+ tdhtml);
		   // rowcells contains all td's in the row
		   // you can do 
		   // rowcells.each(function() {var tdhtml = $(this).html(); }); 
		   // to cycle all of them    

		});
	if(($("input[type=checkbox]:checked").length)!=0)
	{ 
		 alert("inside function");
		 
     	var $row = $(this).closest('tr');
     	
     	alert("$row"+ ""+ $row);
     	
     	alert("datatable"+datatable);
     	 // Get row data
     	
     	var data = datatable.row($row).data();
        
        alert("data is"+data);
	     
	  
	      // Get row ID
	      var rowId = data[0];

     	alert("row is is"+rowId);
     	//$(this).closest('tr').remove();
     };
	 
}*/


function getDetailsTrainingData(){
	
	//alert("inside getrowdata");
  
	if($("input:checkbox[name='training']:checked").length == 0)
	{
	    alert ("ERROR! Please Select Atleast One Record.");
	    
	}
	else
		{
		
		 $.each($("input:checkbox[name='training']:checked").closest("td").siblings("td"),function(){
		    	values.push($(this).text()); 	
		    });
		    
		    trainingid= values[0];
		    
		    alert("training id is"+" "+trainingid);
		    
		    
		    trainingDataPopulate(trainingid);
		    
		}
	
	
   
 //   alert("control returned"+trainingid);
    
   // return trainingid;
    
    // alert("value is"+val);
     
   /* alert("1st value"+ values[1]);
    alert("values are"+values.join(","));*/
    
  /*$.each($("input[name='case[]']:checked").closest("td").siblings("td"),
            function () {
                 values.push($(this).text());
            });
  
     alert("val---" + values.join (", "));*/
    /*$(checkboxes).each(function(){
        var arr = $(this).closest('tr').find('td:not(.training)');
        $(arr).each(function(){
        	values.push($(this).val());
        	alert(values[1]);
        	alert(arr[1]);
           alert(this.innerHTML);
        });
    });*/
    
    
}

function trainingDataPopulate(trainingid)
{
	
	//$('#Container1').load("/GSMP/loadResourcedata?id1="+trainingid);
	
	
	alert("inside training data populate"+trainingid);
	/*document.forms[0].action='/GSMP/loadResourcedata?id1='+trainingid;
	document.forms[0].method="get";
	document.forms[0].submit();*/
	
	
	// var data=$('form').serialize();
     //alert(data);
     $.ajax({
            //url:"/GSMP/deleteLocation?ids="+selected,
            url:"/GSMP/loadResourcedata",
            data:{id1:trainingid},
            type:"GET",
            success:function(resdata){
            	 // alert("data from controller is"+resdata);
                //  alert("success training is"+trainingid);
                  window.location="/GSMP/loadResourcedata?id1="+trainingid;
                  //document.location.href="/GSMP/jsp/trainingAssign.jsp";
            	//$('#soemthing').load("/GSMP/trainingAssign.jsp");
                 
            },
            error:function(request,status,error){
                 
                  alert(status);
            }                  

     });
	
}

function getResourceData(trainingid)
{
	//getDetailsTrainingData();
	
	/*$.each($("input:checkbox[name='training']:checked").closest("td").siblings("td"),function(){
    	values.push($(this).text()); 	
    });
    
    trainingid= values[0];*/
	
	if($("input:checkbox[name='training1']:checked").length==0)
			{
		 alert ("ERROR! Please Select Atleast One Record.");
			}
	else
		{
		 
		var chkval=$("input[type='checkbox']").val();
		alert("checkbox value"+chkval);
		
		 $.each($("input:checkbox[name='training1']:checked").closest("td").siblings("td"),function(){
		    	values1.push($(this).text()); 	
		    });
		 
		// alert("val in res"+trainingid);
		 alert("values1 array are "+values1);
		 
		 var val1= values1[0];
		 
		    newArray.push(chkval,val1);
		    alert("new array values are"+newArray);
		
		
		    var data=$('form').serialize();
            $.ajax({
    			url:"/GSMP/assigntraining?idtraining="+newArray,
        	    data:data,
    			type:"POST",
    			success:function(respData){
    				if(respData=="Training Assigned Successfully!"){
    					
    					alert("i am in ajax ");
    					$('#resultDiv').removeClass('errorTD').addClass('successTD');
    					//setTimeout(function(){location.reload();}, 1000);
    				}else{
    					$('#resultDiv').removeClass('successTD').addClass('errorTD');
    				}
    				
    				$('#resultDiv').show();
    				$('#resultDiv').html(respData);
    				
    			},
    			error:function(request,status,error){
    				
    				alert(request.responseText);
    			}
    			      
		});
		}
   
	    
	   /* alert("1st value"+ values1[1]);
	    alert("values are"+values1.join(","));
	    */
	    //$('#Container').load('/GSMP/editTraining?id='+val);
	
}



//JavaScript function to add training page
$('#trainingAddButton').click(function(event){	
	
			$('#resultDiv').removeClass('errorTD').addClass('successTD');
			$('#courseName').val('');
			$('#categoryId').val("Select Category");
			$('#trainingModeId').val(0);
			$('#venue').val('');
			$('#startDate').val('');
			$('#endDate').val('');
			$('#duration').val('');
			$('#contentType').val('');
			$('#remark').val('');		
	
});



function clearFields() {
 // alert("inside load training");
	$('#Container').load('/GSMP/loadTraining');
}
	/*var xhttp;
	if(window.XMLHttpRequest)
	{
		//code for modern browser
		xhttp = new XMLHttpRequest();
		alert("New browser");
		xhttp.onreadystatechange = function()
		{
			 alert("in onreadychange");
			if(xhttp.readyState==4 && xhttp.status==200){
				document.getElementById("Container").innerHTML=xhttp.responseText;
		}
		};
		//xhttp.open("GET","file.txt",true);
		xRequest1.open("get",'/GSMP/loadTraining',"true");

		xhttp.send(); 
	}
	else
	{
		xhttp= new ActiveXObject("Microsoft.XMLHTTP");	
		alert("old one");
	}
	 */

	
	/*
	
	
    document.getElementById("duration").value="";
    document.getElementById("remark").value="";
    document.getElementById("contentType").value="0";
    document.getElementById("courseName").value="0";
	
    document.getElementById("categoryId").value="0";
    document.getElementById("trainingModeId").value="0";
    document.getElementById("venue").value="0";
    document.getElementById("startDate").value="";
    document.getElementById("startTime").value="0";
    document.getElementById("endTime").value="0";
    document.getElementById("startDate").value="";
*/


/*function crossBrowserFunction()
{
	alert("inside cross browser");
	 var xhttp;
	  if (window.XMLHttpRequest) 
	  {
	    // code for modern browsers
	    xhttp = new XMLHttpRequest();
	    } 
	  else 
	    
	    {
	    // code for IE6, IE5
	    xhttp = new ActiveXObject("Microsoft.XMLHTTP");
	  }
	
	
}*/

function populateTrainingData(trainingId) {
	
	//alert("populate training data");
	$('#Container').load('/GSMP/editTraining?id='+trainingId);
}
	///GSMP/editTraining?id=${training.trainingId}
	//var s="";
	
	//alert("hi hello");
	
	/*var id=document.getElementById("training");
	var attr=document.getElementsByTagName("a");
	var attribute=attr.getAttribute("id");
	alert(attribute);*/
	/*var table = document.getElementById('example');
	
	
    row= table.getElementsByTagName('tr')[attribute];
	
	var x=new Array(row.cells.length);
	
	
  
   for(var j=0;j<row.cells.length;j++)
		{
//		 x[j]=row.cells[j].innerHTML;
//		 alert(x[j]);
//		 fillDataFields("duration", x[j]);
	   
	   row.cells[j].onclick = function() {
		   fillDataFields("duration", row.cells[j].innerHTML);
		  };

		}
	
	//alert(row.cells[0].innerHTML);
	
	    document.getElementById("duration").value=row.cells[0].innerHTML;
	    document.getElementById("remark").value="";
	    document.getElementById("contentType").value="0";
	    document.getElementById("courseName").value="0";
		
	    document.getElementById("categoryId").value="0";
	    document.getElementById("trainingModeId").value="0";
	    document.getElementById("venue").value="0";
	    document.getElementById("startDate").value=row.cells[2].innerHTML;
	    document.getElementById("startTime").value="0";
	    document.getElementById("endTime").value="0";
	    document.getElementById("endDate").value=row.cells[3].innerHTML;
	    */
	    
   /*for (var i=0,len=cells.length; i<len; i++){
    cells[i].onclick = function(){
        //console.log(this.innerHTML);
    	alert(this.innerHTML);
        
        
        
       
    }*/
   
//}



function calculateduration()
{
	//alert(duration);
	
	}

function includeTraining() {
	/*window.alert("inside include");*/
	

	$('#container1').load('/GSMP/viewTraining');
}



function fillDataFields(element,data){
	//alert("hi");
	document.getElementById(element).value=data;
}

function compareDates(startDate,endDate,separator) {
	
	//alert(startDate);
	//alert(endDate);
	var startDateArr = Array();
	var endDateArr = Array();
	
	startDateArr = startDate.split(separator);
	endDateArr = endDate.split(separator);
	
	alert("startdate array"+startDateArr);
	
	startDt = startDateArr[1];
	
	//alert("start date splited"+startDt);
	
	var startMt = startDateArr[0];
	//alert(startMt);
	var startYr = startDateArr[2];
	//alert(startMt);
	endDt = endDateArr[1];
	//alert("endDt date splited"+endDt);
	
	/*duration= parseInt(endDt)-parseInt(startDt);
	alert("Duration is"+duration);*/
	
	var endMt = endDateArr[0];
	var endYr = endDateArr[2];
    
	if (startYr > endYr)
		return 0;
	else if (startYr <= endYr && startMt > endMt)
		return 0;
	else if (startYr <= endYr && startMt == endMt && startDt > endDt)
		return 0;
	else
		return 1;
}

/*function compareDatesStart(startDate,separator) {
	alert("inside the startdate check compare");
	
	var startDateArr2 = Array();
	today=new Date();
	  var dd = today.getDate();
	  var mm = today.getMonth()+1; //January is 0!
	  var yyyy = today.getFullYear();
	
	startDateArr2 = startDate.split(separator);
	alert("start date array"+startDateArr2);
	                                                                                          
	//alert(startDateArr);                                                                         
	var startDt1 = startDateArr2[2];
	alert("startdate inside method"+startDt1);
	var startMt1 = startDateArr2[1];
	alert("startmonth inside method"+startMt1);
	var startYr1 = startDateArr2[0];
	alert("start year inside method"+startYr1);                                      
	
     alert("this is year"+yyyy);
	if (startYr1 < yyyy || startMt1 < mm || startDt1 < dd)
		return 0;
	else
		return 1;
}*/

/*function compareTimes(startTime, startMeridiem, endTime, endMeridiem, separator) {
	var startTimeArr = Array();
	var endTimeArr = Array();
	startTimeArr = startTime.split(separator);
	endTimeArr = endTime.split(separator);
	var startHour = startTimeArr[0];
	var endHour = endTimeArr[0];
	if (startHour > endHour && startMeridiem == endMeridiem)
		return 0;
	else 
		return 1;
}*/

function compareTimes(startTime,endTime) {
	var startTimeArr = Array();
	var endTimeArr = Array();
	startTimeArr = startTime.split(":");
	endTimeArr = endTime.split(":");
	
	//alert("starttime array"+startTimeArr);
	//alert("endtime array"+endTimeArr);
	 startHour = startTimeArr[0];
	 endHour = endTimeArr[0];
	 
	 startmin=startTimeArr[1];
	 endmin=endTimeArr[1];
	 
	 var resstart=startmin.substring(2,4);
	 
	 var resend=endmin.substring(2,4);
	 
	 //alert("its substring"+resstart);
	 //alert("its endsubstring"+resend);
	 /*alert(startmin);
	 alert(endmin);*/
	 
	//alert("start hour"+startHour);
	//alert("End hour"+endHour);
	if (startHour >= endHour && resstart=="am" && resend=="pm")
		{
		return 1;
		}
	else if(startHour <= endHour && resstart=="am" && resend=="pm")
		{
		return 1;
		}
	else if(startHour <= endHour && resstart=="am" && resend=="am")
	   {
	    return 1;
	   }
	else if(startHour >= endHour && resstart=="am" && resend=="am")
	   {
	    return 1;
	   }
	else if(startHour >= endHour && resstart=="pm" && resend=="pm")
		{
		return 1;
		}
    else if(startHour <= endHour && resstart=="pm" && resend=="pm")
	   {
	   return 1;
	   }
		
	else 
		return 0;
}


/*function compareTimesStart(startTime,separator) {
	var startTimeArr = Array();
	
	startTimeArr = startTime.split(separator);
	
	 startHour = startTimeArr[0];
	
	//alert(startHour);
	//alert(endHour);
	
		return startHour;
}


function compareTimesEnd(endTime,separator) {
	
	var endTimeArr = Array();
	
	endTimeArr = endTime.split(separator);
	
	 endHour = endTimeArr[0];
	//alert(startHour);
	//alert(endHour);
	
		return endHour;
}
*/



