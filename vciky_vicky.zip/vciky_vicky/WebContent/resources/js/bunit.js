
$(document).ready(function(){
	    
	      //Save Operation
          $('#buUnitSubButton').click(function(event){
		
      
		          //code added by basavaiah 24th Des15
		              var buUnitname=$('#name').val();
		             
		              
		              if(buUnitname==""|| buUnitname==null)
		              {
		                  
		            	  $('#resultDiv').html("<span style='color:red'>Please enter Business Unit Name.</span>");
			              $('#resultDiv').addClass('errorTD');
			              $('#resultDiv').show();
			
			             return false;
	               	 }

                   /* if(comments==""|| comments==null)
                    {
			
			              $('#resultDiv').html("<span style='color:red'>Please enter Comments.</span>");
			              $('#resultDiv').addClass('errorTD');
			              $('#resultDiv').show();
		
			               return false;
                    }*/
		            $('#resultDiv').removeClass('errorTD').addClass('successTD');
		
		 
		
		             var data=$('form').serialize();
		            
		             $.ajax({
			                 url:"/GSMP/addBuUnit",
			                 data:data,
		                     type:"POST",
			                 success:function(respData){
			                	 alert("SUCCESS");
				                       if(respData=="Business Unit Saved Successfully!"){
				                    	   alert("Success");
					                      $('#resultDiv').removeClass('errorTD').addClass('successTD');
					                      $('#buUnitname').val('');
					                   
				                        }
				                       else {
                                         //  $('#resultDiv').html("<span style='color:red'>"+errorMessage+"</span>");
				                           //   $('#resultDiv').show();
					                        $('#resultDiv').removeClass('successTD').addClass('errorTD');
				                          }
				                    $('#resultDiv').show();
				       				$('#resultDiv').html(respData);
				       				$("#fade").hide();
				       				$("#PleaseWait").hide();
		                    	},
			                error:function(request,status,error){
			            	          alert("Err");
			            	          $("#fade").hide();
			          				  $("#PleaseWait").hide();
			                    }
		        });
		            
          });//closing save()
          
          $('input[name=Comanda]').click(function()
        		  {
        	            $('#AddSkillForm').hide();
        	   
          });
         
          
          //Strating update
         /* $('#skillUpdateButton').click(function(event)
        		  {
                 var skillId=$('#id').val();
                        alert(skillId);
                 var skillName=$('#skillname').val();
                 var createdBy=$('#createdBy').val();
                 var createdDate=$('#createdDate').val();
                 var modifiedBy=$('#modifiedBy').val();
                 var modifiedDate=$('#modifiedDate').val();
                 
        	  alert("Hi");
        	
        	  var data=$('form').serialize();
      		//alert(data);
      		$.ajax({
      			url:"/GSMP/updateSkill",
      			data:data,
      			type:"POST",
      			success:function(respData){
      				if(respData=="Data Saved Successfully!"){
      					$('#resultDiv').removeClass('errorTD').addClass('successTD');
      					$('#skillsName').val('');
      					
      				}else{
      					$('#resultDiv').removeClass('successTD').addClass('errorTD');
      				}
      				
      				$('#resultDiv').show();
      				$('#resultDiv').html(respData);
      				$('#updateSkillForm').hide();
      			},
      			error:function(request,status,error){
      				alert("Hi Err");
      				alert(request.responseText);
      			}
      		});
        });*/
});


function getBunitPage()
{

    $('#addBuUnit').load('/GSMP/loadBunitPage');
}
function populateBuUnitData(buUnitId) {
	
	$('#addBuUnit').load('/GSMP/editBuUnit?id='+buUnitId);
 	}

/*function selectAllCheckBox()
{
	 if (document.getElementById('select_all').checked ==true) {
         $('.person_data').each(function() {
             this.checked = true;
         });
     } else {
         $('.person_data').each(function() {
             this.checked = false;
         });
     }

}
*/
