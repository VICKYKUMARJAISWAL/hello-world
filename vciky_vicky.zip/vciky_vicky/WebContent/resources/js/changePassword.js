$(document).ready(function(){
	$('#chngPasswordSubButton').click(function(event){
		var oldpassWord=$('#oldpassWord').val();
		var newPassword=$('#newPassword').val();
		var ConfPassword=$('#ConfPassword').val();
		//var pattern = /^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/;
		if(oldpassWord==""||oldpassWord==null){
			$('#resultDiv').html("Please Enter Old Password!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		if(newPassword==""||newPassword==null){
			$('#resultDiv').html("Please Enter NewPassword!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		if(ConfPassword==""|| ConfPassword==null){
			$('#resultDiv').html("Please Enter Confirm Password!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
			
	if(newPassword!=ConfPassword){
		$('#resultDiv').html("ConfirmPassword is not matched!!!");
		$('#resultDiv').addClass('errorTD');
		$('#resultDiv').show();
		return false;
		}
		
	if(/*!pattern.test(newPassword)*/ !validatePassword(newPassword)){
		$('#resultDiv').html("Please enter the proper password!!!");
		$('#resultDiv').addClass('errorTD');
		$('#resultDiv').show();
		return false;
	}
		var data=$('form').serialize();
		$("#fade").show();
		$("#PleaseWait").show();
		$.ajax({
			url:"/GSMP/savePassword",
			data:data,
			type:"POST",
			success:function(respData){
				if(respData=="Password Changed Successfully!"){
					$('#resultDiv').removeClass('errorTD').addClass('successTD');
					$('#oldpassWord').val('');
					$('#newPassword').val('');
					$('#ConfPassword').val('');
				}else{
					$('#resultDiv').removeClass('successTD').addClass('errorTD');
				}
				$('#resultDiv').show();
				$('#resultDiv').html(respData);
				$("#fade").hide();
				$("#PleaseWait").hide();
			},
			error:function(request,status,error){
				alert(request.responseText);
				$("#fade").hide();
				$("#PleaseWait").hide();
			}
		});
	});
	
})