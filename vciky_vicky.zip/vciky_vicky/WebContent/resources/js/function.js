function Home(){
	var userId=document.getElementById('userId').value;
	var password=document.getElementById('password').value;
	if(userId==""|| userId==null){
		document.getElementById('loginresultDiv').innerHTML = "please enter userId!!!";
		document.getElementById('loginresultDiv').style.display = "block";
		document.getElementById('loginresultDiv').style.color='#FF0000'
		return false;
	} else if(!validateUserId(userId)){
		document.getElementById('loginresultDiv').innerHTML = "please enter igate userId!!!";
		document.getElementById('loginresultDiv').style.display = "block";
		document.getElementById('loginresultDiv').style.color='#FF0000'
		return false;
	} 
	if(password==""|| password==null){
		document.getElementById('loginresultDiv').innerHTML = "please enter password!!!";
		document.getElementById('loginresultDiv').style.display = "block";
		document.getElementById('loginresultDiv').style.color='#FF0000'
		return false;
	} else if (!validatePassword(password)) {
		document.getElementById('loginresultDiv').innerHTML = "please enter correct password!!!";
		document.getElementById('loginresultDiv').style.display = "block";
		document.getElementById('loginresultDiv').style.color='#FF0000'
		return false;
	}
	document.forms[0].action='/GSMP/loadHomePage';
	document.forms[0].method="post";
	document.forms[0].submit();
}

function Login(){
	document.forms[0].action='/GSMP/';
	document.forms[0].method="get";
	document.forms[0].submit();
}




function loadTraining(){
	document.forms[0].action='/GSMP/loadTraining';
	document.forms[0].method="get";
	document.forms[0].submit();
}

//added addViewEditTraining
function loadAddViewEditTraining(){
	document.forms[0].action='/GSMP/addViewEditTraining';
	document.forms[0].method="get";
	document.forms[0].submit();
}

function loadTrainingCalendar(){
	document.forms[0].action='/GSMP/loadTrainingCalendar';
	document.forms[0].method="get";
	document.forms[0].submit();
}

function loadRegistrationPage(){
	document.forms[0].action='/GSMP/loadRegistrationPage';
	document.forms[0].method="get";
	document.forms[0].submit();
}

function loadResetPage(){
	document.forms[0].action='/GSMP/loadResetPage';
	document.forms[0].method="get";
	document.forms[0].submit();
}

function loadProfileUpdate(){
	document.forms[0].action='/GSMP/loadProfileUpdate';
	document.forms[0].method="get";
	document.forms[0].submit();	
}

function loadAddViewEditProject()
{
	document.forms[0].action='/GSMP/loadAddViewEditProject';
	document.forms[0].method="get";
	document.forms[0].submit();
}

function loadAddViewEditSkill()
{

	document.forms[0].action='/GSMP/addViewEditSkill';
	document.forms[0].method="get";
	document.forms[0].submit();
}

function loadResetPassword(){
	document.forms[0].action='/GSMP/loadResetPassword';
	document.forms[0].method="get";
	document.forms[0].submit();	
}

function loadViewPage()
{
	document.forms[0].action='/GSMP/loadViewPage';
	document.forms[0].method="get";
	document.forms[0].submit();	
}

function loadUserList()
{
	document.forms[0].action='/GSMP/loadUsers';
	document.forms[0].method="get";
	document.forms[0].submit();	
}
function loadTrainingCalendar()
{
	document.forms[0].action='/GSMP/loadTrainingCalendar';
	document.forms[0].method="get";
	document.forms[0].submit();	
}

function loadInterviewTrackerPage()
{
	document.forms[0].action='/GSMP/loadInterviewTrackerPage';
	document.forms[0].method="get";
	document.forms[0].submit();	
}

function loadAddViewEditBuUnit()
{
	//alert("in bunit");
	document.forms[0].action='/GSMP/addViewEditBunit';
	document.forms[0].method="get";
	document.forms[0].submit();
}


function validateEmail(email) {
	  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	  if(emailReg.test(email )){
	       return true;
	   }
	   else {
	       return false;
	   }
	}

function loadaddViewEditLocation(){
	//alert("inside location");
	
	document.forms[0].action='/GSMP/addViewEditLocation';
	document.forms[0].method="get";
	document.forms[0].submit();	
}

function loadAddViewEditSkill()
{
   //alert("in skill function")
	document.forms[0].action='/GSMP/addViewEditSkill';
	document.forms[0].method="get";
	document.forms[0].submit();
}

function loadAddViewEditProject()
{
	document.forms[0].action='/GSMP/loadAddViewEditProject';
	document.forms[0].method="get";
	document.forms[0].submit();
}

function loadSOW(){
	alert("function: loadSOW");
	document.forms[0].action='/GSMP/loadSOWpage';
	document.forms[0].method="get";
	document.forms[0].submit();	
}

function loadBEsheet(){
	alert("function: loadBEsheet");
	document.forms[0].action='/GSMP/loadBEsheet';
	document.forms[0].method="get";
	document.forms[0].submit();	
}
function validatePhone(txtPhone) {
    var filter = /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;
   if(filter.test(txtPhone)){
       return true;
   }
   else {
       return false;
   }
}

function logout(){
	document.forms[0].action='/GSMP/logout';
	document.forms[0].method="get";
	document.forms[0].submit();
}

//added this method to validate the userID. bug fix
function validateUserId(userId){
	var userIdPattern = /^[a-z]{2}[0-9]{6}$/;
	 if(userIdPattern.test(userId)){
	       return true;
	   }
	   else {
	       return false;
	   }
}

function validatePassword(password){
	var passwordPattern = /^.*(?=.{6,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/;
	 if(passwordPattern.test(password)){
	       return true;
	   }
	   else {
	       return false;
	   }
}
