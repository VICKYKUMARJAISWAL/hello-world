
$(document).ready(function(){
	$("#opportunityStartDate,#opportunityEndtartDate").datepicker({
		dateFormat: "yy-mm-dd",
	    //showOn: "button",
	    buttonImage: "resources/images/cal.jpg",
	    buttonImageOnly: true,
	    //showOn: "both",
	
	});
	$("#opportunityStartDate1,#opportunityEndtartDate1").datepicker({
		dateFormat: "yy-mm-dd",
	    //showOn: "button",
	    buttonImage: "resources/images/cal.jpg",
	    buttonImageOnly: true,
	    //showOn: "both",
	
	});
   	
	$('#interviewupdateCancel,#interviewCancelButton').click(function(){
		 $('#Container1').hide();
	});
	
 	$('#name').click(function(){
 		$('#Container1').show();
 	});
   $('#interviewSubButton').click(function(event){
	
    var errorMessage=" ";
    
	var interviewname=$("#iname").val();
	
	var businessUnit=$("#businessUnitId option:selected").text();
			
	var project=$('#projectId option:selected').text();
			
	var location=$('#locationId option:selected').text();

	var interviewSkill=[];
	
    var opportunityStartDate=new Date($('#opportunityStartDate').val());
	
	var opportunityEndDate=new Date($('#opportunityEndtartDate').val());
	
	var opportunitystatus=$('#opportunityStatus option:checked').text();
	
	if(interviewname==""|| interviewname==null){	
		$('#resultDiv').html("<span style='color:red'>Please Enter Opportunity Name.</span>");
		$('#resultDiv').addClass('errorTD');
		$('#resultDiv').show();
		return false;
	}
	
	if(businessUnit=="Select BU Name"){
		$('#resultDiv').html("<span style='color:red'>Please Select a Bussinessunit name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
	
	if(project=="Select Project Name"){
		
		$('#resultDiv').html("<span style='color:red'>Please Select a Project Name.</span>");
		$('#resultDiv').addClass('errorTD');
		$('#resultDiv').show();
		return false;
	}

	if(location=="Select Location"){
		$('#resultDiv').html("<span style='color:red'>Please Select Location</span>");
		$('#resultDiv').addClass('errorTD');
		$('#resultDiv').show();
		return false;
	}
	

	if(opportunityStartDate==""|| opportunityStartDate==null){
		$('#resultDiv').html("<span style='color:red'>Please enter Opportunity Start date.</span>");
		$('#resultDiv').addClass('errorTD');
		$('#resultDiv').show();	
		return false;
	}
		
	if(opportunityEndDate==""|| opportunityEndDate==null){

		$('#resultDiv').html("<span style='color:red'>Please enter Opportunity End Date.</span>");
		$('#resultDiv').addClass('errorTD');
		$('#resultDiv').show();	
		return false;
	}
		
//	if(compareDates(opportunityStartDate,opportunityEndDate,'-') == 0) {
//		$('#resultDiv').html("<span style='color:red'>Opportunity Start Date must be less than or equal to Opportunity End Date.</span>");
//		$('#resultDiv').addClass('errorTD');
//		$('#resultDiv').show();
//	return false;
//	}
	if(opportunityStartDate>opportunityEndDate){
		$('#resultDiv').html("<span style='color:red'>Opportunity Start Date must be less than or equal to Opportunity End Date.</span>");
		$('#resultDiv').addClass('errorTD');
		$('#resultDiv').show();
	return false;
		
	}
	
	if($("#interviewSkills option:selected").length>0){
		
		$('#interviewSkills option:selected').each(function() {
			interviewSkill.push($(this).text());
		     });
	}
	else{
		$('#resultDiv').html("<span style='color:red'>Please select Skills.</span>");
		$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
	}
	
	if(opportunitystatus=="Select Opportunity Status"){

		$('#resultDiv').html("<span style='color:red'>Please enter Opportunity Status.</span>");
		$('#resultDiv').addClass('errorTD');
		$('#resultDiv').show();	
		return false;
	}
	
	$('#resultDiv').removeClass('errorTD').addClass('successTD');

	
	
    var fdata=$('form').serialize();

	$.ajax({
	
		url:"/GSMP/addInterviewDetail",
	    data:fdata,
	    type:"POST",

		success:function(respData){
	
			if(respData=="Data Saved Successfully"){
				
				$("#resultDiv").removeClass("errorTD").addClass("successTD");
				
				$("#iname").val('');
				
				$('#businessUnitId').val(0);
								
				$('#projectId').val(0);
				
				$('#locationId').val(0);
				
				$('#interviewSkills').val(0);
				
				$('#opportunityStartDate').val('');
				
				$('#opportunityEndtartDate').val('');
				
				$('#opportunityStatus').val(0);
				
				$('#comments').val('');
				
				 window.location.reload();
				
				
				
			}else{
				$('#resultDiv').removeClass('successTD').addClass('errorTD');
			}
			
			$('#resultDiv').show();
			$('#resultDiv').html(respData);
		},
		error:function(request,saveStatus,error){
			alert(request.responseText);
		}
	});

});
   
   $('#interviewUpdateSubButton').click(function(event){
		
	     //alert("hi");
	     
		var interviewname=$('#uname').val();
		
		var projectId=$('#projectId :selected').text();
		
		var opportunityStartDate=new Date($('#opportunityStartDate1').val());
		
		var opportunityEndDate= new Date($('#opportunityEndtartDate1').val());
		
		var businessUnitId=$('#businessUnitId :selected').text();
		
		var opportunitystatus=$('#opportunityStatus :selected').text();
		
		var interviewSkill=[];
		
		
		if(interviewname==""|| interviewname==null){
			$('#resultDiv').html("<span style='color:red'>Please enter Opportunity Name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			
			return false;
		}

		if(projectId=="Select Project Name"){
			$('#resultDiv').html("<span style='color:red'>Please enter Project Name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			
			return false;
		}
		
		if(opportunityStartDate==""|| opportunityStartDate==null){
			$('#resultDiv').html("<span style='color:red'>Please enter Opportunity Start Date.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			
			return false;
		}
		
		if(opportunityEndDate==""|| opportunityEndDate==null){
			$('#resultDiv').html("<span style='color:red'>Please enter Opportunity End Date.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			alert(opportunityEndDate);
			return false;
		}
		
//		if(compareDates(opportunityStartDate,opportunityEndDate,'-') == 0) {
//			$('#resultDiv').html("<span style='color:red'>Opportunity Start Date must be less than or equal to Opportunity End Date.</span>");
//			$('#resultDiv').addClass('errorTD');
//			$('#resultDiv').show();
//		return false;
//		}
		 
		if(opportunityStartDate>opportunityEndDate){
			$('#resultDiv').html("<span style='color:red'>Opportunity Start Date must be less than or equal to Opportunity End Date.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
		return false;
			
		}
		if(businessUnitId=="Select BU Name"){
			$('#resultDiv').html("<span style='color:red'>Please enter Business Unit Name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			
			return false;
		}
		if(opportunitystatus=="Select Opportunity Status"){

			$('#resultDiv').html("<span style='color:red'>Please enter Opportunity Status.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();	
			return false;
		}

         if($("#interviewSkills option:selected").length>0){
			
			$('#interviewSkills option:selected').each(function() {
				interviewSkill.push($(this).text());
			     });
		}
		else{
			$('#resultDiv').html("<span style='color:red'>Please select Skills.</span>");
			$('#resultDiv').addClass('errorTD');
				$('#resultDiv').show();
				return false;
		}
		
	    var data=$('form').serialize();
	   
	    //alert(data);
		$("#PleaseWait").show();
		
		$.ajax({
			url:"/GSMP/loadUpdateInterview",
			data:data,
			type:"POST",
			success:function(respData){
				
				if(respData=="Data Saved Successfully!"){
					
					$('#resultDiv').removeClass('errorTD').addClass('successTD');
					
					$('#uname').val('');
					
					$('#projectId ').val('');
					
					$('#opportunityStartDate1').val('');
					
					$('#businessUnitId').val('');
					
					$('#opportunityEndtartDate1').val('');
					
					$('#opportunityStatus').val('');
					
					$('#comments').val('');
					
					$('#interviewSkills').val(0);
					
					setTimeout(function(){location.reload()}, 1000);
				
									
				}else{
					$('#resultDiv').removeClass('successTD').addClass('errorTD');
				}
				
				$('#resultDiv').show();
				$('#resultDiv').html(respData);
			},
			error:function(request,status,error){
				alert(request.responseText);
			}
		});
	});

});

function Delete(){
	if($('input[type=checkbox]:checked').length == 0)
	{
	    alert ("ERROR! Please Select Atleast One Record to Delete");
	    
	}else{
	var r = confirm("Are You Sure want to Delete?");
	if (r == true) {
		var selected = [];
        $.each($("input[name='check']:checked"), function(){ 

        	selected.push($(this).val());
        });
         selected.join(",");            
	} 
  	  var data=$('form').serialize();
		//alert(data);
		$.ajax({
			url:"/GSMP/deleteInterview?ids="+selected,
			data:data,
			type:"POST",
			success:function(respData){
				if(respData=="Data Deleted Successfully!"){
					$('#resultDiv').removeClass('errorTD').addClass('successTD');
					//$('#name').val('');
					setTimeout(function(){location.reload()},1000);
					
				}else{
					$('#resultDiv').removeClass('successTD').addClass('errorTD');
				}
				
				$('#resultDiv').show();
				$('#resultDiv').html(respData);
				
			},
			error:function(request,status,error){
				
				alert(status);
			}			

		});
	}
}
function interviewFields() {	  
		$('#Container1').load('/GSMP/loadinterview');
	}

function populateSkillData(interviewId) {
	
	//alert(interviewId);	
	
	//var result = [];
	var result_text=" ";
	$.ajax({
		url:"/GSMP/getIntervSkillsById?interviewId="+interviewId,		
		type:'GET',
		dataType: 'json',
		success:function(respdata){
			
			console.log(respdata);
			//alert(respdata[0].skillsName);
			$.each(respdata,function(index,element){
				//result.push(respdata[index].skillsName);
				result_text+=respdata[index].skillsName+'</br>';
				$("#dialog").html(result_text);
			
			});
			//alert(result_text);
			
		$( "#dialog" ).dialog({ autoOpen: false,resizable:false,position:{ my: "center", at: "center"}});
		
	    $( "#dialog" ).dialog("open");
	    
			//$('.skillpopup').attr('title',result_text);
			//$(document).tooltip();
	   
		}
		})
		
		
	              
}

function populateInterviewData(interviewId){	
	$('#Container1').load('/GSMP/loadUpdateInterview?interviewId='+interviewId);
}
function compareDates(opportunityStartDate,opportunityEndDate,separator) {
	

	var opportunitystartDateArr = Array();
	var opportunityEndDateArr = Array();
	
	opportunitystartDateArr = opportunityStartDate.split(separator);
	opportunityEndDateArr = opportunityEndDate.split(separator);
	
	var opportunitystartYr = opportunitystartDateArr[0];
	var opportunitystartMt = opportunitystartDateArr[1];
	var opportunitystartDt = opportunitystartDateArr[2];
	
	
	var opportunityendYr = opportunityEndDateArr[0];	
	var opportunityendMt = opportunityEndDateArr[1];
	var opportunityendDt = opportunityEndDateArr[2];
    
	if (opportunitystartYr > opportunityendYr)
		return 0;
	else if (opportunitystartYr <= opportunityendYr && opportunitystartMt > opportunityendMt)
		return 0;
	else if (opportunitystartYr <= opportunityendYr && opportunitystartMt == opportunityendMt && opportunitystartDt > opportunityendDt)
		return 0;
	else
		return 1;
}