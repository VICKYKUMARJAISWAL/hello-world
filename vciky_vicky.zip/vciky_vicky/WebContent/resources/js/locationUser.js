$(document).ready(function(){
	
	
		//JavaScript function to add user page


$('#locationAddNewSubButton').click(function(event){
	
	// var errorMessage="";
		
		var locationName=$('#locationName').val();
		
		if(locationName==""|| locationName==null){
					
			$('#resultDiv').html("<span style='color:red'>Please Enter LocationName.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			//courseName="";
			return false;
		}
		$('#resultDiv').removeClass('errorTD').addClass('successTD');

		//alert("validation completdd");
		
		
		
		var data=$('form').serialize();
		//alert(data);
		$.ajax({
			url:"/GSMP/addLocationDetials",
			data:data,
			type:"POST",
			success:function(respData){
				if(respData=="Data Saved Successfully!"){
					
					$('#resultDiv').removeClass('errorTD').addClass('successTD');
					$('#locationName').val('');
					setTimeout(function(){location.reload();}, 1000);
									}else{
//					$('#resultDiv').html("<span style='color:red'>"+errorMessage+"</span>");
//					$('#resultDiv').show();
					$('#resultDiv').removeClass('successTD').addClass('errorTD');
					
				}
				
				$('#resultDiv').show();
   				$('#resultDiv').html(respData);
   				
   				$("#fade").hide();
   				$("#PleaseWait").hide();
   			    //window.location.reload();
			},
			error:function(request,status,error){
				//alert(request.responseText);
				$("#fade").hide();
				  $("#PleaseWait").hide();
			}
		
		});
	});

			
$('#locationUpdateSubButton').click(function(event){
    alert("update");
    //var errorMessage="";
    var locationName=$('#locationName').val();
 if(locationName==""|| locationName==null){
                 
           $('#resultDiv').html("<span style='color:red'>Please Enter LocationName.</span>");
           $('#resultDiv').addClass('errorTD');
           $('#resultDiv').show();
           
           return false;
     }            
 $('#resultDiv').removeClass('errorTD').addClass('successTD');

var data=$('form').serialize();
//alert(data);
$.ajax({
     url:"/GSMP/updateLocationPage",
     data:data,
     type:"POST",
     success:function(respData){
           if(respData=="Data Saved Successfully!"){
                  $('#resultDiv').removeClass('errorTD').addClass('successTD');
                  $('#locationName').val('');
                  setTimeout(function(){location.reload();}, 1000);
                  
           }else{
                  $('#resultDiv').removeClass('successTD').addClass('errorTD');
           }
           
           $('#resultDiv').show();
           $('#resultDiv').html(respData);
           
     },
     error:function(request,status,error){
           
           alert(request.responseText);
     }


});

});

	/*$('#locationDelButton').click(function(event)
  		  {
		alert("Delete");
		var r = confirm("Are You Sure to Delete?");
		if (r == true) {
			var selected = [];
	        $.each($("input[name='check']:checked"), function(){            
	        	selected.push($(this).val());
	        });
	        alert("selected id's are: " + selected.join(","));
	         selected.join(",");    
		} 
	  	  var data=$('form').serialize();
			alert(data);
			$.ajax({
				url:"/GSMP/deleteLocation?ids="+selected,
				data:data,
				type:"POST",
				success:function(respData){
					if(respData=="Data Deleted Successfully!"){
						$('#resultDiv').removeClass('errorTD').addClass('successTD');
						$('#locationName').val('');
						
					}else{
						$('#resultDiv').removeClass('successTD').addClass('errorTD');
					}
					
					$('#resultDiv').show();
					$('#resultDiv').html(respData);
					
				},
				error:function(request,status,error){
					
					alert(status);
				}		

		});

  	});*/
	
$('#select-All').click(function(event) {
    if(this.checked) {
        $(':checkbox').prop('checked', true);
    } else {
        $(':checkbox').prop('checked', false);
    }
});


	$('#locationDelButton').click(function(event){
		
		var selected=null;
		if($('input[type=checkbox]:checked').length == 0)
		{
		    alert ("ERROR! Please Select Atleast One Record to Delete");
		    
		}else{
		var r = confirm("Are You Sure want to Delete?");
		if (r == true) {
			selected = [];
	        $.each($("input[name='check']:checked"), function(){ 

	        	selected.push($(this).val());
	        	/*$(this).closest('tr').remove();*/
	        });
	        //alert("selected id's are: " + selected.join(","));
	         selected.join(",");    
		} 
	  	  var data=$('form').serialize();
			//alert(data);
			$.ajax({
				url:"/GSMP/deleteLocation?ids="+selected,
				data:data,
				type:"POST",
				success:function(respData){
					if(respData=="Data Deleted Successfully!"){
						$('#resultDiv').removeClass('errorTD').addClass('successTD');
						//$('#locationName').val('');
						setTimeout(function(){location.reload();}, 1000);
						
					}else{
						$('#resultDiv').removeClass('successTD').addClass('errorTD');
					}
					
					$('#resultDiv').show();
					$('#resultDiv').html(respData);
					
				},
				error:function(request,status,error){
					
					//alert(status);
				}			

			});
		}
  	});
	$('#locationAddNewButton1').click(function(){
        //alert("Delete Log");
         var x = screen.width/2 - 1000/2;
         var y = screen.height/2 - 450/2;
         window.open('/GSMP/loadAdminLocationDeletedLog', '_blank','height=485,width=980,left='+x+',top='+y);
});


});	

function getLocationPage() {

	$('#addLocation').load('/GSMP/loadAdminLocation');
	}

function populateLocationData(id) {
	
	
	
	//$('#addLocation').load('/GSMP/editLocation?id='+id);
	$('#addLocation').load('/GSMP/loadUpdateLocation?id='+id);
	
	///GSMP/editTraining?id=${training.trainingId}
	//var s="";
	//getUpdateLocationPage();
}

function closeWin()
{
   close();
}

function populateLocationLogData(id) {
    
    // alert("Sadhu")
     var x = screen.width/2 - 1000/2;
     var y = screen.height/2 - 450/2;
     window.open('/GSMP/loadAdminLocationLog?id='+id, '_blank','height=485,width=980,left='+x+',top='+y);

 /*$('#addLocation').load('/GSMP/loadUpdateLocation?id='+id);*/

}







function selectAllCheckBox()
{
	 if (document.getElementById('select_all').checked ==true) {
         $('.person_data').each(function() {
             this.checked = true;
         });
     } else {
         $('.person_data').each(function() {
             this.checked = false;
         });
     }

}

/*$('#locationAddNewButton').click(function(event){	
	alert("add")
	$('#resultDiv').removeClass('errorTD').addClass('successTD');
	$('#locationId').val('');
	
	$('#locaionName').val('');
	$('#createdBy').val('');
	$('#createdDate').val('');
	$('#modifiedBy').val('');
	$('#modifiedDate').val('');
	getLocationPage();


});
*/





	



