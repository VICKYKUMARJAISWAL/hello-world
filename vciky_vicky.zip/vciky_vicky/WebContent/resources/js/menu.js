$(document).ready(function(){
	var menuId;
	$("#mainMenu > li > div").click(function(){
	    if(false == $(this).next().is(':visible')) {
	        $('#mainMenu ul').slideUp(300);
	    }
	    $(this).next().slideToggle(300);
	});
	$('#mainMenu ul:eq(0)').show();
	
	
	/* $("li[id="+menuId+"]").click(function(e){ 
			     alert('hi');
			    });*/
	$('#mainMenu a').on("click",function(e){
		$(this).addClass('menulibackground');
	});
	/* $('.sub-menu li').click(function(e){
		 menuId=this.id;
	 });*/
});