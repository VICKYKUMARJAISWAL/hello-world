$(document).ready(function(){
	    
	    
	    //Strting add operation
          $('#projectSubButton').click(function(event){
		
      
		          //code added by basavaiah 24th Des15
		              var projectName=$('#projectName').val();
		             /* var comments=$('#comments').val();*/
		             
		              
		              if(projectName==""|| projectName==null)
		              {
		                  
		            	  $('#resultDiv').html("<span style='color:red'>Please enter ProjectName.</span>");
			              $('#resultDiv').addClass('errorTD');
			              $('#resultDiv').show();
			
			             return false;
	               	 }

                   /* if(comments==""|| comments==null)
                    {
			
			              $('#resultDiv').html("<span style='color:red'>Please enter Comments.</span>");
			              $('#resultDiv').addClass('errorTD');
			              $('#resultDiv').show();
		
			               return false;
                    }*/
		            $('#resultDiv').removeClass('errorTD').addClass('successTD');
		
		 
		
		             var data=$('form').serialize();
		             //alert(data);
		             $.ajax({
			                 url:"/GSMP/addProject",
			                 data:data,
		                     type:"POST",
		                     success:function(respData){
			                	 //alert(respData)
				                       if(respData=="Project Saved Successfully!"){
				                    	   
					                      $('#resultDiv').removeClass('errorTD').addClass('successTD');
					                      $('#skillName').val('');
					                      setTimeout(function(){location.reload();}, 1000);
				                        }
				                       else {
                                         //  $('#resultDiv').html("<span style='color:red'>"+errorMessage+"</span>");
				                           //   $('#resultDiv').show();
					                        $('#resultDiv').removeClass('successTD').addClass('errorTD');
				                          }
				                    $('#resultDiv').show();
				       				$('#resultDiv').html(respData);
				       				$('#AddProjectForm').hide();
				       				$("#fade").hide();
				       				$("#PleaseWait").hide();
				       				
		                    	},
			                error:function(request,status,error){
			            	        
			            	          $("#fade").hide();
			          				  $("#PleaseWait").hide();
			                    }
		        });
		            
          });//closing save()
          
          $('input[name=Comanda]').click(function()
        		  {
        	            $('#AddProjectForm').hide();
        	   
          });
         
          
          //Strating update
          $('#projectUpdateButton').click(function(event)
        		  {
              
        	
        	
        	  var data=$('form').serialize();
      		//alert(data);
      		$.ajax({
      			url:"/GSMP/updateProject",
      			data:data,
      			type:"POST",
      			success:function(respData){
      				if(respData=="Project Updated Successfully!"){
      					$('#resultDiv').removeClass('errorTD').addClass('successTD');
      					$('#projectName').val('');
      					setTimeout(function(){location.reload();}, 1000);
      				}else{
      					$('#resultDiv').removeClass('successTD').addClass('errorTD');
      				}
      				
      				$('#resultDiv').show();
      				$('#resultDiv').html(respData);
      				
      			},
      			error:function(request,status,error){
      				alert(request.responseText);
      			}
      		});
        });
          
          $("#projectDeleteButton").click(function(){
              
        	var vals=null;
        		if($('input[type=checkbox]:checked').length == 0)
        		{
        		    alert ("ERROR! Please Select Atleast One Record to Delete");
        		    
        		}else{
        		var r = confirm("Are You Sure want to Delete?");
        		if (r == true) {
        			vals = [];
        	        $.each($("input[name='rec']:checked"), function(){ 

        	        	vals.push($(this).val());
        	        	/*$(this).closest('tr').remove();*/
        	        });
        	        //alert("selected id's are: " + selected.join(","));
        	        vals.join(",");    
        		}
   		           var data=$('form').serialize();
   	               $.ajax({
   	        			url:"/GSMP/deleteProject?id="+vals,
   	            	    data:data,
   	        			type:"POST",
   	        			success:function(respData){
   	        				if(respData=="Project Deleted Successfully!"){
   	        					$('#resultDiv').removeClass('errorTD').addClass('successTD');
   	        					setTimeout(function(){location.reload();}, 1000);
   	        					
   	        				}else{
   	        					$('#resultDiv').removeClass('successTD').addClass('errorTD');
   	        				}
   	        				
   	        				$('#resultDiv').show();
   	        				$('#resultDiv').html(respData);
   	        				
   	        			},
   	        			error:function(request,status,error){
   	        				
   	        				alert(request.responseText);
   	        			}
   	        		});
   		    	  }
   		     /* else
   		    	  {
   		    	     alert("Cancelled");
   		    	     window.location.reload();
   		    	  }*/
       	  /*var rec_id=null;
       	  
      	        $("input[name='rec']:checked").each(function(i) {
     		             rec_id = this.value;
     		      var per=confirm("Are You Sure Want To Delete");
     		      if(per)
     		    	  {
     		         	   $(this).closest('tr').remove();
     		               var data=$('form').serialize();
     	               $.ajax({
     	        			url:"/GSMP/deleteProject?id="+rec_id,
     	            	    data:data,
     	        			type:"POST",
     	        			success:function(respData){
     	        				if(respData=="Project Deleted Successfully!"){
     	        					$('#resultDiv').removeClass('errorTD').addClass('successTD');
     	        					
     	        					
     	        				}else{
     	        					$('#resultDiv').removeClass('successTD').addClass('errorTD');
     	        				}
     	        				
     	        				$('#resultDiv').show();
     	        				$('#resultDiv').html(respData);
     	        				
     	        			},
     	        			error:function(request,status,error){
     	        				
     	        				alert(request.responseText);
     	        			}
     	        		});
     		    	  }
     		      else
     		    	  {
     		    	     alert("Cancelled");
     		    	     window.location.reload();
     		    	  }
             });
       	
      	        if(rec_id==null)
   		       {
   		        confirm("Pls Select Atleast One Record");
   		         return false;
   		       }
       	 */
          
         });
        
});

function getProjectPage()
{

    $('#projectPage').load('/GSMP/loadProjectPage');
}
function populateProjectData(projectId) {
	
	$('#projectPage').load('/GSMP/editProject?id='+projectId);
 	}


function selectAllCheckBox()
{
	 if (document.getElementById('select_all').checked ==false) {
         $('.person_data').each(function() {
             this.checked = true;
         });
     } else {
         $('.person_data').each(function() {
             this.checked = false;
         });
     }

}


function populateProjectLogData(id) {
    
    // alert("Checking Project log")
     var x = screen.width/2 - 1000/2;
     var y = screen.height/2 - 450/2;
     window.open('/GSMP/loadViewEditProjectLogs?id='+id, '_blank','height=485,width=980,left='+x+',top='+y);

 /*$('#addLocation').load('/GSMP/loadUpdateLocation?id='+id);*/

}


function populateProjectDeletedLogData() {
    
    alert("Checking Project Deleted log")
    var x = screen.width/2 - 1000/2;
    var y = screen.height/2 - 450/2;
    window.open('/GSMP/loadViewEditProjectDeletedLogs', '_blank','height=485,width=980,left='+x+',top='+y);
}
