/**
 * 
 */


function populateUserData(userID) {

	$('#Resource').load('/GSMP/editUser?id='+userID);
}

function addUserPage() {
	//alert("Kundan");

	$('#Resource').load('/GSMP/loadAddUserForm');
}

function populateSkillData(userId) {
	
	alert(userId);	
	
	var result_text=" ";
	$.ajax({
		url:"/GSMP/getIntervSkillsById?interviewId="+interviewId,		
		type:'GET',
		dataType: 'json',
		success:function(respdata){
			
			console.log(respdata);
			//alert(respdata[0].skillsName);
			$.each(respdata,function(index,element){
				//result.push(respdata[index].skillsName);
				result_text+=respdata[index].skillsName+'</br>';
				$("#dialog").html(result_text);
			
			});
			//alert(result_text);
			
		$( "#dialog" ).dialog({ autoOpen: false,resizable:false,position:{ my: "center", at: "center"}});
		
	    $( "#dialog" ).dialog("open");
	    
			//$('.skillpopup').attr('title',result_text);
			//$(document).tooltip();
	   
		}
		})
		
		
	              
}

$(document).ready(function(){
	
	
	/*$('#userAddButton').click(function(event){
		alert("userAddButton");
	});*/
	$('#userCancelButton').click(function(event){
		$('#Container').hide();
	});
	
	$('#userSaveButton').click(function(event){
		//alert("userSaveButton");
		var userId=$('#userId').val();
		//populate variables for Validation
		var fname=$('#fname').val();
		var lname=$('#lname').val();
		var contactNo=$('#contactNo').val();
		var emailId=$('#emailId').val();
		var yoe=$('#userProfile.yearOfExp').val();
		var monthsOfExp=$('#monthsOfExp').val();
		var highestEducation=$('#highestEducation').val();
		
		var valid = /^\d{10}$/;
		//Validation
		if(fname==""|| fname==null){	
			$('#resultDiv').html("<span style='color:red'>Please Enter First Name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(lname==""|| lname==null){	
			$('#resultDiv').html("<span style='color:red'>Please Enter Last Name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(contactNo==""|| contactNo==null){	
			$('#resultDiv').html("<span style='color:red'>Please Enter Contact Number.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(!contactNo.match(valid)){
			$('#resultDiv').html("<span style='color:red'>Please Provide Valid Contact Number.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(emailId==""|| emailId==null){	
			$('#resultDiv').html("<span style='color:red'>Please Enter Email ID.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(yoe==""|| yoe==null){	
			alert("year of exp:"+yearOfExp);
			$('#resultDiv').html("<span style='color:red'>Please Enter Years of Experience.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(monthsOfExp==""|| monthsOfExp==null){	
			$('#resultDiv').html("<span style='color:red'>Please Enter months of Experience.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(highestEducation==""|| highestEducation==null){	
			$('#resultDiv').html("<span style='color:red'>Please Enter Highest Qualifications.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
	    var data=$('form').serialize();
	    $.ajax({
	    	url:"/GSMP/addUser",
	    	data:data,
	    	type:"POST",
	    	
			success:function(respData){ 
			if(respData=="Resource Added Successfully!"){
				$('#resultDiv').removeClass('errorTD').addClass('successTD');
				$('#userId').val('');
				setTimeout(function(){location.reload();}, 1000);
			} else { 
				//alert(respData);
				/*$('#resultDiv').html("<span style='color:red'>"+errorMessage+"</span>");*/
				$('#resultDiv').html("<span style='color:red'>"+respData+"</span>");
				$('#resultDiv').show();
				$('#resultDiv').removeClass('successTD').addClass('errorTD'); 
			}
			$('#resultDiv').show();
			$('#resultDiv').html(respData);
			$("#fade").hide(); $("#PleaseWait").hide();
			$('#hi').load().fadeIn("slow"); },
			 
		    error:function(request,status,error){ 
		    	alert("Err");
		    	$("#fade").hide(); 
		    	$("#PleaseWait").hide(); 
		    } //error
		});// ajax
	});
	
	// Starting update operation
    $('#userUpdateButton').click(function(event){
    	
    	var userId=$('#userId').val();
    	
    	//populate variables for Validation
		var firstname=$('#fname').val();
		var lastname=$('#lname').val();
		var contactNum=$('#contactNo').val();
		var email=$('#emailId').val();
		var yoe=$('#yearOfExp').val();
		var moe=$('#monthsOfExp').val();
		var Edu=$('#highestEducation').val();
		
		var valid = /^\d{10}$/;
		//Validation
		if(firstname==""|| firstname==null){	
			$('#resultDiv').html("<span style='color:red'>Please enter First Name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(!firstname.match(/^[A-Za-z0-9-]/)){
			$('#resultDiv').html("<span style='color:red'>Please enter proper First Name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(lastname==""|| lastname==null){	
			$('#resultDiv').html("<span style='color:red'>Please Enter Last Name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(!lastname.match(/^[A-Za-z0-9-]/)){
			$('#resultDiv').html("<span style='color:red'>Please enter proper first name.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(contactNum==""|| contactNum==null){	
			$('#resultDiv').html("<span style='color:red'>Please enter contact number.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(!contactNum.match(/^\d{10}$/)){
			$('#resultDiv').html("<span style='color:red'>Please provide valid contact number.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(email==""|| email==null){	
			$('#resultDiv').html("<span style='color:red'>Please enter email ID.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(!email.match(/^([A-Za-z0-9])+([A-Za-z0-9_\-\.])+([A-Za-z0-9])+\@igate.com/)){	
			$('#resultDiv').html("<span style='color:red'>Please enter proper igate.com email ID.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		if(yoe==""|| yoe==null){	
			alert("year of exp:"+yoe);
			$('#resultDiv').html("<span style='color:red'>Please enter years of experience.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		if(moe==""|| moe==null){	
			$('#resultDiv').html("<span style='color:red'>Please enter months of experience.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		/*if(!moe.match(/^[0-11]/)){*/
		if(moe>11 || moe<0){	
			$('#resultDiv').html("<span style='color:red'>Please enter between 0 to 11 for months of experience.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		if(Edu==""|| Edu==null){	
			$('#resultDiv').html("<span style='color:red'>Please Enter Highest Qualifications.</span>");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
    	
	    var data=$('form').serialize();
	    $.ajax({
	    	url:"/GSMP/updateUser",
	    	data:data,
	    	type:"POST",
	    	
			success:function(respData){ 
			if(respData=="Resource Details Saved Successfully!"){
				$('#resultDiv').removeClass('errorTD').addClass('successTD');
				$('#userId').val('');
				setTimeout(function(){location.reload();}, 1000);
			} else { 
				$('#resultDiv').html("<span style='color:red'>"+errorMessage+"</span>");
				$('#resultDiv').show();
				$('#resultDiv').removeClass('successTD').addClass('errorTD'); 
			}
			$('#resultDiv').show();
			$('#resultDiv').html(respData);
			$("#fade").hide(); $("#PleaseWait").hide();
			$('#hi').load().fadeIn("slow"); },
			 
		    error:function(request,status,error){ 
		    	alert("Err");
		    	$("#fade").hide(); 
		    	$("#PleaseWait").hide(); 
		    } //error
		});// ajax
    });
    
    $('#userDeleteButton').click(function(event){
    	var checkedUserList = null;
    	//alert("resource.js");
    	if($('input[type=checkbox]:checked').length == 0)
  		{
  		    alert ("ERROR! Please Select Atleast One Record to Delete");
  		    
  		}else{
  			var r = confirm("Are You Sure want to Delete?");
  			if (r == true) {
  				checkedUserList = [];
  				$.each($("input[name='checkedId']:checked"), function(){ 

  					checkedUserList.push($(this).val());
  					//alert(checkedUserList);
      	        	
      	        });
      	       /* alert("selected id's are: " + selected.join(","));*/
  				checkedUserList.join(",");
  			
  			var data=$('form').serialize();
  			$.ajax({
  				url:"/GSMP/DeleteUsers?ids="+checkedUserList,
          	    data:data,
      			type:"POST",
      			
      			success:function(respData){ 
      				if(respData=="User Deleted Successfully!"){
      					$('#resultDiv').removeClass('errorTD').addClass('successTD');
      					$('#userId').val('');
      					setTimeout(function(){location.reload();}, 1000);
      				} else { 
      					$('#resultDiv').html("<span style='color:red'>"+errorMessage+"</span>");
      					$('#resultDiv').show();
      					$('#resultDiv').removeClass('successTD').addClass('errorTD'); 
      				}
      				$('#resultDiv').show();
      				$('#resultDiv').html(respData);
      				$("#fade").hide(); $("#PleaseWait").hide();
      				$('#hi').load().fadeIn("slow"); },
      				 
      			    error:function(request,status,error){ 
      			    	alert("Err");
      			    	$("#fade").hide(); 
      			    	$("#PleaseWait").hide(); 
      			    } 
  				
  			});
  			}//if 'yes'
  			setTimeout(function(){location.reload();}, 1000);
  		}
    });
});

