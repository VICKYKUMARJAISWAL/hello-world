
$(document).ready(function(){
	    


	    //Strting add operation
          $('#skillSubButton').click(function(event){
		
        	        
		          //code added by basavaiah 24th Des15
		              var skillName=$('#skillname').val();
		             
		              
		              if(skillName==""|| skillName==null)
		              {
		                  
		            	  $('#resultDiv').html("<span style='color:red'>Please enter SkillName.</span>");
			              $('#resultDiv').addClass('errorTD');
			              $('#resultDiv').show();
			
			             return false;
	               	 }

                   /* if(comments==""|| comments==null)
                    {
			
			              $('#resultDiv').html("<span style='color:red'>Please enter Comments.</span>");
			              $('#resultDiv').addClass('errorTD');
			              $('#resultDiv').show();
		
			               return false;
                    }*/
		            $('#resultDiv').removeClass('errorTD').addClass('successTD');
		
		 
		
		             var data=$('form').serialize();
		            
		             $.ajax({
			                 url:"/GSMP/addSkill",
			                 data:data,
		                     type:"POST",
			                 success:function(respData){
			                	 //alert("SUCCESS");
				                       if(respData=="Skill Saved Successfully!"){
				                    	   
					                      $('#resultDiv').removeClass('errorTD').addClass('successTD');
					                      $('#skillName').val('');
					                      setTimeout(function(){location.reload();}, 1000);
					                   
				                        }
				                       else {
                                         //  $('#resultDiv').html("<span style='color:red'>"+errorMessage+"</span>");
				                           //   $('#resultDiv').show();
					                        $('#resultDiv').removeClass('successTD').addClass('errorTD');
				                          }
				                    $('#resultDiv').show();
				       				$('#resultDiv').html(respData);
				       				
				       				$("#fade").hide();
				       				$("#PleaseWait").hide();
				       				$('#hi').load().fadeIn("slow");
		                    	},
			                error:function(request,status,error){
			            	          alert("Err");
			            	          $("#fade").hide();
			          				  $("#PleaseWait").hide();
			                    }
		        });
		        
		             
          });//closing save()
          
         
          
          //Strating update
          $('#skillUpdateButton').click(function(event)
        		  {
                 
                  
                 var skillName=$('#skillname').val();
                 
        	  
        	alert("Are You Sure Want to update");
        	  var data=$('form').serialize();
      		//alert(data);
      		$.ajax({
      			url:"/GSMP/updateSkill",
      			data:data,
      			type:"POST",
      			success:function(respData){
      				if(respData=="Skill Updated Successfully!"){
      					$('#resultDiv').removeClass('errorTD').addClass('successTD');
      					$('#skillsName').val('');
      					setTimeout(function(){location.reload();}, 1000);
      					
      				}else{
      					$('#resultDiv').removeClass('successTD').addClass('errorTD');
      				}
      				
      				$('#resultDiv').show();
      				$('#resultDiv').html(respData);
      				
      				$('#updateSkillForm').hide();
      				 
      			},
      			error:function(request,status,error){
      				
      				alert(request.responseText);
      			}
      		});
      		
        });
         
          $("#skillDeleteButton").click(function(){
        	  var rec_id=null;
      		if($('input[type=checkbox]:checked').length == 0)
      		{
      		    alert ("ERROR! Please Select Atleast One Record to Delete");
      		    
      		}else{
      		var r = confirm("Are You Sure want to Delete?");
      		if (r == true) {
      			rec_id = [];
      	        $.each($("input[name='rec']:checked"), function(){ 

      	        	rec_id.push($(this).val());
      	        	/*$(this).closest('tr').remove();*/
      	        });
      	        //alert("selected id's are: " + selected.join(","));
      	      rec_id.join(",");    
      		} 
        	   /*var rec_id=null;
        	  
       	        $("input[name='rec']:checked").each(function(i) {
      		             rec_id = this.value;
      		      var per=confirm("Are You Sure Want To Delete?");
      		      if(per)
      		    	  {
      		         	 */ /* $(this).closest('tr').remove();*/
      		               var data=$('form').serialize();
      	               $.ajax({
      	        			url:"/GSMP/deleteSkill?ids="+rec_id,
      	            	    data:data,
      	        			type:"POST",
      	        			success:function(respData){
      	        				if(respData=="Skill Deleted Successfully!"){
      	        					$('#resultDiv').removeClass('errorTD').addClass('successTD');
      	        					setTimeout(function(){location.reload();}, 1000);
      	        					
      	        					
      	        				}else{
      	        					$('#resultDiv').removeClass('successTD').addClass('errorTD');
      	        				}
      	        				
      	        				$('#resultDiv').show();
      	        				$('#resultDiv').html(respData);
      	        				
      	        			},
      	        			error:function(request,status,error){
      	        				
      	        				alert(request.responseText);
      	        			}
      	        		
      		    	  
      		      
          			});
				}
        	    			     
          });
         
});

function getSkillPage()
{

    $('#addSkill').load('/GSMP/loadSkillPage');
    
}
function populateSkillData(skillId) {
	
	$('#addSkill').load('/GSMP/editSkill?id='+skillId);
 	}

function populateSkillLogData(id) {
	   //alert("Sadhu");
	   var x = screen.width/2 - 1000/2;
	   var y = screen.height/2 - 450/2;
	   window.open('/GSMP/addViewEditSkillLog?id='+id, '_blank','height=485,width=980,left='+x+',top='+y);
}

function populateSkillDeletedLogData() {
		 //  alert("Deleted log Details");
		   var x = screen.width/2 - 1000/2;
		   var y = screen.height/2 - 450/2;
		   window.open('/GSMP/addViewEditSkillDeletedLog', '_blank','height=485,width=980,left='+x+',top='+y);
}

