$.fn.loadUserData=function(){
	$.ajax({
		url:"/GSMP/loadUserProfileData",
		type:"POST",
		contentType: 'application/json',
		success:function(respData){
			if(respData!=null && respData!=""){
				$('#userId').val(respData.userId);
				var expYears = '<option value="'+respData.yearOfExp+'">'+respData.yearOfExp+'</option>';
				for ( var i = 0; i <=20; i++) {
					expYears += '<option value="' + i + '">'
							+ i+ '</option>';
				}
				expYears += '</option>';
				var expMonths='<option value="'+respData.monthsOfExp+'">'+respData.monthsOfExp+'</option>';
				for ( var j = 1; j <=11; j++) {
					expMonths += '<option value="' + j + '">'
							+ j+ '</option>';
				}
				expMonths+= '</option>';
				$('#yearOfExp').html(expYears);
				$('#monthsOfExp').html(expMonths);
				if(respData.highestEducation==" "|| respData.highestEducation==null){
					$("#highestEducation").attr("placeholder", "Please Enter your Qualification");	
				}else{
					$('#highestEducation').val(respData.highestEducation);
				}
				if(respData.expSummary==" "|| respData.expSummary==null){
					$("#expSummary").attr("placeholder", "Please Enter your ExpSummary");	
				}else{
					$('#expSummary').val(respData.expSummary);
				}
				
			}
		},
		error:function(request,status,error){
			alert(request.responseText);
		}
	});
};
$(document).ready(function(){
	$.fn.loadUserData();
	$('#proUpdateSubButton').click(function(){
		var highestEducation=$('#highestEducation').val();
		var expSummary=$('#expSummary').val();
		if(highestEducation==""|| highestEducation==null){
			$('#resultDiv').html("please enter highestEducation!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		
		if(expSummary==""|| expSummary==null){
			$('#resultDiv').html("please enter expSummary!!!");
			$('#resultDiv').addClass('errorTD');
			$('#resultDiv').show();
			return false;
		}
		var data=$('form').serialize();
		$("#fade").show();
		$("#PleaseWait").show();
		$.ajax({
			url:"/GSMP/updateUserProfile",
			data:data,
			type:"POST",
			success:function(respData){
				if(respData=="Data Updated Successfully!"){
					$('#resultDiv').removeClass('errorTD').addClass('successTD');
				}else{
					$('#resultDiv').removeClass('successTD').addClass('errorTD');
				}
				$('#resultDiv').show();
				$('#resultDiv').html(respData);
				$("#fade").hide();
				$("#PleaseWait").hide();
			},
			error:function(request,status,error){
				alert(request.responseText);
				$("#fade").hide();
				$("#PleaseWait").hide();
			}
		});
	});
});