package com.igate.Dao;

import java.util.List;

import com.igate.model.BeSheet;
import com.igate.model.Training;

public interface BeSheetDao {
	List<BeSheet> getBeSheetDetails(int year);

}
