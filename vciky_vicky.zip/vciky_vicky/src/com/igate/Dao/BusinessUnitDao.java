package com.igate.Dao;

import com.igate.beans.BusinessUnitVO;
import com.igate.model.BusinessUnit;

public interface BusinessUnitDao {
	public Integer addBuUnit(BusinessUnitVO businessUnitVO);
	public BusinessUnit getBuUnitByID(Short id);

}
