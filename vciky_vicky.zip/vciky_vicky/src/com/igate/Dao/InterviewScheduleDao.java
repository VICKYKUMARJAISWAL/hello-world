package com.igate.Dao;

import java.util.List;

import com.igate.beans.InterviewVO;
import com.igate.model.InterviewDetail;
import com.igate.model.Skill;

public interface InterviewScheduleDao {

	public Integer addScheduleDetailsData(InterviewVO interviewVO) throws Exception;
	public List<InterviewDetail> getAllAvilableInterviews();
	public List<InterviewDetail> getAllAvilableInterviewsSkills();
	public InterviewDetail getInterviewById(int interviewId);
	
	public List<Skill> getIntervSkillsById(int interviewId);
	public Integer updateInterviewData(InterviewVO interviewVO) throws Exception;
	public Integer deleteInterviewData(String[] strarray);
	
}
