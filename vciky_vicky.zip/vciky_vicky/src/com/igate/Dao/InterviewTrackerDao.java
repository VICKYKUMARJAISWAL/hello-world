package com.igate.Dao;

import com.igate.beans.InterviewTrackerVO;

public interface InterviewTrackerDao {
	
	public String addInterviewTrackerData(InterviewTrackerVO interviewTracker);

}
