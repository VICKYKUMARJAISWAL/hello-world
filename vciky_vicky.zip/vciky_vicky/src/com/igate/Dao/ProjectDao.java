package com.igate.Dao;

import com.igate.beans.ProjectVO;
import com.igate.model.Project;

public interface ProjectDao {
   public Integer addProject(ProjectVO projectVO);
   public Project getProjectById(Short id);
   public Integer updateProject(ProjectVO projectVO);
   //public Integer deleteProject(Short id);
   public Integer deleteProject(String[] id);
}
