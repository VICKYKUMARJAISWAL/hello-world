package com.igate.Dao;

import com.igate.beans.SkillVO;
import com.igate.model.Skill;
import com.igate.beans.SkillLogBean;

public interface SkillDao {
	public Integer addKill(SkillVO skillVo,SkillLogBean skillLogBean);
/*	public Integer addKill(SkillVO skillVo);*/
	public Skill getSkillByID(Short id);
	public Integer updateSkill(SkillVO skillVo);
	public Integer deleteSkill(String[] id);
	public Integer addSkillLog(SkillLogBean SkillLogBean);
}
