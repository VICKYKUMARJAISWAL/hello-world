package com.igate.Dao;

import java.util.List;

import com.igate.model.Sow;

public interface SowDao{
	public List<Sow> getSowList();
}

