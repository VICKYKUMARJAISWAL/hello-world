package com.igate.Dao;

import java.util.List;

import com.igate.beans.TrainingVO;
import com.igate.model.Training;
import com.igate.model.TrainingAssign;
import com.igate.model.TrainingCategory;
import com.igate.model.TrainingMode;

public interface TrainingDao {
	public Integer addTraining(TrainingVO training);
	public List<Training> getAvilableTraining();
	public Training getTrainingById(int id);
	public List<String> getContentType();
	public Integer updateTraining(TrainingVO training);
	public List<String> getCourseName();
	public List<String> getVenueNames();
	public Integer deleteTraining(String[] id);
	public Integer assignTraining(TrainingAssign t);	
}
