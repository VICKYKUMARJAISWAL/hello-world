/**
 * 
 */
package com.igate.Dao;

import java.util.List;

import com.igate.model.InterviewStatusType;
import com.igate.model.User;
import com.igate.model.UserProfile;
import com.igate.model.UserStatus;
import com.igate.model.UserType;


/**
 * @author rm832401
 *
 */
public interface UserDao {
	
public Integer  addUser(User user);
public Integer  loginUser(User user);
public UserType getUserType(short type);
public UserStatus getUserStatus(short status);
public UserProfile getUserProfileData(String userID);
public Integer updateUserProfileData(UserProfile userProfile);
public Integer  updatePassword(User user);
public User getUserData(String userId);
public List<UserStatus> getUserStatus();
public InterviewStatusType getInterviewStatusType(short id);
public List<User> getUserList();
public User getCompleteUserData(String userID);
public Integer updateUser(User user);
public Integer deleteUser(String[] stringArray); 
}
