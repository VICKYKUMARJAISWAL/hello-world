package com.igate.DaoImpl;

import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.igate.Dao.BeSheetDao;
import com.igate.model.BeSheet;
import com.igate.model.Training;

public class BeSheetDaoImpl implements BeSheetDao{

	private static final String PM = "PM";
	@Autowired
	 private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BeSheet> getBeSheetDetails(int year) {
		List<BeSheet> besheetList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			//Query query = session.getNamedQuery("Traing.findAllFromCurrentDate").setDate("startDate", new Date());
			
			System.out.println("inside dao besheet********************");
			//Query query= session.createQuery("select b from BeSheet b");
			
			Query query = session.createSQLQuery("EXEC spGetBestEstimates :iYear")
							.addEntity(BeSheet.class)
							.setParameter("iYear", year);
			
			besheetList = query.list();
			System.out.println("inside dao*******************"+besheetList);
			
			for (BeSheet entity : besheetList) {
				System.out.println(" "+ entity);
			}
			
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}
		System.out.println("Test:******************************"+besheetList.size());
		return besheetList;
	}
}
