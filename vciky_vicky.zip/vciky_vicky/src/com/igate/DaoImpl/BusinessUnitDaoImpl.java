package com.igate.DaoImpl;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.igate.Dao.BusinessUnitDao;
import com.igate.beans.BusinessUnitVO;
import com.igate.model.BusinessUnit;
import com.igate.model.Skill;
@Repository
public class BusinessUnitDaoImpl implements BusinessUnitDao{

	@Autowired
	 private SessionFactory sessionFactory;  
	
	@Override
	public Integer addBuUnit(BusinessUnitVO businessUnitVO) {
		int statusCode = 0;
		Session session=null;
		
           try{
        	   
			 session=sessionFactory.openSession();
			 System.out.println(businessUnitVO.getName());
			 
			BusinessUnit businessUnit=new BusinessUnit();
			 
			businessUnit.setName(businessUnitVO.getName());
			businessUnit.setCreatedBy(businessUnitVO.getCreatedBy()); 
			businessUnit.setCreatedDate(businessUnitVO.getCreatedDate());
			businessUnit.setModifiedBy(businessUnitVO.getModifiedBy());
			businessUnit.setModifiedDate(businessUnitVO.getModifiedDate());
			Serializable id=session.save(businessUnit);
			System.out.println("BuUnitDaoImpl"+id);
			
			
			    
			 
			 statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}
	@Override
	public BusinessUnit getBuUnitByID(Short id) {
		BusinessUnit buUnit = null;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.getNamedQuery("BusinessUnit.findBuUnitById").setInteger("id", id);
			buUnit = (BusinessUnit) query.uniqueResult();
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} 
		return buUnit;
	}

}
