package com.igate.DaoImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.annotations.FetchMode;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.Dao.InterviewScheduleDao;
import com.igate.beans.InterviewVO;
import com.igate.model.BusinessUnit;
import com.igate.model.InterviewDetail;
import com.igate.model.InterviewResourceStatus;
import com.igate.model.InterviewSkill;
import com.igate.model.Location;
import com.igate.model.Project;
import com.igate.model.Skill;

@Service
public class InterviewScheduleDaoImpl implements InterviewScheduleDao {

	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	HttpSession httpSession;

	// add operation in dao
	@Override
	public Integer addScheduleDetailsData(InterviewVO interview)
			throws Exception {
		int statusCode = 0;
		Session session = null;
		try {
			System.out.println("I am from daoadd");
			session = sessionFactory.openSession();
			InterviewDetail intDetails = new InterviewDetail();

			// srinivas

			String userId = (String) httpSession.getAttribute("userId");
			intDetails.setLocationId(interview.getLocationId());
			intDetails.setBusinessUnitId(interview.getBusinessUnitId());
			intDetails.setProjectId(interview.getProjectId());
			intDetails.setOpportunityStartDate(interview
					.getOpportunityStartDate());
			intDetails.setOpportunityEndtartDate(interview
					.getOpportunityEndtartDate());
			intDetails.setName(interview.getName());
			intDetails.setComments(interview.getComments());

			intDetails.setOpportunityStatus(interview.getOpportunityStatus());
			intDetails.setActive("yes");
			//intDetails.setOpportunitystatus(interview.getOpportunitystatus());

			System.out.println("after data pick");

			Integer i = (Integer) session.save(intDetails);

			System.out.println("from dao layer" + i);

			for (Integer interviewSkillId : interview.getInterviewSkills()) {

				InterviewSkill intSkill = new InterviewSkill();

				intSkill.setInterviewid(i);

				intSkill.setSkillId(interviewSkillId);

				// intSkill.setModifiedBy(interviewVO.getCreatedby());

				intSkill.setModifiedBy(userId);
				
				intSkill.setModifiedDate(new java.sql.Time(new java.util.Date()
						.getTime()));
				session.save(intSkill);
			}

			intDetails = (InterviewDetail) session.load(InterviewDetail.class,
					new Integer(1));

			statusCode = 1;

		} catch (Exception ex) {
			statusCode = 0;
			ex.printStackTrace();
		}
		return statusCode;
	}

	// view interview form page
	@Override
	public List<InterviewDetail> getAllAvilableInterviews() {
		// TODO Auto-generated method stub
		List<InterviewDetail> interviewDetailList = null;

		List<InterviewDetail> InterviewList = new ArrayList<InterviewDetail>();

		Session session = null;
		try {

			session = sessionFactory.openSession();
			String hql = "from InterviewDetail i where i.active='yes'";
			Query query = session.createQuery(hql);
			interviewDetailList = query.list();

			for (Object d : interviewDetailList) {
				InterviewDetail detail = (InterviewDetail) d;
				InterviewList.add(detail);
			}

			System.out.println(interviewDetailList);
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}
		return interviewDetailList;
	}

	@Override
	public List<InterviewDetail> getAllAvilableInterviewsSkills() {

		Session session = null;
		List<InterviewDetail> InterviewList = new ArrayList<InterviewDetail>();

		try {
			session = sessionFactory.openSession();

			String hql = " from InterviewDetail i  ";
			Query query = session.createQuery(hql);
			@SuppressWarnings("unchecked")
			List<InterviewDetail> interviewDetailSkillList = query.list();

			for (Object d : interviewDetailSkillList) {
				InterviewDetail detail = (InterviewDetail) d;
				InterviewList.add(detail);
			}
		}

		catch (HibernateException ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}

		return InterviewList;
	}

	// updateform getting operation
	@Override
	public InterviewDetail getInterviewById(int interviewId) {
		// TODO Auto-generated method stub
		InterviewDetail interviewdetail = null;
		Session session = null;
		try {
			System.out.println("from daooooooooooooooooo");
			session = sessionFactory.openSession();
			String hql = "FROM InterviewDetail i WHERE i.interviewId= :interviewId";
			Query query = session.createQuery(hql).setInteger("interviewId",
					interviewId);

			interviewdetail = (InterviewDetail) query.uniqueResult();
			System.out.println("end of daoooooooooooooo");

		} catch (HibernateException ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}
		return interviewdetail;
	}

	@Override
	public List<Skill> getIntervSkillsById(int interviewId) {

		InterviewDetail interviewdetail = null;
		Session session = null;
		// interviewId = 554 ;
		List<Skill> skilllst = new ArrayList<Skill>();

		try {
			session = sessionFactory.openSession();
			interviewdetail = (InterviewDetail) session.get(
					InterviewDetail.class, interviewId);
			skilllst = interviewdetail.getSkills();

		} catch (HibernateException ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}

		System.out.println("In DAO");
		System.out.println(skilllst);
		return skilllst;

	}

	// update operation in dao
	@Override
	public Integer updateInterviewData(InterviewVO interviewVO)
			throws Exception {

		int statusCode = 0;
		try {
			Session session = sessionFactory.openSession();
			Transaction t = session.beginTransaction();

			InterviewDetail interviewdetail = (InterviewDetail) session.load(InterviewDetail.class, interviewVO.getInterviewId());
			interviewdetail.setName(interviewVO.getName());
			interviewdetail.setOpportunityStartDate(interviewVO.getOpportunityStartDate());
			interviewdetail.setOpportunityEndtartDate(interviewVO.getOpportunityEndtartDate());
			//interviewdetail.setOpportunitystatus(interviewVO.getOpportunitystatus());
			
			interviewdetail.setOpportunityStatus(interviewVO.getOpportunityStatus());
			interviewdetail.setLocationId(interviewVO.getLocationId());
			interviewdetail.setComments(interviewVO.getComments());
			interviewdetail.setBusinessUnitId(interviewVO.getBusinessUnitId());
			interviewdetail.setProjectId(interviewVO.getProjectId());

			InterviewSkill skill = null;
			List<Integer> InteviewSkillIds = interviewVO.getInterviewSkills();

			String hql2 = "select skillId FROM InterviewSkill inter WHERE inter.interviewid = :inter_id";
			Query query2 = session.createQuery(hql2).setParameter("inter_id",
					interviewVO.getInterviewId());
			@SuppressWarnings("unchecked")
			List<Integer> results2 = query2.list();

			String userId = (String) httpSession.getAttribute("userId");
			Date date = new java.util.Date();

			for (Integer in : InteviewSkillIds) {
				if (!results2.contains(in)) {
					skill = new InterviewSkill();
					skill.setInterviewid(interviewVO.getInterviewId());
					skill.setSkillId(in);
					
					skill.setModifiedBy(userId);
					
					skill.setModifiedDate(date);
					session.save(skill);
				}

			}
			String hql = "FROM InterviewSkill inter WHERE inter.skillId not in (:skill_Id) and inter.interviewid = :inter_id ";
			Query query = session.createQuery(hql)
					.setParameterList("skill_Id", InteviewSkillIds)
					.setParameter("inter_id", interviewVO.getInterviewId());
			@SuppressWarnings("unchecked")
			List<InterviewSkill> results = query.list();

			for (InterviewSkill in : results) {
				session.delete(in);
				System.out.println(in.getSkillId());

			}

			session.merge(interviewdetail);
			t.commit();
			statusCode = 1;
		} catch (HibernateException ex) {
			statusCode = 0;
			ex.printStackTrace();
		}
		return statusCode;

	}

	// delete operation in dao
	@Override
	public Integer deleteInterviewData(String[] strarray) {

		Integer[] intarray = new Integer[strarray.length];
		System.out.println(intarray);
		int i = 0;
		for (String str : strarray) {
			try {
				intarray[i] = Integer.parseInt(str);
				i++;
			} catch (NumberFormatException e) {
				throw new IllegalArgumentException("Not a number: " + str
						+ " at index " + i, e);
			}
		}

		List<Integer> list = new ArrayList<Integer>();
		for (Integer intlist : intarray) {

			list.add(intlist);
		}
		int statusCode = 0;
		System.out.println("daoimpl del");
		try {
			Session session = sessionFactory.getCurrentSession();
			//Transaction t = session.beginTransaction();
//			Query query2 = session
//					.createQuery("delete from InterviewSkill s where s.interviewid in(:ids)");
//			query2.setParameterList("ids", list);
//			int result2 = query2.executeUpdate();

//			Query query1 = session
//					.createQuery("delete from InterviewDetail i where i.interviewId in(:ids)");
			Query query1 = session
					.createQuery("update InterviewDetail i set active = :no where i.interviewId in(:ids)");				
			query1.setString("no","No");
			query1.setParameterList("ids", list);
			int result1 = query1.executeUpdate();

			if ( result1 > 0) {
				System.out.println("Updated " + result1 + " rows.");
			}

			statusCode = 1;
			//t.commit();
		} catch (HibernateException ex) {
			statusCode = 0;
			ex.printStackTrace();
		}
		return statusCode;
	}

}
