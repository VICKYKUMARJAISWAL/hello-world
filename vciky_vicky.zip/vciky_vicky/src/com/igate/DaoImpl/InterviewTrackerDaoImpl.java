package com.igate.DaoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.igate.Dao.InterviewTrackerDao;
import com.igate.beans.InterviewTrackerVO;
import com.igate.model.InterviewTracker;
import com.igate.utilities.Utilities;

public class InterviewTrackerDaoImpl implements InterviewTrackerDao {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public String addInterviewTrackerData(InterviewTrackerVO interviewTracker) {
		// TODO Auto-generated method stub
		Session sess = null;
		String statusCode = null;
		try {
			
			/*
			 * 
			 * interviewTracker.setStatus("2");
			 * interviewTracker.setLocation("1");
			 * interviewTracker.setModeOfInterview("10");
			 * interviewTracker.setTeamInterviewedFor(1);
			 */

			sess = sessionFactory.getCurrentSession();
			InterviewTracker intrvTracker = new InterviewTracker();
			
			intrvTracker.setUserId(interviewTracker.getResourceName());
			
			intrvTracker.setInterviewDate(new java.sql.Date(interviewTracker.getDateOfInterview().getTime()));
			
			intrvTracker.setProjectId(Integer.parseInt(interviewTracker.getTeamInterviewedFor()));
			
			intrvTracker.setClientManagerName(interviewTracker.getClientManager());
			intrvTracker.setTechnologyStack(interviewTracker.getTechnologyStack());
			intrvTracker.setInterviewRound(Integer.parseInt(interviewTracker.getRoundNumber()));
			
			
			/*intrvTracker.setProjectId((int) interviewTracker.getTeamInterviewedFor());*/
			
			
			intrvTracker.setInterviewStatusId(Integer.parseInt(interviewTracker.getStatus()));
			intrvTracker.setLocationId(Integer.parseInt(interviewTracker.getLocation()));
			intrvTracker.setInterviewMode(Integer.parseInt(interviewTracker.getModeOfInterview()));
			
			intrvTracker.setCreatedBy(interviewTracker.getUserId());
			intrvTracker.setCreatedDate(Utilities.currentDate());
			
			sess.save(intrvTracker);
			statusCode = "Data Saved Successfully!";

		} catch (Exception ex) {
			statusCode = "Data not Saved Successfully!";
			ex.printStackTrace();
		}
		return statusCode;
	}

}
