package com.igate.DaoImpl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.igate.Dao.LocationDao;
import com.igate.beans.LocationVO;
import com.igate.beans.LocationVOBeanLog;
import com.igate.model.Location;
import com.igate.model.LocationLog;
import com.igate.utilities.Utilities;
@Repository
public class LocationDaoImpl implements LocationDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	HttpSession httpSession;

	/*@SuppressWarnings("unchecked")
	@Override
	public List<Location> getAllAvailableLocations(){
		List<Location> locationList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.getNamedQuery("Traing.findAllFromCurrentDate").setDate("startDate", new Date());
			System.out.println("***********************************"+new Date());
			
	        locationList = session.createQuery("from Location").list();
	        
			//locationList = query.list();
			for(Location l:locationList){
				Hibernate.initialize(l.getLocationName());
				Hibernate.initialize(l.getCreatedBy());
				Hibernate.initialize(l.getCreatedDate());
				Hibernate.initialize(l.getId());
				Hibernate.initialize(l.getModifiedBy());
				Hibernate.initialize(l.getModifiedDate());
			}
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}
		System.out.println("***************************************"+locationList.size());
		
		return locationList;
	}*/
	
	@Override
	public Location getLocationById(int id) {
		
		Location location=null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.getNamedQuery("Location.findLocationbyId").setInteger("id", id);
			location=(Location)query.uniqueResult();
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}
		return location;
		
		
	}
	/*@Override
	public Integer addLocationData(LocationVO locationvo){
		Session session = null;
		int statusCode=0;
			try{
				
			
			session = sessionFactory.getCurrentSession();
			Location location = new Location();
			location.setId(locationvo.getId());
			location.setLocationName(locationvo.getLocationName());
			location.setCreatedBy(locationvo.getCreatedBy());
			location.setCreatedDate(Utilities.currentDate());
			location.setModifiedBy(locationvo.getModifiedBy());
			location.setModifiedDate(Utilities.currentDate());
			Serializable id = session.save(location);
			System.out.println(id);
			statusCode=1;
			}catch(Exception e){
				statusCode=0;
				e.printStackTrace();
			}
					
		return statusCode;
		
	}*/
	
	
	@Override
	public Integer addLocationData(LocationVO locationvo){
		Session session,session1 = null;
		int statusCode=0;
			try{
				
			
				session = sessionFactory.getCurrentSession();
				Location location = new Location();
				location.setId(locationvo.getId());
				location.setLocationName(locationvo.getLocationName());
				location.setCreatedBy(locationvo.getCreatedBy());
				location.setCreatedDate(Utilities.currentDate());
				location.setModifiedBy(locationvo.getModifiedBy());
				location.setModifiedDate(Utilities.currentDate());
				Serializable id = session.save(location);
								
				statusCode=location.getId();
				String Locationid=Integer.toString(statusCode);
								
				session1=sessionFactory.getCurrentSession();
				
				LocationVOBeanLog locationLog=new LocationVOBeanLog();
				LocationLog log=new LocationLog();
				locationLog.setLocationId(Locationid);
				locationLog.setCreatedBy(locationvo.getCreatedBy());
				locationLog.setCreatedDate(locationvo.getCreatedDate());
				locationLog.setLocationName(locationvo.getLocationName());
				locationLog.setModifiedBy(locationvo.getModifiedBy());
				locationLog.setModifiedDate(locationvo.getModifiedDate());
				locationLog.setStatus("sucess");
				locationLog.setAction("Add");
			   
			// add data to Location Model
			    
			    
			   
				log.setLocationId(locationLog.getLocationId());
				log.setCreatedBy(locationLog.getCreatedBy());
				log.setCreatedDate(locationLog.getCreatedDate());
				log.setLocationName(locationLog.getLocationName());
				log.setModifiedBy(locationLog.getModifiedBy());
				log.setModifiedDate(locationLog.getModifiedDate());
				log.setStatus(locationLog.getStatus());
				log.setAction(locationLog.getAction());
				
				
				/*System.out.println("Id :-"+locationLog.getLocationId()+" created by :-"+locationLog.getCreatedBy()+" created Date :-"+locationLog.getCreatedDate());
				System.out.println("Location Name:-"+locationLog.getLocationName()+" Modified by:-"+locationLog.getModifiedBy()+" Modified date:-"+locationLog.getModifiedDate());
				System.out.println("Status :-"+locationLog.getStatus()+" Action:-"+locationLog.getAction());*/
				
				session1.save(log);
			
				/*session.flush();
				session.close();
				session1.flush();
				session1.close();*/
			/*	System.out.println("Log data saved sucess fully");*/
			
			
			    System.out.println(id);
			    statusCode=1;
			}catch(Exception e){
				statusCode=0;
				e.printStackTrace();
			}
					
		return statusCode;
		
	}
	
//	public Integer updateLocationData(LocationVO locationvo){
//		
//		int statusCode=0;
//		try{
//			Session session=sessionFactory.openSession();
//			Location locationObj = new Location();
//			
//			Query query=session.getNamedQuery("Location.findLocationbyId").setInteger("id",locationvo.getId() );
//			locationObj = (Location) query.uniqueResult();
//			System.out.println("daoimpl: "+locationvo.getLocationName());
//			Transaction tx=session.beginTransaction();
//			//locationObj.setId(locationvo.getId());
//			locationObj.setCreatedBy(locationvo.getCreatedBy());
//			//locationObj.setCreatedDate(locationvo.getCreatedDate());
//			locationObj.setLocationName(locationvo.getLocationName());
//			locationObj.setModifiedBy(locationvo.getModifiedBy());
//			locationObj.setModifiedDate(locationvo.getModifiedDate());
//			session.merge(locationObj);
//			
//			statusCode=1;
//			tx.commit();
//		}catch(HibernateException ex){
//			statusCode=0;
//			ex.printStackTrace();
//		}
//		return statusCode;
//		
//	}
	
	public Integer updateLocationData(LocationVO locationvo){
        
        int statusCode=0;
        try{
               Session session=sessionFactory.openSession();
               Location locationObj = new Location();
              
               Query query=session.getNamedQuery("Location.findLocationbyId").setInteger("id",locationvo.getId() );
               locationObj = (Location) query.uniqueResult();
               System.out.println("daoimpl: "+locationvo.getLocationName());
               Transaction tx=session.beginTransaction();
               //locationObj.setId(locationvo.getId());
               locationObj.setCreatedBy(locationvo.getCreatedBy());
               //locationObj.setCreatedDate(locationvo.getCreatedDate());
               locationObj.setLocationName(locationvo.getLocationName());
               locationObj.setModifiedBy(locationvo.getModifiedBy());
               locationObj.setModifiedDate(locationvo.getModifiedDate());
              
              
              
               LocationLog log=new LocationLog();
      
       log.setLocationId(locationvo.getId().toString());
       log.setCreatedBy(locationvo.getCreatedBy());
       log.setCreatedDate(locationvo.getCreatedDate());
       log.setLocationName(locationvo.getLocationName());
       log.setModifiedBy(locationvo.getModifiedBy());
       log.setModifiedDate(locationvo.getModifiedDate());
       log.setStatus("success");
       log.setAction("Update");
                          
              
       session.merge(locationObj);
       session.save(log);
              
              
               statusCode=1;
               tx.commit();
        }catch(HibernateException ex){
               statusCode=0;
               ex.printStackTrace();
        }
        return statusCode;
       
 }
/*public Integer deleteLocationData(String[] strarray){
		
		Integer[] intarray=new Integer[strarray.length];
		
		int i=0;
	    for(String str:strarray){
	        try {
	            intarray[i]=Integer.parseInt(str);
	            i++;
	        } catch (NumberFormatException e) {
	            throw new IllegalArgumentException("Not a number: " + str + " at index " + i, e);
	        }
	    }
	    
	    List<Integer> list = new ArrayList<Integer>();
	    for(Integer intlist : intarray){
	    	
	    	list.add(intlist);
	    }
		int statusCode=0;
		System.out.println("daoimpl del");
		try{
			Session session=sessionFactory.openSession();
			
			Query query = session.createQuery("delete from Location where id in(:ids)");
			query.setParameterList("ids", list);
			 
			int result = query.executeUpdate();
			if (result > 0) {
				System.out.println("Deleted " + result + " rows.");
			}
			
			Transaction tx=session.beginTransaction();
		
			tx.commit();
			statusCode=1;
		}catch(HibernateException ex){
			statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}*/

	
	public Integer deleteLocationData(String[] strarray){
        
        Integer[] intarray=new Integer[strarray.length];
        Integer id=0;
        int i=0;
     for(String str:strarray){
         try {
             intarray[i]=Integer.parseInt(str);
             i++;
         } catch (NumberFormatException e) {
             throw new IllegalArgumentException("Not a number: " + str + " at index " + i, e);
         }
     }
    
   
        int statusCode=0;
        System.out.println("daoimpl del");
        try{
               Session session=sessionFactory.openSession();
                
               List<Integer> list = new ArrayList<Integer>();
                   for(Integer intlist : intarray){
                     
                      list.add(intlist);
                      System.out.println("sadhu :-"+intlist);
                      id=intlist;
                   }
              
                   Location location=(Location)session.load(Location.class, id);
                     LocationLog log=new LocationLog();
                       
                     log.setLocationId(id.toString());
                     log.setCreatedBy(location.getCreatedBy());
                     log.setCreatedDate(location.getCreatedDate());
                     log.setLocationName(location.getLocationName());
                     log.setModifiedBy(location.getModifiedBy());
                     log.setModifiedDate(location.getModifiedDate());
                     log.setStatus("success");
                     log.setAction("Delete");
                    
                     System.out.println("id:-"+id.toString()+" created By :-"+location.getCreatedBy()+" created Date :-"+location.getCreatedDate());
                     System.out.println("Location time :-"+location.getLocationName()+" Modified by :-"+location.getModifiedBy()+" modified Date :-"+location.getModifiedDate());
                     System.out.println("status :"+log.getStatus()+" action :"+log.getAction());
                     session.save(log);
                                  
              
              
              
               // End of Audit log
              
               Query query = session.createQuery("delete from Location where id in(:ids)");
               query.setParameterList("ids", list);
              
               int result = query.executeUpdate();
               if (result > 0) {
                     System.out.println("Deleted " + result + " rows.");
               }
              
               Transaction tx=session.beginTransaction();
       
               tx.commit();
               statusCode=1;
        }catch(HibernateException ex){
               statusCode=0;
               ex.printStackTrace();
        }
        return statusCode;
 }

	
	
}
