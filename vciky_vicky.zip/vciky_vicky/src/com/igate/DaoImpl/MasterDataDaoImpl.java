package com.igate.DaoImpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.igate.Dao.MasterDataDao;
import com.igate.model.BusinessUnit;
import com.igate.model.InterviewStatus;
import com.igate.model.Location;
import com.igate.model.LocationLog;
import com.igate.model.ModeOfInterview;
import com.igate.model.Project;
import com.igate.model.ProjectLog;
import com.igate.model.Skill;
import com.igate.model.SkillLog;
import com.igate.model.Training;
import com.igate.model.TrainingCategory;
import com.igate.model.TrainingMode;
import com.igate.model.TypeOfInterview;
import com.igate.model.User;
@Repository
public class MasterDataDaoImpl implements MasterDataDao {
	@Autowired
	private SessionFactory sessionFactory;
	@Override
	@SuppressWarnings("unchecked") 
	public List<Skill> getAllSkills() {
		
			return (List<Skill>) sessionFactory.getCurrentSession().createCriteria(Skill.class).list();
	
	}

	// skill Log Details
	
		@Override
	    @SuppressWarnings("unchecked")
	    public List<SkillLog> getAllSkillsLog(String id) {
	                   
	                    Criteria crit = sessionFactory.getCurrentSession().createCriteria(SkillLog.class);
	                    List<SkillLog> results=crit.add(Restrictions.eq("skillId",id)).list();
	   
	                    return results;
	        }
		
		
		
		// End
		
		// skill Deleted Log Details
		
			@Override
		    @SuppressWarnings("unchecked")
		    public List<SkillLog> getAllSkillsDeletedLog() {
		                   
				  Criteria crit = sessionFactory.getCurrentSession().createCriteria(SkillLog.class);
	              List<SkillLog> results=crit.add(Restrictions.eq("action","delete")).list();
	              return results;
		        }
			
			
			
			// End
		
	
	
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Location> getAllLocations() {
		return (List<Location>) sessionFactory.getCurrentSession().createCriteria(Location.class).list();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Project> getAllProjects() {
		
		return (List<Project>) sessionFactory.getCurrentSession().createCriteria(Project.class).list();
		
		       
	}

	@Override
	public Project getProject(String userId) {
		return (Project) sessionFactory.getCurrentSession().get(Project.class, userId);
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<TypeOfInterview> getAllTypeOfInterviews() {
		return (List<TypeOfInterview>) sessionFactory.getCurrentSession().createCriteria(TypeOfInterview.class).list();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<ModeOfInterview> getAllModeOfInterviews() {
		return (List<ModeOfInterview>) sessionFactory.getCurrentSession().createCriteria(ModeOfInterview.class).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BusinessUnit> getAllBusinessunits() {
		// TODO Auto-generated method stub
		return (List<BusinessUnit>)sessionFactory.getCurrentSession().createCriteria(BusinessUnit.class).list();
	}

	@SuppressWarnings("unchecked")
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		System.out.println("List of Users"+(List<User>)sessionFactory.getCurrentSession().createCriteria(User.class).list());
		             
		return (List<User>)sessionFactory.getCurrentSession().createQuery("select u from User u").list();
	}
	//code  added by Ajaya 20150907
		@SuppressWarnings("unchecked")
		@Override
		public List<TrainingCategory> getAllTrainingCategories() {
			// TODO Auto-generated method stub
			//List<TrainingCategory> trngCategoryList=new ArrayList<TrainingCategory>();
			System.out.println("train"+(List<TrainingCategory>) sessionFactory.getCurrentSession().createCriteria(TrainingCategory.class).list());
			return (List<TrainingCategory>) sessionFactory.getCurrentSession().createCriteria(TrainingCategory.class).list();
		}

		@Override
		public List<TrainingMode> getAllTrainingModes() {
			// TODO Auto-generated method stub
			return (List<TrainingMode>) sessionFactory.getCurrentSession().createCriteria(TrainingMode.class).list();		
		
		}

		@Override
		@SuppressWarnings("unchecked")
		public List<InterviewStatus> getAllStatus() {
			// TODO Auto-generated method stub
			return (List<InterviewStatus>) sessionFactory.getCurrentSession().createCriteria(InterviewStatus.class).list();
			//return null;
		}

		/*@SuppressWarnings("unchecked")
		@Override
		public List<Training> getAllTrainingContentType() {
			// TODO Auto-generated method stub
			
			return(List<Training>) sessionFactory.getCurrentSession().createCriteria(Training.class).list();
		}*/

		@Override
        @SuppressWarnings("unchecked")
        public List<LocationLog> getAllLocationsLog(String id) {
                       
                       
                        Criteria crit = sessionFactory.getCurrentSession().createCriteria(LocationLog.class);
                        List<LocationLog> results=crit.add(Restrictions.eq("locationId",id)).list();
       
                        return results;
        }
        //  show deleted Item of Location Log
       
        @Override
        @SuppressWarnings("unchecked")
        public List<LocationLog> getAllLocationsDeletedLog() {
                        Criteria crit = sessionFactory.getCurrentSession().createCriteria(LocationLog.class);
                        List<LocationLog> results=crit.add(Restrictions.eq("action","Delete")).list();
                        return results;
        }


        @Override
        @SuppressWarnings("unchecked")
        public List<ProjectLog> getAllProjectsLog(String id) {
                       
                         Criteria crit = sessionFactory.getCurrentSession().createCriteria(ProjectLog.class);
                        List<ProjectLog> results=crit.add(Restrictions.eq("projectid",id)).list();
       
                        return results;
            }
    	
    	
    	// Deleted Logs for Project
    	@Override
        @SuppressWarnings("unchecked")
        public List<ProjectLog> getAllProjectsDeletedLog() {
                       
    		  Criteria crit = sessionFactory.getCurrentSession().createCriteria(ProjectLog.class);
              List<ProjectLog> results=crit.add(Restrictions.eq("action","Delete")).list();
              return results;
            }
    	
    	// End

		
	

}
