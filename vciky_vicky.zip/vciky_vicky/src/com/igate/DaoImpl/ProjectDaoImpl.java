package com.igate.DaoImpl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.igate.Dao.ProjectDao;
import com.igate.beans.ProjectVO;
import com.igate.model.Location;
import com.igate.model.Project;
import com.igate.model.ProjectLog;
@Repository
public class ProjectDaoImpl implements ProjectDao{
	@Autowired
	 private SessionFactory sessionFactory;  
	/*@Override
	public Integer addProject(ProjectVO projectVO) {
		int statusCode =0;
		Session session=null;
		 try{
      	   
			 session=sessionFactory.getCurrentSession();
			 System.out.println("Project Id"+projectVO.getCreatedBy());
			 System.out.println(projectVO.getProjectName());
			 Project p1=getProjectById(projectVO.getId());
			 if(p1.getProjectName().equals(projectVO.getProjectName()))
			 {
				 statusCode=2;
			 }
			
			 Project project=new Project();
			project.setProjectName(projectVO.getProjectName());
			project.setCreatedBy(projectVO.getCreatedBy());
			project.setCreatedDate(projectVO.getCreatedDate());
			project.setModifiedBy(projectVO.getModifiedBy());
			project.setModifiedDate(projectVO.getModifiedDate());
			Serializable id=session.save(project);
			System.out.println(id);
			
			
			    
			 
			 statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}*/
	
	
	@Override
	public Integer addProject(ProjectVO projectVO) {
		int statusCode =0;
		Session session=null;
		 try{
      	   
			 session=sessionFactory.getCurrentSession();
			 System.out.println("Project Id"+projectVO.getCreatedBy());
			 System.out.println(projectVO.getProjectName());
			
			Project project=new Project();
			project.setProjectName(projectVO.getProjectName());
			project.setCreatedBy(projectVO.getCreatedBy());
			project.setCreatedDate(projectVO.getCreatedDate());
			project.setModifiedBy(projectVO.getModifiedBy());
			project.setModifiedDate(projectVO.getModifiedDate());
			Serializable id=session.save(project);
			
			System.out.println("Project id:-"+project.getId()+" project name :-"+project.getProjectName());
			// FOR lOG Data
			ProjectLog logObject=new ProjectLog();
			
			logObject.setProjectid(Integer.toString(project.getId()));
			logObject.setProjectName(project.getProjectName());
			logObject.setCreatedBy(project.getCreatedBy());
			logObject.setCreatedDate(project.getCreatedDate());
			logObject.setModifiedBy(project.getModifiedBy());
			logObject.setModifiedDate(project.getModifiedDate());
			logObject.setAction("Add");
			logObject.setStatus("Success");
			
			session.save(logObject);
			/*session.flush();
			session.close();*/
			System.out.println("Log Saved successfully");
			
			statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}
	
	
	@Override
	public Project getProjectById(Short id) {
		Project project=null;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.getNamedQuery("Project.findProjectById").setInteger("id", id);
			project = (Project)query.uniqueResult();
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} 
		return project;
	}
	@Override
	public Integer updateProject(ProjectVO projectVO) {
		int statusCode = 0;
		Session session=null;
		System.out.println(projectVO.getCreatedBy());
		Project project = null;
           try{
   		    	
			   session = sessionFactory.openSession();
			   Query query=session.getNamedQuery("Project.findProjectById").setInteger("id",projectVO.getId() );
			   project = (Project) query.uniqueResult();
			  if(project==null)
			  {
				  
			  }
			      Transaction tx=session.beginTransaction();
			      project.setProjectName(projectVO.getProjectName());
			      System.out.println("Test Update:-"+projectVO.getProjectName());
			      project.setCreatedBy(projectVO.getCreatedBy());
			      project.setModifiedBy(projectVO.getModifiedBy());
			      project.setModifiedDate(projectVO.getModifiedDate());
			      
			          
			      
			        ProjectLog logObject=new ProjectLog();
					
					logObject.setProjectid(Integer.toString(project.getId()));
					logObject.setProjectName(projectVO.getProjectName());
					 System.out.println("Test Update Log:-"+project.getProjectName());
					
					logObject.setCreatedBy(project.getCreatedBy());
					logObject.setCreatedDate(project.getCreatedDate());
					logObject.setModifiedBy(project.getModifiedBy());
					logObject.setModifiedDate(project.getModifiedDate());
					logObject.setAction("Update");
					logObject.setStatus("Success");
					
					session.merge(logObject);
			        session.merge(project);
			        tx.commit();
				
			 
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}
	/*@Override
	public Integer deleteProject(Short id) {
		System.out.println("Dao id"+id);
		int statusCode = 0;
		Session session=null;
		
		Project project=null;
           try{
   		    	
			    session = sessionFactory.openSession();
			    String hql = "delete from Project where id =:id";
		        Query query = session.createQuery(hql);
		        query.setInteger("id",id);
		        int rowCount = query.executeUpdate();
		        System.out.println("Rows affected: " + rowCount);
			 
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			 ex.printStackTrace();
		}
		return statusCode;
	}*/
	
	/*@Override
	public Integer deleteProject(String[] id) {
		
	      	short[] intArray = new short[id.length];
	      for (int i = 0; i < id.length; i++) {
	         String numberAsString = id[i];
	         intArray[i] = Short.parseShort(numberAsString);
	      }
	      
	      List<Short> list=new ArrayList<Short>();
	      for (Short short1 : intArray)
	       {
			        list.add(short1);
		   }
		int statusCode = 0;
		Session session=null;
		
		
           try{
   		    	
			    session = sessionFactory.openSession();
			    String hql = "delete from Project where id in(:ids)";
		        Query query = session.createQuery(hql);
		        query.setParameterList("ids", list);
		        int rowCount = query.executeUpdate();
		        System.out.println("Rows affected: " + rowCount);
		        
			 
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			 ex.printStackTrace();
		}
		return statusCode;
	}*/
	
	
	@Override
	public Integer deleteProject(String[] id) {
		
	      short[] intArray = new short[id.length];
	      Short ids=0;
	      for (int i = 0; i < id.length; i++) {
	         String numberAsString = id[i];
	         intArray[i] = Short.parseShort(numberAsString);
	      }
	      
	      List<Short> list=new ArrayList<Short>();
	      for (Short short1 : intArray)
	       {
			        list.add(short1);
			        
			        ids=short1;
			        System.out.println("Test ids :-"+ids);
			        
		   }
	           
	      
		int statusCode = 0;
		Session session=null;
		
		
           try{
   		    	
			    session = sessionFactory.openSession();
			    
			    // Database Log
			    
			    Project project=(Project)session.load(Project.class, ids);
		        ProjectLog logObject=new ProjectLog();
				
		        System.out.println("Id:-"+Integer.toString(ids)+"Project Name:-"+project.getProjectName());
			
		        logObject.setProjectid(Integer.toString(ids));
				logObject.setProjectName(project.getProjectName());
				logObject.setCreatedBy(project.getCreatedBy());
				logObject.setCreatedDate(project.getCreatedDate());
				logObject.setModifiedBy(project.getModifiedBy());
				logObject.setModifiedDate(project.getModifiedDate());
				logObject.setAction("Delete");
				logObject.setStatus("Success");

				session.save(logObject);
			        
			    
			   // End of Log 
			    
			    
			    
			    String hql = "delete from Project where id in(:ids)";
		        Query query = session.createQuery(hql);
		        query.setParameterList("ids", list);
		        int rowCount = query.executeUpdate();
		        System.out.println("Rows affected: " + rowCount);
		        Transaction tx=session.beginTransaction();
		        
	             tx.commit();
			 
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			 ex.printStackTrace();
		}
		return statusCode;
	}
	
	
	
	
	
	

}





/*package com.igate.DaoImpl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.igate.Dao.ProjectDao;
import com.igate.beans.ProjectVO;
import com.igate.model.Project;
@Repository
public class ProjectDaoImpl implements ProjectDao{
	@Autowired
	 private SessionFactory sessionFactory;  
	@Override
	public Integer addProject(ProjectVO projectVO) {
		int statusCode =0;
		Session session=null;
		 try{
      	   
			 session=sessionFactory.getCurrentSession();
			 System.out.println("Project Id"+projectVO.getCreatedBy());
			 System.out.println(projectVO.getProjectName());
			 Project p1=getProjectById(projectVO.getId());
			 if(p1.getProjectName().equals(projectVO.getProjectName()))
			 {
				 statusCode=2;
			 }
			
			 Project project=new Project();
			project.setProjectName(projectVO.getProjectName());
			project.setCreatedBy(projectVO.getCreatedBy());
			project.setCreatedDate(projectVO.getCreatedDate());
			project.setModifiedBy(projectVO.getModifiedBy());
			project.setModifiedDate(projectVO.getModifiedDate());
			Serializable id=session.save(project);
			System.out.println(id);
			
			
			    
			 
			 statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}
	@Override
	public Project getProjectById(Short id) {
		Project project=null;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.getNamedQuery("Project.findProjectById").setInteger("id", id);
			project = (Project)query.uniqueResult();
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} 
		return project;
	}
	@Override
	public Integer updateProject(ProjectVO projectVO) {
		int statusCode = 0;
		Session session=null;
		System.out.println(projectVO.getCreatedBy());
		Project project = null;
           try{
   		    	
			   session = sessionFactory.openSession();
			   Query query=session.getNamedQuery("Project.findProjectById").setInteger("id",projectVO.getId() );
			   project = (Project) query.uniqueResult();
			  if(project==null)
			  {
				  
			  }
			  Transaction tx=session.beginTransaction();
			      project.setProjectName(projectVO.getProjectName());
			      project.setCreatedBy(projectVO.getCreatedBy());
			      project.setModifiedBy(projectVO.getModifiedBy());
			      project.setModifiedDate(projectVO.getModifiedDate());
			        session.merge(project);
			        tx.commit();
				
			 
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}
	@Override
	public Integer deleteProject(Short id) {
		System.out.println("Dao id"+id);
		int statusCode = 0;
		Session session=null;
		
		Project project=null;
           try{
   		    	
			    session = sessionFactory.openSession();
			    String hql = "delete from Project where id =:id";
		        Query query = session.createQuery(hql);
		        query.setInteger("id",id);
		        int rowCount = query.executeUpdate();
		        System.out.println("Rows affected: " + rowCount);
			 
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			 ex.printStackTrace();
		}
		return statusCode;
	}
	
	@Override
	public Integer deleteProject(String[] id) {
		
	      	short[] intArray = new short[id.length];
	      for (int i = 0; i < id.length; i++) {
	         String numberAsString = id[i];
	         intArray[i] = Short.parseShort(numberAsString);
	      }
	      
	      List<Short> list=new ArrayList<Short>();
	      for (Short short1 : intArray)
	       {
			        list.add(short1);
		   }
		int statusCode = 0;
		Session session=null;
		
		
           try{
   		    	
			    session = sessionFactory.openSession();
			    String hql = "delete from Project where id in(:ids)";
		        Query query = session.createQuery(hql);
		        query.setParameterList("ids", list);
		        int rowCount = query.executeUpdate();
		        System.out.println("Rows affected: " + rowCount);
		        
			 
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			 ex.printStackTrace();
		}
		return statusCode;
	}

}
*/