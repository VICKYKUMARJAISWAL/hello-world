package com.igate.DaoImpl;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.igate.Dao.SkillDao;
import com.igate.beans.SkillVO;
import com.igate.model.Skill;
import com.igate.model.Training;
import com.igate.Dao.SkillDao;
import com.igate.beans.SkillVO;
import com.igate.model.Skill;
import com.igate.model.SkillLog;
import com.igate.model.Training;
import com.igate.utilities.Utilities;
import com.igate.beans.SkillLogBean;

@Repository
public class SkillDaoImpl implements SkillDao{
	@Autowired
	 private SessionFactory sessionFactory;  
	
	@Override
	public Integer addKill(SkillVO skillVo,SkillLogBean skillLogBean) {
		int statusCode = 0;
		Session session=null;
		
           try{
        	   
			 session=sessionFactory.openSession();
			 System.out.println(skillVo.getSkillsName());
			 
			 Skill skillObject = new Skill();
			 
			 skillObject.setSkillsName(skillVo.getSkillsName());
			 skillObject.setCreatedBy(skillVo.getCreatedBy());
			 skillObject.setCreatedDate(skillVo.getCreatedDate());
			 skillObject.setModifiedBy(skillVo.getModifiedBy());
			 skillObject.setModifiedDate(skillVo.getModifiedDate());
			 
			Serializable id=session.save(skillObject);
			statusCode=skillObject.getId();
			
			
			
			 String skillId=Integer.toString(statusCode);
			
			 SkillLog skillLogObject = new SkillLog();
			 skillLogObject.setSkillId(skillId);
			 
			 skillLogObject.setAction(skillLogBean.getAction());
			 skillLogObject.setModifiedBy(skillLogBean.getModifiedBy());
			 skillLogObject.setModifiedDate(skillLogBean.getModifiedDate());
			 skillLogObject.setSkillsName(skillLogBean.getSkillsName());
			 skillLogObject.setStatus(skillLogBean.getStatus());
			
			 System.out.println("Inside Log:-id "+skillLogObject.getSkillId()+" Action :-"+skillLogObject.getAction()+" Modified By :-"+skillLogObject.getModifiedBy()+" Modified Date:-"+skillLogObject.getModifiedDate()+" skill Name:-"+skillLogObject.getSkillsName()+" status :-"+skillLogObject.getStatus());
			 session.save(skillLogObject);
			 System.out.println("Master Log Table updated sucess fully");
			 session.flush();
			 session.close();
			 
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}
	/*@Override
	public Integer addKill(SkillVO skillVo) {
		int statusCode = 0;
		Session session=null;
		
           try{
        	   
			 session=sessionFactory.openSession();
			 System.out.println(skillVo.getSkillsName());
			 
			 Skill skillObject = new Skill();
			 
			 skillObject.setSkillsName(skillVo.getSkillsName());
			 skillObject.setCreatedBy(skillVo.getCreatedBy());
			 skillObject.setCreatedDate(skillVo.getCreatedDate());
			 skillObject.setModifiedBy(skillVo.getModifiedBy());
			 skillObject.setModifiedDate(skillVo.getModifiedDate());
			 
			Serializable id=session.save(skillObject);
			System.out.println(id);
			
			
			    
			 
			 statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}
*/
	
	@Override
	public Skill getSkillByID(Short id) {
		Skill skill = null;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.getNamedQuery("Skill.findSkillById").setInteger("id", id);
			   skill = (Skill) query.uniqueResult();
			  
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} 
		return skill;
	}

	/*@Override
	public Integer updateSkill(SkillVO skillVo) {
		int statusCode = 0;
		Session session=null;
		System.out.println(skillVo.getCreatedBy());
		Skill skill = null;
           try{
   		    	
			   session = sessionFactory.openSession();
			   Query query=session.getNamedQuery("Skill.findSkillById").setInteger("id",skillVo.getId());
			   skill = (Skill) query.uniqueResult();
			  if(skill==null)
			  {
				  
			  }
			  
			        Transaction tx=session.beginTransaction();
			        skill.setSkillsName(skillVo.getSkillsName());
			        skill.setCreatedBy(skillVo.getCreatedBy());
			        skill.setModifiedBy(skillVo.getModifiedBy());
			        skill.setModifiedDate(skillVo.getModifiedDate());
			        session.merge(skill);
			        tx.commit();
				
			 
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}*/

    // sadhu 
	@Override
	public Integer updateSkill(SkillVO skillVo) {
		int statusCode = 0;
		Session session=null,session1=null;
		System.out.println(skillVo.getCreatedBy());
		Skill skill = null;
           try{
   		    	
			   session = sessionFactory.openSession();
			  // session1 = sessionFactory.openSession();
			   Query query=session.getNamedQuery("Skill.findSkillById").setInteger("id",skillVo.getId());
			   skill = (Skill) query.uniqueResult();
			  if(skill==null)
			  {
				  
			  }
			  
			        Transaction tx=session.beginTransaction();
			        skill.setSkillsName(skillVo.getSkillsName());
			        skill.setCreatedBy(skillVo.getCreatedBy());
			        skill.setModifiedBy(skillVo.getModifiedBy());
			        skill.setModifiedDate(skillVo.getModifiedDate());
			        /*session.merge(skill);
			        tx.commit();*/
				   
			      
			        String datetime=skillVo.getModifiedDate().toString();
			        DateFormat formatter;
			        String dateFormat = datetime.toString();
			        formatter = new SimpleDateFormat("yyyy-MM-dd");
			        Date date = (Date) formatter.parse(dateFormat);      
			        			       
			        
			          String id=Integer.toString(skillVo.getId());
			          SkillLog LogObject = new SkillLog();
					 
			          LogObject.setSkillId(id);
					 
			          LogObject.setAction("Update");
			          LogObject.setModifiedBy(skillVo.getModifiedBy());
			          LogObject.setModifiedDate(new Timestamp(date.getTime()));
			         // LogObject.setModifiedDate(Utilities.currentDate());
					 
			          LogObject.setSkillsName(skillVo.getSkillsName());
			          LogObject.setStatus("success");
					
					  System.out.println("ID:-"+id+" Modified by:-"+skillVo.getModifiedBy()+" Modified Date :-"+Utilities.currentDate()+" Skill name:-"+skillVo.getSkillsName());
					  session.merge(skill);
				      session.save(LogObject);
				      
					  tx.commit();
					// tx.commit();
					 System.out.println("Master Log Table updated sucess fully");
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return statusCode;
	}
	
	
	
	
	
	
	/*@Override
	public Integer deleteSkill(Short id) {
		System.out.println("Dao id"+id);
		int statusCode = 0;
		Session session=null;
		
		Skill skill=null;
           try{
   		    	
			    session = sessionFactory.openSession();
			    String hql = "delete from Skill where id =:id";
		        Query query = session.createQuery(hql);
		        query.setInteger("id",id);
		        int rowCount = query.executeUpdate();
		        System.out.println("Rows affected: " + rowCount);
			 
			
			 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			 ex.printStackTrace();
		}
		return statusCode;
	}*/
	@Override
	public Integer deleteSkill(String[] id) {

      	short[] intArray = new short[id.length];
      for (int i = 0; i < id.length; i++) {
         String numberAsString = id[i];
         intArray[i] = Short.parseShort(numberAsString);
      }
      
      List<Short> list=new ArrayList<Short>();
      for (Short short1 : intArray)
       {
		        list.add(short1);
	   }
      	int statusCode = 0;
      	Session session=null;
          /* try{
   		    	
			    session = sessionFactory.openSession();
			    
			    // test
			    Skill sk=(Skill)session.load(Skill.class, id);
			    System.out.println("sadhu:-"+sk.getCreatedBy());
			    System.out.println("sadhu:-"+sk.getModifiedBy());
			    System.out.println("sadhu:-"+sk.getModifiedDate());
			    String skillId=Integer.toString(id);
			     SkillLog skillLogObject = new SkillLog();
				 skillLogObject.setSkill_ID(skillId);
				 
				 skillLogObject.setAction("delete");
				 skillLogObject.setModifiedBy(sk.getModifiedBy());
				 skillLogObject.setModifiedDate(Utilities.currentDate());
				 skillLogObject.setSkillsName(sk.getSkillsName());
				 skillLogObject.setStatus("sucess");
				
				 System.out.println("Inside Delete Log:-id "+skillLogObject.getSkill_ID()+" Action :-"+skillLogObject.getAction()+" Modified By :-"+skillLogObject.getModifiedBy()+" Modified Date:-"+skillLogObject.getModifiedDate()+" skill Name:-"+skillLogObject.getSkillsName()+" status :-"+skillLogObject.getStatus());
				 session.save(skillLogObject);
				 System.out.println("Master Log Table updated sucess fully");
				//test
			    String hql = "delete from Skill where id =:id";
		        Query query = session.createQuery(hql);
		        query.setInteger("id",id);
		        int rowCount = query.executeUpdate();
		        System.out.println("Rows affected: " + rowCount);
		        session.flush();
				session.close();
		       		 
			 
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			 ex.printStackTrace();
		}*/
      	 try{
		    	
			    session = sessionFactory.openSession();
			    String hql = "delete from Skill where id in(:ids)";
		        Query query = session.createQuery(hql);
		        query.setParameterList("ids", list);
		        int rowCount = query.executeUpdate();
		        System.out.println("Rows affected: " + rowCount);
		        
			  statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			 ex.printStackTrace();
		}
		return statusCode;
	}
	
	@Override
	public Integer addSkillLog(SkillLogBean SkillLogBean) {
		int statusCode = 0;
		Session session=null;
		
           try{
        	   
			 session=sessionFactory.openSession();
				 
			 SkillLog skillObject = new SkillLog();
			 skillObject.setSkillId(SkillLogBean.getSkill_ID());
			 
			 skillObject.setAction(SkillLogBean.getAction());
			 skillObject.setModifiedBy(SkillLogBean.getModifiedBy());
			 skillObject.setModifiedDate(SkillLogBean.getModifiedDate());
			 skillObject.setSkillsName(SkillLogBean.getSkillsName());
			 skillObject.setStatus(SkillLogBean.getStatus());
			 
			 
			 System.out.println("Inside Log:-id "+SkillLogBean.getSkill_ID()+" Action :-"+SkillLogBean.getAction()+" Modified By :-"+SkillLogBean.getModifiedBy()+" Modified Date:-"+SkillLogBean.getModifiedDate()+" skill Name:-"+SkillLogBean.getSkillsName()+" status :-"+SkillLogBean.getStatus());
			 session.save(skillObject);
			 System.out.println("Log Table updated sucess fully");
			
			
			    
			 
			 statusCode=1;
		}catch(HibernateException ex){

		        
			 statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}

}




//
//
//
//package com.igate.DaoImpl;
//
//import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.Iterator;
//import java.util.List;
//
//import org.hibernate.HibernateException;
//import org.hibernate.Query;
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
//
//import com.igate.Dao.SkillDao;
//import com.igate.beans.SkillVO;
//import com.igate.model.Skill;
//import com.igate.model.SkillLog;
//import com.igate.beans.SkillLogBean;
//import java.sql.Timestamp;
//import java.text.DateFormat;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//
// 
//
//@Repository
//public class SkillDaoImpl implements SkillDao{
//	@Autowired
//	 private SessionFactory sessionFactory;  
//	
//	@Override
//	public Integer addKill(SkillVO skillVo,SkillLogBean skillLogBean) {
//		int statusCode = 0;
//		Session session=null;
//		
//           try{
//        	   
//			 session=sessionFactory.openSession();
//			 System.out.println(skillVo.getSkillsName());
//			 
//			 Skill skillObject = new Skill();
//			 
//			 skillObject.setSkillsName(skillVo.getSkillsName());
//			 skillObject.setCreatedBy(skillVo.getCreatedBy());
//			 skillObject.setCreatedDate(skillVo.getCreatedDate());
//			 skillObject.setModifiedBy(skillVo.getModifiedBy());
//			 skillObject.setModifiedDate(skillVo.getModifiedDate());
//			 
//			Serializable id=session.save(skillObject);
//			statusCode=skillObject.getId();
//			
//			
//			
//			 String skillId=Integer.toString(statusCode);
//			
//			 SkillLog skillLogObject = new SkillLog();
//			 skillLogObject.setSkill_ID(skillId);
//			 
//			 skillLogObject.setAction(skillLogBean.getAction());
//			 skillLogObject.setModifiedBy(skillLogBean.getModifiedBy());
//			 skillLogObject.setModifiedDate(skillLogBean.getModifiedDate());
//			 skillLogObject.setSkillsName(skillLogBean.getSkillsName());
//			 skillLogObject.setStatus(skillLogBean.getStatus());
//			
//			 System.out.println("Inside Log:-id "+skillLogObject.getSkill_ID()+" Action :-"+skillLogObject.getAction()+" Modified By :-"+skillLogObject.getModifiedBy()+" Modified Date:-"+skillLogObject.getModifiedDate()+" skill Name:-"+skillLogObject.getSkillsName()+" status :-"+skillLogObject.getStatus());
//			 session.save(skillLogObject);
//			 System.out.println("Master Log Table updated sucess fully");
//			 session.flush();
//			 session.close();
//			 
//		}catch(HibernateException ex){
//
//		        
//			 statusCode=0;
//			ex.printStackTrace();
//		}
//		return statusCode;
//	}
//	/*@Override
//	public Integer addKill(SkillVO skillVo) {
//		int statusCode = 0;
//		Session session=null;
//		
//           try{
//        	   
//			 session=sessionFactory.openSession();
//			 System.out.println(skillVo.getSkillsName());
//			 
//			 Skill skillObject = new Skill();
//			 
//			 skillObject.setSkillsName(skillVo.getSkillsName());
//			 skillObject.setCreatedBy(skillVo.getCreatedBy());
//			 skillObject.setCreatedDate(skillVo.getCreatedDate());
//			 skillObject.setModifiedBy(skillVo.getModifiedBy());
//			 skillObject.setModifiedDate(skillVo.getModifiedDate());
//			 
//			Serializable id=session.save(skillObject);
//			System.out.println(id);
//			
//			
//			    
//			 
//			 statusCode=1;
//		}catch(HibernateException ex){
//
//		        
//			 statusCode=0;
//			ex.printStackTrace();
//		}
//		return statusCode;
//	}
//*/
//	
//	@Override
//	public Skill getSkillByID(Short id) {
//		Skill skill = null;
//		Session session = null;
//		try {
//			session = sessionFactory.getCurrentSession();
//			Query query = session.getNamedQuery("Skill.findSkillById").setInteger("id", id);
//			   skill = (Skill) query.uniqueResult();
//			  
//		} catch (HibernateException ex) {
//			ex.printStackTrace();
//		} 
//		return skill;
//	}
//	
//	
//	// sadhu
//    @Override
//    public Integer updateSkill(SkillVO skillVo) {
//           int statusCode = 0;
//           Session session=null,session1=null;
//           System.out.println("Hi"+skillVo.getCreatedBy());
//           Skill skill = null;
//        try{
//                 
//                     session = sessionFactory.openSession();
//                     Query query=session.getNamedQuery("Skill.findSkillById").setInteger("id",skillVo.getId());
//                     skill = (Skill) query.uniqueResult();
//                    if(skill==null)
//                    {
//                         
//                    }
//                   
//                          Transaction tx=session.beginTransaction();
//                          skill.setSkillsName(skillVo.getSkillsName());
//                          skill.setCreatedBy(skillVo.getCreatedBy());
//                          skill.setModifiedBy(skillVo.getModifiedBy());
//                          skill.setModifiedDate(skillVo.getModifiedDate());
//                          /*session.merge(skill);
//                          tx.commit();*/
//                          
//                        
//                          String datetime=skillVo.getModifiedDate().toString();
//                          DateFormat formatter;
//                          String dateFormat = datetime.toString();
//                          formatter = new SimpleDateFormat("yyyy-MM-dd");
//                          Date date = (Date) formatter.parse(dateFormat);     
//                                                    
//                          
//                            String id=Integer.toString(skillVo.getId());
//                            SkillLog LogObject = new SkillLog();
//                              
//                            LogObject.setSkill_ID(id);
//                              
//                            LogObject.setAction("Update");
//                            LogObject.setModifiedBy(skillVo.getModifiedBy());
//                            LogObject.setModifiedDate(new Timestamp(date.getTime()));
//                                                        
//                            LogObject.setSkillsName(skillVo.getSkillsName());
//                            LogObject.setStatus("success");
//                              
//                             System.out.println("ID:-"+id+" Modified by:-"+skillVo.getModifiedBy()+" Modified Date :-"+new Timestamp(date.getTime())+" Skill name:-"+skillVo.getSkillsName());
//                             session.merge(skill);
//                             session.save(LogObject);
//                             
//                              tx.commit();
//                              System.out.println("Master Log Table updated sucess fully");
//                 
//                 
//                   
//                    statusCode=1;
//           }catch(HibernateException ex){
//
//                  
//                   statusCode=0;
//                  ex.printStackTrace();
//           } catch (ParseException e) {
//                  // TODO Auto-generated catch block
//                  e.printStackTrace();
//           }
//           return statusCode;
//    }
//	/*@Override
//	public Integer updateSkill(SkillVO skillVo) {
//		int statusCode = 0;
//		Session session=null;
//		System.out.println(skillVo.getCreatedBy());
//		Skill skill = null;
//           try{
//   		    	
//			   session = sessionFactory.openSession();
//			   Query query=session.getNamedQuery("Skill.findSkillById").setInteger("id",skillVo.getId());
//			   skill = (Skill) query.uniqueResult();
//			  if(skill==null)
//			  {
//				  
//			  }
//			  
//			        Transaction tx=session.beginTransaction();
//			        skill.setSkillsName(skillVo.getSkillsName());
//			        skill.setCreatedBy(skillVo.getCreatedBy());
//			        skill.setModifiedBy(skillVo.getModifiedBy());
//			        skill.setModifiedDate(skillVo.getModifiedDate());
//			        session.merge(skill);
//			        tx.commit();
//				
//			 
//			
//			 
//			 
//			  statusCode=1;
//		}catch(HibernateException ex){
//
//		        
//			 statusCode=0;
//			ex.printStackTrace();
//		}
//		return statusCode;
//	}
//*/
//
//	/*@Override
//	public Integer deleteSkill(Short id) {
//		System.out.println("Dao id"+id);
//		int statusCode = 0;
//		Session session=null;
//		
//		Skill skill=null;
//           try{
//   		    	
//			    session = sessionFactory.openSession();
//			    String hql = "delete from Skill where id =:id";
//		        Query query = session.createQuery(hql);
//		        query.setInteger("id",id);
//		        int rowCount = query.executeUpdate();
//		        System.out.println("Rows affected: " + rowCount);
//			 
//			
//			 
//			 
//			  statusCode=1;
//		}catch(HibernateException ex){
//
//		        
//			 statusCode=0;
//			 ex.printStackTrace();
//		}
//		return statusCode;
//	}*/
//	@Override
//	public Integer deleteSkill(String[] id) {
//
//      	short[] intArray = new short[id.length];
//      for (int i = 0; i < id.length; i++) {
//         String numberAsString = id[i];
//         intArray[i] = Short.parseShort(numberAsString);
//      }
//      
//      List<Short> list=new ArrayList<Short>();
//      for (Short short1 : intArray)
//       {
//		        list.add(short1);
//	   }
//      	int statusCode = 0;
//      	Session session=null;
//          /* try{
//   		    	
//			    session = sessionFactory.openSession();
//			    
//			    // test
//			    Skill sk=(Skill)session.load(Skill.class, id);
//			    System.out.println("sadhu:-"+sk.getCreatedBy());
//			    System.out.println("sadhu:-"+sk.getModifiedBy());
//			    System.out.println("sadhu:-"+sk.getModifiedDate());
//			    String skillId=Integer.toString(id);
//			     SkillLog skillLogObject = new SkillLog();
//				 skillLogObject.setSkill_ID(skillId);
//				 
//				 skillLogObject.setAction("delete");
//				 skillLogObject.setModifiedBy(sk.getModifiedBy());
//				 skillLogObject.setModifiedDate(Utilities.currentDate());
//				 skillLogObject.setSkillsName(sk.getSkillsName());
//				 skillLogObject.setStatus("sucess");
//				
//				 System.out.println("Inside Delete Log:-id "+skillLogObject.getSkill_ID()+" Action :-"+skillLogObject.getAction()+" Modified By :-"+skillLogObject.getModifiedBy()+" Modified Date:-"+skillLogObject.getModifiedDate()+" skill Name:-"+skillLogObject.getSkillsName()+" status :-"+skillLogObject.getStatus());
//				 session.save(skillLogObject);
//				 System.out.println("Master Log Table updated sucess fully");
//				//test
//			    String hql = "delete from Skill where id =:id";
//		        Query query = session.createQuery(hql);
//		        query.setInteger("id",id);
//		        int rowCount = query.executeUpdate();
//		        System.out.println("Rows affected: " + rowCount);
//		        session.flush();
//				session.close();
//		       		 
//			 
//			  statusCode=1;
//		}catch(HibernateException ex){
//
//		        
//			 statusCode=0;
//			 ex.printStackTrace();
//		}*/
//      	 try{
//		    	
//			    session = sessionFactory.openSession();
//			    String hql = "delete from Skill where id in(:ids)";
//		        Query query = session.createQuery(hql);
//		        query.setParameterList("ids", list);
//		        int rowCount = query.executeUpdate();
//		        System.out.println("Rows affected: " + rowCount);
//		        
//			  statusCode=1;
//		}catch(HibernateException ex){
//
//		        
//			 statusCode=0;
//			 ex.printStackTrace();
//		}
//		return statusCode;
//	}
//	
//	@Override
//	public Integer addSkillLog(SkillLogBean SkillLogBean) {
//		int statusCode = 0;
//		Session session=null;
//		
//           try{
//        	   
//			 session=sessionFactory.openSession();
//				 
//			 SkillLog skillObject = new SkillLog();
//			 skillObject.setSkill_ID(SkillLogBean.getSkill_ID());
//			 
//			 skillObject.setAction(SkillLogBean.getAction());
//			 skillObject.setModifiedBy(SkillLogBean.getModifiedBy());
//			 skillObject.setModifiedDate(SkillLogBean.getModifiedDate());
//			 skillObject.setSkillsName(SkillLogBean.getSkillsName());
//			 skillObject.setStatus(SkillLogBean.getStatus());
//			 
//			 
//			 System.out.println("Inside Log:-id "+SkillLogBean.getSkill_ID()+" Action :-"+SkillLogBean.getAction()+" Modified By :-"+SkillLogBean.getModifiedBy()+" Modified Date:-"+SkillLogBean.getModifiedDate()+" skill Name:-"+SkillLogBean.getSkillsName()+" status :-"+SkillLogBean.getStatus());
//			 session.save(skillObject);
//			 System.out.println("Log Table updated sucess fully");
//			
//			
//			    
//			 
//			 statusCode=1;
//		}catch(HibernateException ex){
//
//		        
//			 statusCode=0;
//			ex.printStackTrace();
//		}
//		return statusCode;
//	}
//
//}
