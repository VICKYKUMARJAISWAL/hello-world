package com.igate.DaoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.igate.Dao.SowDao;
import com.igate.model.Project;
import com.igate.model.Sow;
import com.igate.model.User;

public class SowDaoImpl implements SowDao {
	@Autowired
	 private SessionFactory sessionFactory; 
	@Override
	public List<Sow> getSowList() {
		Session session=sessionFactory.openSession();
		List sowlist = null;
		
		@SuppressWarnings("unchecked")
		
		Query q=session.createQuery("from Sow as s");
		sowlist = q.list();
		System.out.println(q.list());
		
		for(Object wl: sowlist){
			
			
			List<User> u = ((Sow)wl).getUsers();
			for(User u1:u){
				try{
					System.out.println(u1.getFname());	
				}catch(Exception e){
					System.out.println(e.getMessage());
				}
				
				System.out.println( "in for loop");
			}
			Project p = ((Sow)wl).getProj();
			System.out.println(p.getProjectName());
			
		}
		
		session.close();
		return sowlist;
	}

}
