package com.igate.DaoImpl;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.igate.Dao.TrainingDao;
import com.igate.beans.TrainingVO;
import com.igate.model.Skill;
import com.igate.model.Training;
import com.igate.model.TrainingAssign;
import com.igate.model.TrainingCategory;
import com.igate.model.TrainingMode;
import com.igate.model.TrainingStatus;
import com.igate.utilities.Utilities;

public class TrainingDaoImpl implements TrainingDao {

	private static final String PM = "PM";
	@Autowired
	 private SessionFactory sessionFactory;  
	 
	@Override
	public Integer addTraining(TrainingVO training) {
		int statusCode=1;
		try{
			
//			training_id SMALLINT  NOT NULL,
//			course_name VARCHAR(32)  NOT NULL,
//			registration_required BIT  NOT NULL,
//			content_type VARCHAR(32)  NOT NULL,
//			start_date DATE  NOT NULL,
//			end_date DATE  NOT NULL,
//			start_time TIME  NOT NULL,
//			end_time TIME  NOT NULL,
//			duration VARCHAR(32)  NOT NULL,
//			venue VARCHAR(32)  NOT NULL,
//			category_id SMALLINT  NOT NULL,
//			mode_id SMALLINT  NOT NULL,
//			status_id SMALLINT  NOT NULL,
//			remark VARCHAR(200)  NOT NULL,
//			created_date DATETIME  NOT NULL,
//			created_by CHAR(8)  NOT NULL
			System.out.println("*************************************************");
			System.out.println("add training statuscode in dao"+statusCode);
			System.out.println("***************************************************");
			Session session=sessionFactory.getCurrentSession();
			Training trainingObj = new Training();
			trainingObj.setCourseName(training.getCourseName());
			trainingObj.setRegistrationRequired(false);
			trainingObj.setContentType(training.getContentType());
			
			System.out.println("************start date"+training.getStartDate());
			System.out.println("****************end date"+training.getEndDate());
			
			trainingObj.setStartDate(training.getStartDate());
			trainingObj.setEndDate(training.getEndDate());
			//String satrtMeridiem =  training.getStartMeridiem();
			String startTime = training.getStartTime();
			String endTime = training.getEndTime();
			//String endMeridiem = training.getEndMeridiem();
			//startTime =  getTime(satrtMeridiem, startTime);
			//endTime = getTime(endMeridiem, endTime);
			trainingObj.setStartTime(startTime);
			//trainingObj.setStartTime(startTime);
			trainingObj.setEndTime(endTime);
			trainingObj.setDuration(training.getDuration());
			trainingObj.setVenue(training.getVenue());
			
			TrainingCategory tc = new TrainingCategory();
			
			System.out.println(training.getTrainingCatID());
			tc.setCategoryId(training.getTrainingCatID());
			trainingObj.setTrainingCategory(tc);
			
			
			TrainingMode tm = new TrainingMode();
			tm.setModeId(training.getTrainingModeId());
			trainingObj.setTrainingMode(tm);

			TrainingStatus ts = new TrainingStatus();
			ts.setStatusId((short)1);
			System.out.println("training status"+ts);
			trainingObj.setTrainingStatus(ts);
			System.out.println("training created by from controller"+training.getCreatedBy());
			trainingObj.setRemark(training.getRemark());
			trainingObj.setCreatedBy(training.getCreatedBy());
			trainingObj.setCreatedDate(training.getCreatedDate());
			//trainingObj.setCreatedDate(Utilities.currentDate());
			session.save(trainingObj);
			
			
			
		}catch(HibernateException ex){
			statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}

	public String getTime(String meridiem, String time) {
		Integer hour = Integer.parseInt(time);
		if(PM.equals(meridiem)) {
			hour = 12 + hour;
		}
		String hourInString = hour.toString()+":00:00";
		return hourInString;
	}

	@Override
	public List<Training> getAvilableTraining() {
		List<Training> trainingList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.getNamedQuery("Traing.findAllFromCurrentDate").setDate("startDate", new Date());
			
			System.out.println("****************************************************************************"+new Date());
			
			trainingList = query.list();
			/*for(Training t:trainingList){
				Hibernate.initialize(t.getTrainingCategory());
				Hibernate.initialize(t.getTrainingMode());
				Hibernate.initialize(t.getTrainingStatus());
			}*/
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}
		System.out.println("Test:****************************************************************************"+trainingList.size());
		return trainingList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Training getTrainingById(int id)
	{
		List<Training> trainingList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.getNamedQuery("Traing.findTrainingbyId").setInteger("trainingId", id);
			trainingList = query.list();
			System.out.println("trainingList"+trainingList);
		} catch (HibernateException ex) {
			ex.printStackTrace();
		} finally {
			session.close();
		}
		return trainingList.get(0);
	}
	
	@SuppressWarnings("unchecked")
	public List<String> getContentType()
	{
		
	    List<String> contenttypeList=null;
	    Session session=null;
	    try{
	    	
	    	session= sessionFactory.openSession();
	    	//Query query=session.getNamedQuery("Traing.getContentType");
	    	//String hql = "select content_type FROM Training"; 
	    	Query query= session.createQuery("select t.contentType FROM Training t");
	    	contenttypeList=query.list();
	    	System.out.println("*****************************");
	    	System.out.println("contenttypeList"+contenttypeList);
	    	System.out.println("*********************************");
	    }catch(HibernateException ex)
	    {
	    	ex.printStackTrace();
	    }finally{
	    	session.close();
	    }
	    return contenttypeList;
	}
	
	@SuppressWarnings("unchecked")
	public List<String> getCourseName()
	{
		
	    List<String> coursenameList=null;
	    Session session=null;
	    try{
	    	
	    	session= sessionFactory.openSession();
	    	//Query query=session.getNamedQuery("Traing.getContentType");
	    	//String hql = "select content_type FROM Training"; 
	    	Query query= session.createQuery("select t.courseName FROM Training t");
	    	coursenameList=query.list();
	    	System.out.println("*****************************");
	    	System.out.println(coursenameList);
	    	System.out.println("*********************************");
	    }catch(HibernateException ex)
	    {
	    	ex.printStackTrace();
	    }finally{
	    	session.close();
	    }
	    return coursenameList;
	}
	
	
	@Override
	public Integer updateTraining(TrainingVO training) {
		int statusCode=1;
		try{
			
			Training trainingObj = new Training();
			//Session session=sessionFactory.getCurrentSession();
		
			Session session= sessionFactory.openSession();
			
			 Query query=session.getNamedQuery("Traing.findTrainingbyId").setInteger("trainingId",training.getTrainingId());
			 trainingObj = (Training) query.uniqueResult();
		  
			 Transaction tx=session.beginTransaction();
			 
			trainingObj.setTrainingId(training.getTrainingId());
			trainingObj.setCourseName(training.getCourseName());
			trainingObj.setRegistrationRequired(false);
			trainingObj.setContentType(training.getContentType());
			
			System.out.println("****************************inside dao of update training*****************************");
			System.out.println("start date"+training.getStartDate());
			System.out.println("end date"+training.getEndDate());
			
			trainingObj.setStartDate(training.getStartDate());
			trainingObj.setEndDate(training.getEndDate());
			//String satrtMeridiem =  training.getStartMeridiem();
			String startTime = training.getStartTime();
			String endTime = training.getEndTime();
			//System.out.println("******* this is start time saving"+startTime);
			//System.out.println("******* this is end time saving"+endTime);
			//String endMeridiem = training.getEndMeridiem();
			//startTime =  getTime(satrtMeridiem, startTime);
			//endTime = getTime(endMeridiem, endTime);
			trainingObj.setStartTime(startTime);
			trainingObj.setEndTime(endTime);
			trainingObj.setDuration(training.getDuration());
			trainingObj.setVenue(training.getVenue());
			
			TrainingCategory tc = new TrainingCategory();
			tc.setCategoryId(training.getTrainingCatID());
			trainingObj.setTrainingCategory(tc);
			
			TrainingMode tm = new TrainingMode();
			tm.setModeId(training.getTrainingModeId());
			trainingObj.setTrainingMode(tm);

			TrainingStatus ts = new TrainingStatus();
			ts.setStatusId((short)1);
			trainingObj.setTrainingStatus(ts);
			
			trainingObj.setRemark(training.getRemark());
			trainingObj.setCreatedBy(training.getCreatedBy());
			trainingObj.setCreatedDate(training.getCreatedDate());
			//trainingObj.setCreatedDate(Utilities.currentDate());
			session.merge(trainingObj);
			tx.commit();
		    //session.update(trainingObj);
			
		}catch(HibernateException ex){
			statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getVenueNames() {
		
		 List<String> venuenameList=null;
		    Session session=null;
		    try{
		    	
		    	session= sessionFactory.openSession();
		    	//Query query=session.getNamedQuery("Traing.getContentType");
		    	//String hql = "select content_type FROM Training"; 
		    	Query query= session.createQuery("select t.venue FROM Training t");
		    	venuenameList=query.list();
		    	System.out.println("*****************************");
		    	System.out.println(venuenameList);
		    	System.out.println("*********************************");
		    }catch(HibernateException ex)
		    {
		    	ex.printStackTrace();
		    }finally{
		    	session.close();
		    }
		    return venuenameList;
	}

	@Override
	public Integer deleteTraining(String[] ids) {
		
		System.out.println("inside delete function");
       short[] shortarraytraining=new short[ids.length];
		
		int i=0;
	    for(String str:ids){
	        try {
	        	shortarraytraining[i]=Short.parseShort(str);
	            i++;
	        } catch (NumberFormatException e) {
	            throw new IllegalArgumentException("Not a number: " + str + " at index " + i,e);
	        }
	    }
	    
	    List<Short> list = new ArrayList<Short>();
	    for(Short intlist : shortarraytraining){
	    	
	    	list.add(intlist);
	    }
		int statusCode=0;
		System.out.println("daoimpl del");
		try{
			Session session=sessionFactory.openSession();
			
			Transaction tx=session.beginTransaction();
			
			Query query = session.createQuery("delete from Training where trainingId in(:ids)");
			query.setParameterList("ids", list);
			 
			int result = query.executeUpdate();
			if (result > 0) {
				System.out.println("Deleted " + result + " rows.");
			}
			
			tx.commit();
			statusCode=1;
		}catch(HibernateException ex){
			statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}

	@Override
	public Integer assignTraining(TrainingAssign t) {
		// TODO Auto-generated method stub
		
		System.out.println("inside daoimpl trainingassign");
		int statusCode=1;
		//Session session=sessionFactory.getCurrentSession();
		try
		{
			Session session= sessionFactory.openSession();
			
			Transaction tx = session.beginTransaction();
			session.save(t);
			tx.commit();
			
			
		}catch(HibernateException ex){
			statusCode=0;
			ex.printStackTrace();
		}
		
		return statusCode;
	}

}
