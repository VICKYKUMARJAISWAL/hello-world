/**
 * 
 */
package com.igate.DaoImpl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.Dao.UserDao;
import com.igate.model.InterviewStatusType;
import com.igate.model.User;
import com.igate.model.UserProfile;
import com.igate.model.UserStatus;
import com.igate.model.UserType;
import com.igate.utilities.PasswordEncryptor;
import com.igate.utilities.Utilities;

/**
 * @author rm832401
 *
 */
@Service
public class UserDaoImpl implements UserDao {
	
	 @Autowired
	 private SessionFactory sessionFactory;  
	 
	/* (non-Javadoc)
	 * @see com.igate.Dao.UserDao#addUser(com.igate.beans.User)
	 */
	@Override
	public Integer  addUser(User user){
		
		int statusCode=1;
		try{
			Session session=sessionFactory.getCurrentSession();
			/*UserProfile userProfile=new UserProfile();
			userProfile.setUserId(user.getUserId());*/
			String userId = user.getUserId();
			user.setCreatedDate(Utilities.currentDate());
			System.out.println(user.getUserType().getId());
			System.out.println("user data :   "+user);
			user.setPassword("password");
			user.setSysPwd("password");
			
			
			UserProfile userProfile=user.getUserProfile();
			userProfile.setExpSummary(" ");
			/*userProfile.setMonthsOfExp(new BigDecimal(0));*/
			/*userProfile.setHighestEducation(" ");*/
			userProfile.setModifiedDate(Utilities.currentDate());
			/*userProfile.setYearOfExp(new BigDecimal(0));*/
			userProfile.setUserStatus(getUserStatus((short)1));
			session.save(user);
			userProfile.setUser(user);
			session.save(userProfile);
		}catch(HibernateException ex){
			statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
		
	}
	
	@Override
	public Integer  updateUser(User user){
		
		int statusCode=1;
		Session session= null;
		try{
			session=sessionFactory.openSession();
			/*session=sessionFactory.getCurrentSession();*/
			Transaction trans = session.beginTransaction();
			String userId = user.getUserId();
			user.setCreatedDate(Utilities.currentDate());
			System.out.println("user data :   "+user);
			UserProfile userProfile=user.getUserProfile();
			/*userProfile.setUserId(user.getUserId());
			userProfile.setCreatedDate(Utilities.currentDate());
			userProfile.setExpSummary(" ");
			userProfile.setMonthsOfExp(new BigDecimal(0));
			userProfile.setHighestEducation(" ");
			userProfile.setModifiedDate(Utilities.currentDate());
			userProfile.setYearOfExp(new BigDecimal(0));
			userProfile.setUserStatus(getUserStatus((short)1));*/
			System.out.println("test   ");
			//String updateUser = "update User set fname=:"+user.getFname()+" AND lname=:"+user.getLname()+" And contactNo=:"+user.getContactNo()+" where userId=:"+user.getUserId();
			String updateUser = "update User set fname=:fn, mname=:mn, lname=:ln, contactNo=:cno, emailId=:em where userId =:userId";
			
			System.out.println("updateUser :  "+updateUser);
			Query updateQuery = session.createQuery(updateUser);
			updateQuery.setString("fn", user.getFname());
			updateQuery.setString("mn", user.getMname());
			updateQuery.setString("ln", user.getLname());
			updateQuery.setBigDecimal("cno", user.getContactNo());
			updateQuery.setString("em",user.getEmailId());
			updateQuery.setString("userId", user.getUserId());
			System.out.println(updateQuery.toString());
			statusCode = updateQuery.executeUpdate();
			
			String updateProfile = "update UserProfile set yearOfExp=:yoe, monthsOfExp=:moe, highestEducation=:he where userId=:userId";
//			String updateProfile = "update UserProfile set yearOfExp=:yoe where userId=:userId";
			System.out.println("updateProfile :  "+updateProfile);
			Query updateQueryProfile = session.createQuery(updateProfile);
			updateQueryProfile.setBigDecimal("yoe",userProfile.getYearOfExp());
			updateQueryProfile.setBigDecimal("moe",userProfile.getMonthsOfExp());
			updateQueryProfile.setString("he", userProfile.getHighestEducation());
			updateQueryProfile.setString("userId", userProfile.getUserId());
			System.out.println("UserId:"+userProfile.getUserId()+" And YoE:"+userProfile.getYearOfExp());
			
			System.out.println("updateQueryProfile:"+updateQueryProfile.toString());
			statusCode = updateQueryProfile.executeUpdate();
			//session.update(user);
			//userProfile.setUser(user);
			//session.update(user.getUserProfile());
			trans.commit();
		}catch(HibernateException ex){
			statusCode=0;
			ex.printStackTrace();
		} finally {
			session.close();
		}
		return statusCode;
		
	}
	
	@Override
	public Integer loginUser(User user){
		int statusCode;
		Session session=sessionFactory.getCurrentSession();
		String queryStr="from User as o where o.userId=?";
		Query query=session.createQuery(queryStr);
		query.setParameter(0, user.getUserId());
		User userData=(User)query.uniqueResult();
		PasswordEncryptor passwordEncryptor = new PasswordEncryptor();
		passwordEncryptor.decrypt(userData.getPassword());
		String password   = passwordEncryptor.getDecryptedString();
		if(userData==null){
			statusCode=1;
		}else{
			if(/*userData.getPassword()*/password.equals(user.getPassword())){
				statusCode=2;
			}else{
				statusCode=3;
			}
		}
		return statusCode;
	}
	
	@Override
	public UserType getUserType(short type){
		Session session=sessionFactory.getCurrentSession();
		String queryStr="from UserType as o where o.id=?";
		Query query=session.createQuery(queryStr);
		query.setParameter(0, type);
		UserType userType=(UserType)query.uniqueResult();
		userType.setId(userType.getId());
		return userType;
	}
	
	@Override
	public UserStatus getUserStatus(short status){
		Session session=sessionFactory.getCurrentSession();
		String queryStr="from UserStatus as o where o.id=?";
		Query query=session.createQuery(queryStr);
		query.setParameter(0, status);
		UserStatus userStatus=(UserStatus)query.uniqueResult();
		userStatus.setId(userStatus.getId());
		return userStatus;
		
	}
	
	@Override
	public UserProfile getUserProfileData(String userID){
		Session session=sessionFactory.getCurrentSession();
		String queryStr="from UserProfile as o where o.userId=?";
		Query query=session.createQuery(queryStr);
		query.setParameter(0, userID);
		UserProfile userProfile=(UserProfile)query.uniqueResult();
		return userProfile;
	}
	@Override
	public Integer updateUserProfileData(UserProfile userProfile){
		int statusCode=1;
		String userId=userProfile.getUserId();
		try{
		Session session=sessionFactory.getCurrentSession();
		UserProfile data=(UserProfile)session.get(UserProfile.class, userId);
		data.setExpSummary(userProfile.getExpSummary());
		data.setYearOfExp(userProfile.getYearOfExp());
		data.setHighestEducation(userProfile.getHighestEducation());
		data.setMonthsOfExp(userProfile.getMonthsOfExp());
		data.setModifiedDate(userProfile.getModifiedDate());
		}catch(HibernateException ex){
			statusCode=0;
			ex.printStackTrace();
		}
		return statusCode;
	}
	
	public Integer  updatePassword(User user){
		int statusCode=1;
		String userId=user.getUserId();
		try{
			Session session=sessionFactory.getCurrentSession();
			User data=(User)session.get(User.class, userId);
			PasswordEncryptor pe = new PasswordEncryptor();
			String frontEndPassword = user.getSysPwd(); 
			pe.encrypt(frontEndPassword);
			String encryptedPassword = pe.getEncryptedString();
			if(user.getSysPwd()!=null && encryptedPassword.equals(data.getPassword())){
				pe = new PasswordEncryptor();
				pe.encrypt(user.getPassword());
				data.setPassword(pe.getEncryptedString());
			}else{
				statusCode=2;
			}
			
			}catch(HibernateException ex){
				statusCode=0;
				ex.printStackTrace();
			}
			return statusCode;
	}
	public User getUserData(String userId){
		Session session=sessionFactory.getCurrentSession();
		User data=(User)session.get(User.class, userId);
		return data;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<UserStatus> getUserStatus() {
		return (List<UserStatus>) sessionFactory.getCurrentSession().createCriteria(UserStatus.class).list();
	}

	@Override
	public InterviewStatusType getInterviewStatusType(short id) {
		// TODO Auto-generated method stub
		return (InterviewStatusType) sessionFactory.getCurrentSession().get(InterviewStatusType.class, id);
	}

	@Override
	public List<User> getUserList() {
		Session session=sessionFactory.openSession();//getCurrentSession();
/*		Session session=sessionFactory.getCurrentSession();*/
		@SuppressWarnings("unchecked")
		/*List<User> userList = session.createCriteria(User.class).list();*/
		/*Query q=session.createQuery("select u, up from User as u"
				+ " inner join UserProfile as up on u.userId = up.userId");
		*/
		List<User> userList = new ArrayList<User>();
		/*Query q=session.createQuery("from User as u left outer join u.userProfile where u.active='yes'");*/
		Query q=session.createQuery("from User as u where u.active='yes'");
		List userlist = q.list();
		System.out.println(q.list());
		/*System.out.println(userList);*/
		/*
		for(Object wl: userList){
			System.out.println("User Id is "+ ((User)wl).getUserId());
			System.out.println("Skills of this user are: ");
			List slist = ((User)wl).getSkills();
			for(Object s:slist){
				s.toString();
			}
			
		}*/
		
		
		/*Iterator ite = userlist.iterator();
			    	while(ite.hasNext())
			    	{
			    	Object [] objects = (Object []) ite.next();
			    	User user = (User)objects[0];
			    	if(user.getUserProfile()==null){
			    		BigDecimal b = new BigDecimal(0);
			    		UserProfile up = new UserProfile();
			    		up.setMonthsOfExp(b);
			    		up.setYearOfExp(b);
			    		user.setUserProfile(up);
			    	}
			    	userList.add(user);
			    	if(user.getUserProfile()== null){
			    		
			    	}
			    	//UserProfile profile = (UserProfile)objects[1];
			    	System.out.println("UserID " + user.getUserId());
			    	System.out.println("UserID " + user.getUserProfile().getHighestEducation());
			    	}
*/
		
		session.close();
		/*return   userList;*/
		return userlist;
	}

	@Override
	public User getCompleteUserData(String userID) {
		System.out.println("Dao");
		Session session=sessionFactory.openSession();
		@SuppressWarnings("unchecked")
		
		User user = new User();
		/*from Cat cat,Owner owner where cat.OwnerId = owner.Id and owner.Name='Duke'"
		Query q=session.createQuery("from User as u inner join u.userProfile AND u.userId="+userID);*/
		/*Query q=session.createQuery("from User u, UserProfile up where u.userId=up.userId and u.userId="+"'"+userID+"'");*/
		System.out.println("UserID"+userID);
/*		Query q=session.createQuery("from User as u left outer join u.userProfile as UserProfile where u.userId="+"'"+userID+"'");*/
		Query q=session.createQuery("from User as u left outer join u.userProfile as UserProfile where u.userId="+"'"+userID+"'");
		List userlist = q.list();
		
		System.out.println("q: "+q);
		System.out.println("userlist: "+userlist);
		
		Iterator ite = userlist.iterator();
    	while(ite.hasNext())
    	{
    	Object [] objects = (Object []) ite.next();
    	user = (User)objects[0];
    	
    	//UserProfile profile = (UserProfile)objects[1];
    	System.out.println("UserIDD " + user.getUserId());
    	/*System.out.println("UserID " + user.getUserProfile().getHighestEducation());*/
    	}
    	session.close();
		return user;
	}

	@Override
	public Integer deleteUser(String[] stringArray) {
		/*short[] intArray = new short[stringArray.length];
	      for (int i = 0; i < stringArray.length; i++) {
	         String UserID = stringArray[i];
	         //intArray[i] = Short.parseShort(numberAsString);
	      }*/
	      /*
	      List<String> list=new ArrayList<Short>();
	      for (Short short1 : intArray)
	       {
			        list.add(short1);
		  }*/
	      int statusCode = 0;
	      Session session=null;
	      try{
	    	  
	    	  session = sessionFactory.openSession();
			  /*String hql = "delete from UserProfile where userId in(:ids)";
		      Query query = session.createQuery(hql);
		      query.setParameterList("ids", stringArray);
		      int rowCount = query.executeUpdate();
		      System.out.println("Rows affected in UserProfile: " + rowCount);
		      */
	    	  		      
			  String hql = "update User set active=:no where userId in (:userId)";
		      Query query1 = session.createQuery(hql);
		      query1.setParameter("no", "no");
		      query1.setParameterList("userId", stringArray);
		      int rowCount1 = query1.executeUpdate();
		      System.out.println("Rows affected in User: " + rowCount1);
		      
		      statusCode=1;
		}catch(HibernateException ex){
			statusCode=0;
			ex.printStackTrace();
		}
	    session.close();
		return statusCode;
		
		
	}
	
	
}
