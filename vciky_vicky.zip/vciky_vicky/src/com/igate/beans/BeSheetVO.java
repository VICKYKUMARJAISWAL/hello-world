package com.igate.beans;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the users database table.
 * 
 */
public class BeSheetVO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private BigDecimal projectId;

	private String projectName;

	private String sowName;

	private BigDecimal empId;

	private String empName;

	private String empLoc;

	private Timestamp gsStartDt;

	private Timestamp gSEndDt;
	
	private Long usdBillRate;
	
	private Long janBilling;
	
	private Long febBilling;
	
	private Long marBilling;
	
	private Long aprBilling;
	
	private Long mayBilling;
	
	private Long junBilling;
	
	private Long julBilling;
	
	private Long augBilling;
	
	private Long sepBilling;
	
	private Long octBilling;
	
	private Long novBilling;
	
	private Long decBilling;
	
	public BigDecimal getProjectId() {
		return projectId;
	}

	public void setProjectId(BigDecimal projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getSowName() {
		return sowName;
	}

	public void setSowName(String sowName) {
		this.sowName = sowName;
	}

	public BigDecimal getEmpId() {
		return empId;
	}

	public void setEmpId(BigDecimal empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpLoc() {
		return empLoc;
	}

	public void setEmpLoc(String empLoc) {
		this.empLoc = empLoc;
	}

	public Timestamp getGsStartDt() {
		return gsStartDt;
	}

	public void setGsStartDt(Timestamp gsStartDt) {
		this.gsStartDt = gsStartDt;
	}

	public Timestamp getgSEndDt() {
		return gSEndDt;
	}

	public void setgSEndDt(Timestamp gSEndDt) {
		this.gSEndDt = gSEndDt;
	}

	public Long getUsdBillRate() {
		return usdBillRate;
	}

	public void setUsdBillRate(Long usdBillRate) {
		this.usdBillRate = usdBillRate;
	}

	public Long getJanBilling() {
		return janBilling;
	}

	public void setJanBilling(Long janBilling) {
		this.janBilling = janBilling;
	}

	public Long getFebBilling() {
		return febBilling;
	}

	public void setFebBilling(Long febBilling) {
		this.febBilling = febBilling;
	}

	public Long getMarBilling() {
		return marBilling;
	}

	public void setMarBilling(Long marBilling) {
		this.marBilling = marBilling;
	}

	public Long getAprBilling() {
		return aprBilling;
	}

	public void setAprBilling(Long aprBilling) {
		this.aprBilling = aprBilling;
	}

	public Long getMayBilling() {
		return mayBilling;
	}

	public void setMayBilling(Long mayBilling) {
		this.mayBilling = mayBilling;
	}

	public Long getJunBilling() {
		return junBilling;
	}

	public void setJunBilling(Long junBilling) {
		this.junBilling = junBilling;
	}

	public Long getJulBilling() {
		return julBilling;
	}

	public void setJulBilling(Long julBilling) {
		this.julBilling = julBilling;
	}

	public Long getAugBilling() {
		return augBilling;
	}

	public void setAugBilling(Long augBilling) {
		this.augBilling = augBilling;
	}

	public Long getSepBilling() {
		return sepBilling;
	}

	public void setSepBilling(Long sepBilling) {
		this.sepBilling = sepBilling;
	}

	public Long getOctBilling() {
		return octBilling;
	}

	public void setOctBilling(Long octBilling) {
		this.octBilling = octBilling;
	}

	public Long getNovBilling() {
		return novBilling;
	}

	public void setNovBilling(Long novBilling) {
		this.novBilling = novBilling;
	}

	public Long getDecBilling() {
		return decBilling;
	}

	public void setDecBilling(Long decBilling) {
		this.decBilling = decBilling;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	@Override
	public String toString() {
		return "BESheet [projectId=" + projectId + ", projectName=" + projectName
				+ ", sowName=" + sowName + ", empId=" + empId + ", empName="
				+ empName + ", empLoc=" + empLoc + ", gsStartDt=" + gsStartDt
				+ ", gSEndDt=" + gSEndDt + ", usdBillRate=" + usdBillRate
				+ ", janBilling=" + janBilling + ", febBilling=" + febBilling
				+ ", marBilling=" + marBilling + ", aprBilling=" + aprBilling
				+ ", mayBilling=" + mayBilling + ", junBilling=" + junBilling
				+ ", julBilling=" + julBilling + ", augBilling=" + augBilling
				+ ", sepBilling=" + sepBilling + ", octBilling=" + octBilling
				+ ", novBilling=" + novBilling + ", decBilling=" + decBilling
				+ "]";
	}
	
}