package com.igate.beans;

import java.sql.Timestamp;


/**
 * The persistent class for the interview_status_type database table.
 * 
 */
public class InterviewStatusTypeVO {
	private short id;
	private String createdBy;
	private Timestamp createdDate;
	private String statusName;
	public short getId() {
		return id;
	}
	public void setId(short id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	

}