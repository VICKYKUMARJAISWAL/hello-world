package com.igate.beans;

import java.util.Date;

public class InterviewTrackerVO {

	private String resourceName;
	private String teamInterviewedFor;
	private Date dateOfInterview;

	private String clientManager;

	private String technologyStack;
	private String roundNumber;

	private String status;
	private String location;

	private String modeOfInterview;

	
	private String userId;
	
	
	
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public String getTeamInterviewedFor() {
		return teamInterviewedFor;
	}

	public void setTeamInterviewedFor(String teamInterviewedFor) {
		this.teamInterviewedFor = teamInterviewedFor;
	}

	public Date getDateOfInterview() {
		return dateOfInterview;
	}

	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	public String getClientManager() {
		return clientManager;
	}

	public void setClientManager(String clientManager) {
		this.clientManager = clientManager;
	}

	public String getTechnologyStack() {
		return technologyStack;
	}

	public void setTechnologyStack(String technologyStack) {
		this.technologyStack = technologyStack;
	}

	public String getRoundNumber() {
		return roundNumber;
	}

	public void setRoundNumber(String roundNumber) {
		this.roundNumber = roundNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getModeOfInterview() {
		return modeOfInterview;
	}

	public void setModeOfInterview(String modeOfInterview) {
		this.modeOfInterview = modeOfInterview;
	}

}
