package com.igate.beans;

import java.util.Date;
import java.util.List;

import javax.persistence.Id;

import com.igate.model.InterviewResourceStatus;
import com.igate.model.InterviewSkill;
import com.igate.model.Skill;
import com.igate.utilities.OpportunityStausenum;

public class InterviewVO {

	private int interviewId;

	private short businessUnitId;

	private String comments;

	private Date opportunityStartDate;

	private Date opportunityEndtartDate;

	private String opportunityStatus;
	
	//private List<OpportunityStausenum> opportunitystatus;

	private int locationId;

	private String name;

	private short projectId;

	private List<Integer> interviewSkills;

	//private List<Skill> interviewSkillList;

	private String createdby;

	public int getInterviewId() {
		return interviewId;
	}

	public void setInterviewId(int interviewId) {
		this.interviewId = interviewId;
	}

	public short getBusinessUnitId() {
		return businessUnitId;
	}

	public void setBusinessUnitId(short businessUnitId) {
		this.businessUnitId = businessUnitId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getOpportunityStartDate() {
		return opportunityStartDate;
	}

	public void setOpportunityStartDate(Date opportunityStartDate) {
		this.opportunityStartDate = opportunityStartDate;
	}

	public Date getOpportunityEndtartDate() {
		return opportunityEndtartDate;
	}

	public void setOpportunityEndtartDate(Date opportunityEndtartDate) {
		this.opportunityEndtartDate = opportunityEndtartDate;
	}

	public String getOpportunityStatus() {
		return opportunityStatus;
	}

	public void setOpportunityStatus(String opportunityStatus) {
		this.opportunityStatus = opportunityStatus;
	}

	
	public int getLocationId() {
		return locationId;
	}

//	public List<OpportunityStausenum> getOpportunitystatus() {
//		return opportunitystatus;
//	}
//
//	public void setOpportunitystatus(List<OpportunityStausenum> opportunitystatus) {
//		this.opportunitystatus = opportunitystatus;
//	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public short getProjectId() {
		return projectId;
	}

	public void setProjectId(short projectId) {
		this.projectId = projectId;
	}

	public List<Integer> getInterviewSkills() {
		return interviewSkills;
	}

	public void setInterviewSkills(List<Integer> interviewSkills) {
		this.interviewSkills = interviewSkills;
	}

//	public List<Skill> getInterviewSkillList() {
//		return interviewSkillList;
//	}
//
//	public void setInterviewSkillList(List<Skill> interviewSkillList) {
//		this.interviewSkillList = interviewSkillList;
//	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	@Override
	public String toString() {
		return "InterviewVO [interviewId=" + interviewId + ", businessUnitId="
				+ businessUnitId + ", comments=" + comments
				+ ", interviewDate=" + opportunityStartDate + ", locationId="
				+ locationId + ", name=" + name + ", projectName=" + projectId
				+ ", fname=" + ", resourceId=" + " " + "]";
	}

}
