package com.igate.beans;
/**
 * @author rm832401
 *
 */
public class Registration {
private String ConfPassword;
private String fName;
private String lName;
private int cNumber;
private String email;
private String oldPassword;
private String newPassword;
public Registration(){
	
}
public String getConfPassword() {
	return ConfPassword;
}
public void setConfPassword(String confPassword) {
	ConfPassword = confPassword;
}
public String getfName() {
	return fName;
}
public void setfName(String fName) {
	this.fName = fName;
}
public String getlName() {
	return lName;
}
public void setlName(String lName) {
	this.lName = lName;
}
public int getcNumber() {
	return cNumber;
}
public void setcNumber(int cNumber) {
	this.cNumber = cNumber;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getOldPassword() {
	return oldPassword;
}
public void setOldPassword(String oldPassword) {
	this.oldPassword = oldPassword;
}
public String getNewPassword() {
	return newPassword;
}
public void setNewPassword(String newPassword) {
	this.newPassword = newPassword;
}

}
