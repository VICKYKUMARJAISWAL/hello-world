package com.igate.beans;

import java.sql.Timestamp;

import javax.persistence.Column;

public class SkillLogBean {
	private static final long serialVersionUID = 1L;
	
	private String Skill_ID;

	private String action;
	
	private String modifiedBy;

	private Timestamp modifiedDate;	

	private String skillsName;
	
	private String status;

	public String getSkill_ID() {
		return Skill_ID;
	}

	public void setSkill_ID(String skill_ID) {
		Skill_ID = skill_ID;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getSkillsName() {
		return skillsName;
	}

	public void setSkillsName(String skillsName) {
		this.skillsName = skillsName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
