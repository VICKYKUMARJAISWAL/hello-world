/*package com.igate.beans;

import java.util.Date;

public class TrainingAssign {
	
	private int id;
	private String userId;
	private String trainingId;
	private String nominatedby;
	private Date nominationdate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(String trainingId) {
		this.trainingId = trainingId;
	}
	public String getNominatedby() {
		return nominatedby;
	}
	public void setNominatedby(String nominatedby) {
		this.nominatedby = nominatedby;
	}
	public Date getNominationdate() {
		return nominationdate;
	}
	public void setNominationdate(Date nominationdate) {
		this.nominationdate = nominationdate;
	}
	
	 
	
	

}
*/