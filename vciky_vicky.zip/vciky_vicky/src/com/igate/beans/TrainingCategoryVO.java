package com.igate.beans;

import java.sql.Timestamp;


/**
 * The persistent class for the training_category database table.
 * 
 */
public class TrainingCategoryVO {
	private static final long serialVersionUID = 1L;
	private int categoryId;
	private String categoryName;
	private String createdBy;
	private Timestamp createdDate;
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}