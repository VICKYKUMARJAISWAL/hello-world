package com.igate.beans;

import java.sql.Timestamp;


/**
 * The persistent class for the training_mode database table.
 * 
 */
public class TrainingModeVO {
	private static final long serialVersionUID = 1L;
	private int modeId;
	private String createdBy;
	private Timestamp createdDate;
	private String modeName;
	public int getModeId() {
		return modeId;
	}
	public void setModeId(int modeId) {
		this.modeId = modeId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getModeName() {
		return modeName;
	}
	public void setModeName(String modeName) {
		this.modeName = modeName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}