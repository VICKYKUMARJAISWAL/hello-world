package com.igate.beans;

import java.sql.Timestamp;


/**
 * The persistent class for the training_status database table.
 * 
 */
public class TrainingStatusVO {
	private static final long serialVersionUID = 1L;

	private int statusId;
	private String createdBy;
	private Timestamp createdDate;
	private String statusName;
	public int getStatusId() {
		return statusId;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}