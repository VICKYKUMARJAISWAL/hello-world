package com.igate.beans;

import java.util.Date;


/**
 * The persistent class for the training database table.
 * 
 */

public class TrainingVO {
	private static final long serialVersionUID = 1L;

	private short trainingId;
	private String contentType;
	private String courseName;
	private String createdBy;
	private Date createdDate;
	private String duration;
	private Date endDate;
	private String endTime;
	private boolean registrationRequired;
	private String remark;
	private Date startDate;
	private String startTime;
	private String venue;
	private int trainingCatID;
	private int trainingModeId;
	private int trainingStaId;
	//private String startMeridiem;
	//private String endMeridiem;
	//private String trainingCategory;
	
	
	public TrainingVO(){}
	
	public short getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(short trainingId) {
		this.trainingId = trainingId;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public boolean isRegistrationRequired() {
		return registrationRequired;
	}
	public void setRegistrationRequired(boolean registrationRequired) {
		this.registrationRequired = registrationRequired;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public int getTrainingCatID() {
		return trainingCatID;
	}
	public void setTrainingCatID(int trainingCatID) {
		this.trainingCatID = trainingCatID;
	}
	
	public int getTrainingModeId() {
		return trainingModeId;
	}
	public void setTrainingModeId(int trainingModeId) {
		this.trainingModeId = trainingModeId;
	}
	public int getTrainingStaId() {
		return trainingStaId;
	}
	public void setTrainingStaId(int trainingStaId) {
		this.trainingStaId = trainingStaId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	/*public String getTrainingCategory() {
		return trainingCategory;
	}
	public void setTrainingCategory(String trainingCategory) {
		this.trainingCategory = trainingCategory;
	}
	
	public String getStartMeridiem() {
		return startMeridiem;
	}
	public void setStartMeridiem(String startMeridiem) {
		this.startMeridiem = startMeridiem;
	}
	public String getEndMeridiem() {
		return endMeridiem;
	}
	public void setEndMeridiem(String endMeridiem) {
		this.endMeridiem = endMeridiem;
	}*/

	@Override
	public String toString() {
		return "TrainingVO [trainingId=" + trainingId + ", contentType="
				+ contentType + ", courseName=" + courseName + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + ", duration="
				+ duration + ", endDate=" + endDate + ", endTime=" + endTime
				+ ", registrationRequired=" + registrationRequired
				+ ", remark=" + remark + ", startDate=" + startDate
				+ ", startTime=" + startTime + ", venue=" + venue
				+ ", trainingCatID=" + trainingCatID + ", trainingModeId="
				+ trainingModeId + ", trainingStaId=" + trainingStaId + "]";
	}
	
	
	
}