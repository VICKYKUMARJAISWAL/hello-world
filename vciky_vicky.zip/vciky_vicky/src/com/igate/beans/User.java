/**
 * 
 */
package com.igate.beans;

/**
 * @author rm832401
 *
 */
public class User {
private String userId;
private String passWord;
private Registration registration;
public User(){
	registration=new Registration();
}
public Registration getRegistration() {
	return registration;
}
public void setRegistration(Registration registration) {
	this.registration = registration;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getPassWord() {
	return passWord;
}
public void setPassWord(String passWord) {
	this.passWord = passWord;
}



}
