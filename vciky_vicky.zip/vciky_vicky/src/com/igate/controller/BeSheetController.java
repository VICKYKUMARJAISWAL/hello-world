package com.igate.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.beans.BeSheetVO;
import com.igate.model.BeSheet;
import com.igate.service.BeSheetService;


@Controller
public class BeSheetController {
	
	@Autowired
	HttpSession httpSession;
	
	@Autowired
	BeSheetService beSheetService;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		//binder.registerCustomEditor(Timestamp.class, new SqlTimestampPropertyEditor("dd/MM/yyyy"));
		//SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		binder.registerCustomEditor(Date.class, "startDate", new CustomDateEditor(dateFormat, true));
		binder.registerCustomEditor(Date.class, "endDate", new CustomDateEditor(dateFormat, true));
	}
	
	
	
	final static Logger LOG = Logger.getLogger(BeSheetController.class);
	@RequestMapping(value="/loadBEsheet",method=RequestMethod.GET)
	public String l(Model mod,HttpServletRequest req){
				
		System.out.println("BE Sheet Controller");
		try{
			LOG.info("View BE Sheet");
			List<BeSheet> BESheetList=beSheetService.getBeSheetDetails(2016);
			System.out.println("BESheetlist:"+BESheetList.toString());
				
			mod.addAttribute("list",BESheetList);
		
		}catch(Exception e){
			LOG.error("Error in BE Sheet"+e.getMessage());
		}
		
		
		return "BESheet";
	}
}
