package com.igate.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.igate.beans.InterviewVO;
import com.igate.beans.TrainingVO;
import com.igate.model.InterviewDetail;
import com.igate.model.InterviewTracker;
import com.igate.model.Skill;
import com.igate.service.InterviewScheduleService;
//import com.igate.service.InterviewScheduleService;
import com.igate.service.MasterDataService;
import com.igate.utilities.OpportunityStausenum;
import com.igate.utilities.SqlTimestampPropertyEditor;
@Controller
public class InterviewScheduleController {
	 
	@InitBinder
	public void initBinder(WebDataBinder binder) {
			
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, "opportunityStartDate", new CustomDateEditor(dateFormat, true));
		binder.registerCustomEditor(Date.class, "opportunityEndtartDate", new CustomDateEditor(dateFormat, true));
		//binder.registerCustomEditor(requiredType, field, propertyEditor);
		
	}

	final static Logger LOG = Logger.getLogger(UserController.class);
	

	@Autowired
	HttpSession httpSession;
	
	@Autowired
	InterviewScheduleService scheduleService;
	@Autowired
	private MasterDataService masterDataService;
	
	@RequestMapping(value = "/loadScheduleInterviewData", method = RequestMethod.POST)
	public @ResponseBody
	InterviewVO loadScheduleInterviewData(Model mod, HttpServletRequest req) {
		System.out.println("inside loadScheduleInterviewData ");
		InterviewVO interviewVO = null;
		String userID = null;
		System.out.println("req.getSession().getAttribute(interviewId) "+req.getSession().getAttribute("interviewId"));
		if (req.getSession().getAttribute("interviewId") != null) {
			userID = req.getSession().getAttribute("userId").toString();
		}
		try {
			//interviewDetail = scheduleService.addScheduleDetails(interviewDetail);
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in UserController  ..addUser()..."
					+ ex.getMessage());
		}
		return interviewVO;
	}
	
	
	
	@RequestMapping(value="/addInterviewDetail",method=RequestMethod.POST)	                          
	public @ResponseBody String addInterviewDetails(@ModelAttribute("interviewVO") InterviewVO interviewVO,Model model,HttpServletRequest request)
	{
		
		System.out.println("from controller@@@@@@@@@@@@@@@@@@@@");
		String userId=(String)httpSession.getAttribute("userId");
		interviewVO.setCreatedby(userId);
		System.out.println(userId);
		System.out.println(interviewVO.getBusinessUnitId());
		//model.addAttribute("details",interviewVO);
		     String saveStatus=null;
		try{
			   
			    Integer saveStatusCode=scheduleService.addScheduleDetails(interviewVO);
			    
			if(saveStatusCode==1)
			{
				saveStatus="Data Saved Successfully";
			}else
			{
				saveStatus="Data not Saved Successfully!";
			}
		}
		catch(DataIntegrityViolationException ex){
			saveStatus="Already Scheduled !";
			ex.printStackTrace();
			LOG.error("Error in InterviewController  ....."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in InterviewController  ....."+ex.getMessage());
		}
		return saveStatus;
		//return "ViewInterviewDetails";
		
	}
	
	@RequestMapping(value="/getSkills",method=RequestMethod.GET)
	public String loadSkill(Model mod,HttpServletRequest req) throws JsonGenerationException, JsonMappingException, IOException{
		String viewInterview="GetSkills";
		String interviewID=req.getParameter("interviewId");
		Integer id = Integer.parseInt(interviewID);
		System.out.println(id);
		ObjectMapper mapper = new ObjectMapper();
		String skills= "";	
		try {
			LOG.info("Application Started");
			
		} catch (Exception e) {
			LOG.error("Error in InterviewSheduleController.....loadviewpage()..."+e.getMessage());
		}
		List<InterviewDetail> InterviewDetailsList=scheduleService.getAllAvilableInterviewsSkill();	
		
		List<Skill> skillset = scheduleService.getIntervSkillsById(id);
		skills = mapper.writeValueAsString(skillset);
		mod.addAttribute("InterviewDetail", InterviewDetailsList );
		mod.addAttribute("skills", skills );

		return viewInterview;
	}
	
	
	
	
	@RequestMapping(value="/loadinterview",method=RequestMethod.GET)
	public String loadInterview(Model mod,HttpServletRequest req){
		InterviewVO interviewVO=new InterviewVO();
		List<OpportunityStausenum> opportunitystatus=Arrays.asList(OpportunityStausenum.values());
		
		System.out.println("i am in loadinterview");
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in InterviewSheduleController.....loadProfileUpdate()..."+e.getMessage());
		}
		mod.addAttribute("interviewVO", interviewVO);	
		mod.addAttribute("skills", masterDataService.getAllSkills());
		mod.addAttribute("projects", masterDataService.getAllProjects());
		mod.addAttribute("location", masterDataService.getAllLocations());
		mod.addAttribute("bussinessunit", masterDataService.getAllBusinessunits());
		mod.addAttribute("status",opportunitystatus);

		return "AddInterview";
	}
	
	@RequestMapping(value="/loadViewPage",method=RequestMethod.GET)
	public String loadViewPage(Model mod,HttpServletRequest req){
		String viewInterview="ViewInterview";
		InterviewVO interviewVO=new InterviewVO();
		try {
			LOG.info("Application Started");
		} catch (Exception e) {
			LOG.error("Error in InterviewSheduleController.....loadviewpage()..."+e.getMessage());
		}
		List<InterviewDetail> interviewDetailList=scheduleService.getAllAvilableInterviews();
		//List<List<Object>> interviewDetailSkillList=scheduleService.getAllAvilableInterviewsSkill();
		System.out.println("List"+interviewDetailList);
		mod.addAttribute("interviewVO", interviewVO );
		mod.addAttribute("interviewDetailList", interviewDetailList);
		//mod.addAttribute("interviewDetailSkillList", interviewDetailSkillList);
	//	mod.addAttribute("skills", masterDataService.getAllSkills());
//		mod.addAttribute("Details", SkillDetail );
	//	mod.addAttribute("skills", skills );
		
		
		return viewInterview;
	}
	
	@RequestMapping(value="/loadUpdateInterview",method=RequestMethod.GET)
	public String loadUpdateInterview(Model mod,HttpServletRequest req){
		
		InterviewVO interviewVO=new InterviewVO();

		String interviewID=req.getParameter("interviewId");
		
		Integer id = Integer.parseInt(interviewID);
		
		InterviewDetail interviewdetail = scheduleService.getInterviewById(id);
		
		//interviewVO.setInterviewSkillList(interviewdetail.getSkills());
		interviewVO.setInterviewId(id);
		interviewVO.setName(interviewdetail.getName());
		interviewVO.setProjectId(interviewdetail.getProject().getId());
		interviewVO.setOpportunityStartDate(interviewdetail.getOpportunityStartDate());
		interviewVO.setOpportunityEndtartDate(interviewdetail.getOpportunityEndtartDate());
		interviewVO.setBusinessUnitId(interviewdetail.getBusinessUnit().getId());
		interviewVO.setLocationId(interviewdetail.getLocation().getId());
		interviewVO.setOpportunityStatus(interviewdetail.getOpportunityStatus());
		//interviewVO.setOpportunitystatus(interviewdetail.getOpportunitystatus());
		
		List<OpportunityStausenum> enumlist=Arrays.asList(OpportunityStausenum.values());
		//interviewVO.getInterviewSkills(interviewdetail.getSkills());
		
		/*interviewVO.setModifiedBy(interviewdetail.getModifiedBy());
		interviewVO.setModifiedDate(interviewdetail.getModifiedDate());*/
		
		System.out.println("controller updateInterview");
		try{
			LOG.info("Application Started");
			LOG.info("UpdateInterview");
		}catch(Exception e){
			LOG.error("Error in InterviewscheduleController"+e.getMessage());
		}
		
		//mod.addAttribute("status", enumlist);
		mod.addAttribute("skills",masterDataService.getAllSkills());
		mod.addAttribute("location", masterDataService.getAllLocations());
		mod.addAttribute("bussinessunit", masterDataService.getAllBusinessunits());
		mod.addAttribute("projects", masterDataService.getAllProjects());
		mod.addAttribute("interviewVO",interviewVO);
		mod.addAttribute("status",enumlist);
		
		
		return "updateInterview";
	}
	
@RequestMapping(value="/loadUpdateInterview",method=RequestMethod.POST)
	
	public @ResponseBody String updateInterview(@ModelAttribute("updateInterviewData")InterviewVO interviewVO,Model mod,HttpServletRequest req){
		
		String saveStatus=null;
		try{
			String userId=(String)httpSession.getAttribute("userId");
			interviewVO.setCreatedby(userId);
		System.out.println("update controller@@@@@@@@"+interviewVO.getOpportunityEndtartDate());
			Integer saveStatusCode=scheduleService.updateInterviewData(interviewVO);
			System.out.println("in final updation@@@@@@@@@@@@@@");
			if(saveStatusCode==1){
				saveStatus="Data Saved Successfully!";
			}else{
				saveStatus="Data not Saved Successfully!";
			}
		}catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in interviewscheduleController  ..UpdateInterview()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in InterviewScheduleController  ..addUser()..."+ex.getMessage());
		}
		return saveStatus;
	}
	

	@RequestMapping(value = "/deleteInterview", method = RequestMethod.POST)
	
	public @ResponseBody String deleteInterviewPage(Model mod, HttpServletRequest request) {
          
		InterviewVO interviewVO=new InterviewVO();
		
		System.out.println("in delete controll");
		//int id = Integer.parseInt(request.getParameter("id"));
		String strid = request.getParameter("ids");
		
		System.out.println("string id: "+strid);
		String[] strarray = strid.split(",");
		System.out.println("delete interview controller entered"+strarray.toString());
		String saveStatus = null;
		try {
			
			String userId=(String)httpSession.getAttribute("userId");
			interviewVO.setCreatedby(userId);
			
			Integer saveStatusCode = scheduleService.deleteInterviewData(strarray);
			 
			if (saveStatusCode == 1) {
				saveStatus ="Data Deleted Successfully!";
			} else {
				saveStatus ="Data not Deleted Successfully!";
			}
		} catch (DataIntegrityViolationException ex) {
			saveStatus = "Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in InterviewScheduleController  ..UpdateInterview()..."
					+ ex.getMessage());
		} catch (Exception ex) {
			saveStatus = "Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in InterviewScheduleController  ..UpdateInterview()..."
					+ ex.getMessage());
		}
		return saveStatus;
	}

	
	@RequestMapping(value="/getIntervSkillsById",method=RequestMethod.GET,produces = "application/json")
	public @ResponseBody String getIntervSkillsById(Model mod,HttpServletRequest req) throws JsonGenerationException, JsonMappingException, IOException{
		
		System.out.println("controller@@@@@@@@");
		InterviewVO interviewVO=new InterviewVO();
		
		String interviewID=req.getParameter("interviewId");
		
		Integer id = Integer.parseInt(interviewID);
		
		List<Skill> selectedSkill = scheduleService.getIntervSkillsById(id);
		
		OutputStream out = new ByteArrayOutputStream();
	     ObjectMapper mapper = new ObjectMapper();
	     mapper.writeValue(out, selectedSkill);
	     byte[] data = ((ByteArrayOutputStream) out).toByteArray();
	     String s=new String(data);
	     System.out.println(s);
		System.out.println("controller"+selectedSkill);
		try{
			LOG.info("Application Started");
			LOG.info("UpdateInterview");
		}catch(Exception e){
			LOG.error("Error in InterviewscheduleController"+e.getMessage());
		}
		
		return s;
	}
	
}
