package com.igate.controller;

import java.sql.Timestamp;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.igate.beans.InterviewTrackerVO;
import com.igate.service.InterviewTrackerService;
//import com.igate.service.InterviewScheduleService;
import com.igate.service.MasterDataService;
import com.igate.utilities.SqlTimestampPropertyEditor;

@Controller
public class InterviewTrackerController {
	@InitBinder
	public void initBinder(WebDataBinder binder) {

		binder.registerCustomEditor(Timestamp.class,new SqlTimestampPropertyEditor("dd/mm/yyyy"));

	}

	final static Logger LOG = Logger.getLogger(InterviewTrackerController.class);

	@Autowired
	private MasterDataService masterDataService;
	
	@Autowired
	InterviewTrackerService interviewTrackerService;
	
	

	@RequestMapping(value = "/loadInterviewTrackerPage", method = RequestMethod.GET)
	public String loadInterviewPage(Model model, HttpServletRequest req) {

		LOG.info("Entered in the loadInterviewPage");
		InterviewTrackerVO details = new InterviewTrackerVO();
		model.addAttribute("interviewTrackerData", details);
		model.addAttribute("locationList", masterDataService.getAllLocations());
		model.addAttribute("interviewStatus", masterDataService.getAllStatus());
		model.addAttribute("interviewModeList1",masterDataService.getAllModeOfInterviews());
		
		//get the project id		
		model.addAttribute("projectList",masterDataService.getAllProjects());
		//get the resource name : user id and name
		model.addAttribute("usersList",masterDataService.getAllUsers());
		
		LOG.info("Exit from the loadInterviewPage");
		return "interviewTracker";
	}

	@RequestMapping(value = "addInterViewDetials", method = RequestMethod.POST)
	@ResponseBody
	public String addInterviewDetials(@ModelAttribute("interviewTrackerData") InterviewTrackerVO interviewtracker,
			Model mod, HttpServletRequest req) {
		// set the data into the database and also return to the view object
		LOG.info("Entered in the addInterviewDetials");	
		
		String userID = null;	
		String UserId = (String)req.getSession().getAttribute("userId");
		
		if (req.getSession().getAttribute("userId") != null) {
			userID = req.getSession().getAttribute("userId").toString();
			interviewtracker.setUserId(userID);
		}
			
		
		String status = interviewTrackerService.addInterviewTrackerData(interviewtracker);
		LOG.info("Exit from the addInterviewDetials");
		return status;
		
		
	}

	

}
