package com.igate.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.igate.beans.LocationVO;
import com.igate.beans.LocationVOBeanLog;
import com.igate.model.Location;
import com.igate.service.LocationService;
import com.igate.service.MasterDataService;
import com.igate.utilities.Utilities;

@Controller
public class LocationController {

	final static Logger LOG = Logger.getLogger(LocationController.class);

	@Autowired
	HttpSession httpSession;
	@Autowired
	private MasterDataService masterDataService;

	@Autowired
	LocationService locationService;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		//binder.registerCustomEditor(Timestamp.class, new SqlTimestampPropertyEditor("dd/MM/yyyy"));
		//SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		binder.registerCustomEditor(Timestamp.class, "modifiedDate", new CustomDateEditor(dateFormat, true));
		binder.registerCustomEditor(Timestamp.class, "createdDate", new CustomDateEditor(dateFormat, true));
	}

	@RequestMapping(value = "/addViewEditLocation", method = RequestMethod.GET)
	public String loadViewRegisterLocations(Model mod, HttpServletRequest req) {

		LocationVO locationData = new LocationVO();

		try {
			LOG.info("Application Started");
		} catch (Exception e) {
			LOG.error("Error in LocationController" + e.getMessage());
		}

		mod.addAttribute("locationData", locationData);

		mod.addAttribute("locationlist", masterDataService.getAllLocations());

		return "addViewEditLocation";
	}

	@RequestMapping(value = "/loadAdminLocation", method = RequestMethod.GET)
	public String loadAdminLocation(Model mod, HttpServletRequest req) {
		
		LocationVO locationData = new LocationVO();
		try {
			LOG.info("Application Started");
		} catch (Exception e) {
			LOG.error("Error in LocationController" + e.getMessage());
		}

		mod.addAttribute("locationData", locationData);

		return "locationUser";
	}


	@RequestMapping(value = "addLocationDetials", method = RequestMethod.POST)
	@ResponseBody
	public String addLocationDetials(@ModelAttribute("locationData") LocationVO locationData, final RedirectAttributes redirectAttributes, Model mod, HttpServletRequest req) {
		String saveStatus = null;
		try {
			String userId = (String) httpSession.getAttribute("userId");
			locationData.setCreatedBy(userId);
			locationData.setCreatedDate(Utilities.currentDate());
			locationData.setModifiedBy(userId);
			locationData.setModifiedDate(Utilities.currentDate());
			Integer saveStatusCode = locationService.addLocationData(locationData);
			if (saveStatusCode == 1) {
				saveStatus = "Data Saved Successfully!";
				
			} else {
				saveStatus = "Data not Saved Successfully!";
			}
		} catch (DataIntegrityViolationException ex) {
			saveStatus = "Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in LocationController  ..addUser()..."
					+ ex.getMessage());
		} catch (Exception ex) {
			saveStatus = "Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in LocationController  ..addUser()..."
					+ ex.getMessage());
		}
		redirectAttributes.addFlashAttribute("message", "Data Saved Successfully!");
		return saveStatus;
		//return "redirect:/addViewEditLocation";

	}

	

	@RequestMapping(value = "/loadUpdateLocation", method = RequestMethod.GET)
	public String loadUpdateLocation(Model model, HttpServletRequest req) {
		

		int id = Integer.parseInt(req.getParameter("id"));
		System.out.println("locationId: "+id);
		Location location = locationService.getLocationById(id);
		
		LocationVO locationData = new LocationVO();
		
		locationData.setId(location.getId());
		locationData.setLocationName(location.getLocationName());
		
		locationData.setCreatedBy(location.getCreatedBy());
		
		locationData.setCreatedDate(location.getCreatedDate());
		locationData.setModifiedBy(location.getModifiedBy());
		
		locationData.setModifiedDate(location.getModifiedDate());
		
		model.addAttribute("updateLocationData",locationData);
		return "updateLocation";
	}
	
	
	@RequestMapping(value = "/updateLocationPage", method = RequestMethod.POST)
	@ResponseBody
	public String updateLocationPage(
			@ModelAttribute("updateLocationData") LocationVO locationvo,
			Model mod, HttpServletRequest request) {
          
		System.out.println("location controller entered");
		String saveStatus = null;
		try {
			 
			
			String userId=(String)httpSession.getAttribute("userId");
			System.out.println("locationId in update: "+userId);
		
			locationvo.setModifiedBy(userId);
			locationvo.setModifiedDate(Utilities.currentDate());
	

			Integer saveStatusCode = locationService.updateLocationData(locationvo);
			 
			if (saveStatusCode == 1) {
				saveStatus ="Data Saved Successfully!";
			} else {
				saveStatus ="Data not Saved Successfully!";
			}
		} catch (DataIntegrityViolationException ex) {
			saveStatus = "Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in LocationController  ..UpdateLocation()..."
					+ ex.getMessage());
		} catch (Exception ex) {
			saveStatus = "Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in LocationController  ..updateLocation()..."
					+ ex.getMessage());
		}
		return saveStatus;
	}
	@RequestMapping(value = "/deleteLocation", method = RequestMethod.POST)
	@ResponseBody
	public String deleteLocationPage(Model mod, HttpServletRequest request) {
          
		
		//int id = Integer.parseInt(request.getParameter("id"));
		String strid = request.getParameter("ids");
		System.out.println("string id: "+strid);
		String[] strarray = strid.split(",");
		
		String saveStatus = null;
		try {
			 
			
			Integer saveStatusCode = locationService.deleteLocationData(strarray);
			 
			if (saveStatusCode == 1) {
				saveStatus ="Data Deleted Successfully!";
			} else {
				saveStatus ="Data not Deleted Successfully!";
			}
		} catch (DataIntegrityViolationException ex) {
			saveStatus = "Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in LocationController  ..UpdateLocation()..."
					+ ex.getMessage());
		} catch (Exception ex) {
			saveStatus = "Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in LocationController  ..updateLocation()..."
					+ ex.getMessage());
		}
		return saveStatus;
	}
	
	
	// auther sadhu
    @RequestMapping(value = "/loadAdminLocationLog", method = RequestMethod.GET)
    public String loadViewLocationsLog(Model mod, HttpServletRequest req) {

        String id = req.getParameter("id");
        LocationVOBeanLog locationLogData=new LocationVOBeanLog();
   
        try {
                                    LOG.info("Application Started");
                    } catch (Exception e) {
                                    LOG.error("Error in LocationController" + e.getMessage());
                    }

                    mod.addAttribute("locationLogData", locationLogData);

                    mod.addAttribute("locationLogDataList", masterDataService.getAllLocationsLog(id));

                    return "addViewEditLocationLog";
                   
    }



    // view deleted logs
    @RequestMapping(value = "/loadAdminLocationDeletedLog", method = RequestMethod.GET)
    public String loadViewLocationsDeletedLog(Model mod, HttpServletRequest req) {

                      LocationVOBeanLog locationLogData=new LocationVOBeanLog();
   
        try {
                                    LOG.info("Application Started");
                    } catch (Exception e) {
                                    LOG.error("Error in LocationController" + e.getMessage());
                    }

                    mod.addAttribute("locationLogData", locationLogData);

                    mod.addAttribute("locationLogDataList", masterDataService.getAllLocationsDeletedLog());
   
                    return "addViewEditLocationDeletedLog";
    }

	
	
}