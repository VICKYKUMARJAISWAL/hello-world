package com.igate.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.beans.BusinessUnitVO;
import com.igate.beans.LocationVO;
import com.igate.beans.ProjectVO;
import com.igate.beans.SkillVO;
import com.igate.beans.TrainingCategoryVO;
import com.igate.beans.TrainingModeVO;
import com.igate.beans.TrainingStatusVO;
import com.igate.service.MasterDataService;

/**
 * @author rk833632
 *
 */
@Controller
public class MasterDataController {
	
	@Autowired
	HttpSession httpSession;

	final static Logger LOG = Logger.getLogger(MasterDataController.class);
	
	@Autowired
	MasterDataService masterDataService;
	
	@RequestMapping(value="/loadLocation",method=RequestMethod.GET)
	public String loadLocation(Model mod,HttpServletRequest req){
		LocationVO locationVO = new LocationVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in loadLocation.....loadLocation()..."+e.getMessage());
		}
		mod.addAttribute("locationVO", locationVO);	
		return "addLocation";
	}
	
	@RequestMapping(value="/loadProject",method=RequestMethod.GET)
	public String loadProject(Model mod,HttpServletRequest req){
		ProjectVO projectVO = new ProjectVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in loadProject.....loadProject()..."+e.getMessage());
		}
		mod.addAttribute("projectVO", projectVO);	
		mod.addAttribute("businessunits", masterDataService.getAllBusinessunits());
		return "addProject";
	}
	
	@RequestMapping(value="/loadBusinessUnit",method=RequestMethod.GET)
	public String loadBusinessUnit(Model mod,HttpServletRequest req){
		BusinessUnitVO businessUnitVO = new BusinessUnitVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in loadBusinessUnit.....loadBusinessUnit()..."+e.getMessage());
		}
		mod.addAttribute("businessUnitVO", businessUnitVO);	
		return "addBusinessUnit";
	}
	
	@RequestMapping(value="/loadSkill",method=RequestMethod.GET)
	public String loadSkill(Model mod,HttpServletRequest req){
		SkillVO skillVO = new SkillVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in loadskillVO.....loadskill()..."+e.getMessage());
		}
		mod.addAttribute("skillVO", skillVO);	
		return "addskill";
	}
	
	@RequestMapping(value="/loadTrainingCategory",method=RequestMethod.GET)
	public String loadTrainingCategory(Model mod,HttpServletRequest req){
		TrainingCategoryVO trainingCategoryVO = new TrainingCategoryVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in loadTrainingCategory.....loadsTrainingCategory()..."+e.getMessage());
		}
		mod.addAttribute("trainingCategoryVO", trainingCategoryVO);	
		return "addTrainingCategory";
	}
	
	@RequestMapping(value="/loadTrainingMode",method=RequestMethod.GET)
	public String loadTrainingMode(Model mod,HttpServletRequest req){
		TrainingModeVO trainingModeVO = new TrainingModeVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in loadTrainingMode.....loadTrainingMode()..."+e.getMessage());
		}
		mod.addAttribute("trainingModeVO", trainingModeVO);	
		return "addTrainingMode";
	}
	
	@RequestMapping(value="/loadTrainingStatus",method=RequestMethod.GET)
	public String loadTrainingStatus(Model mod,HttpServletRequest req){
		TrainingStatusVO trainingStatusVO = new TrainingStatusVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in loadTrainingStatus.....loadTrainingStatus()..."+e.getMessage());
		}
		mod.addAttribute("trainingStatusVO", trainingStatusVO);	
		return "addTrainingStatus";
	}
	
	
	
}
