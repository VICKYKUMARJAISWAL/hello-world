package com.igate.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.igate.beans.ProjectVO;
import com.igate.beans.SkillVO;
import com.igate.model.Project;
import com.igate.model.Skill;
import com.igate.service.MasterDataService;
import com.igate.service.ProjectService;
import com.igate.utilities.Utilities;
@Controller
public class ProjectController {
	final static Logger LOG = Logger.getLogger(ProjectController.class);
	@Autowired
	HttpSession httpSession;
	@Autowired
	private MasterDataService masterDataService;
	@Autowired
	private ProjectService projectService;
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		//binder.registerCustomEditor(Timestamp.class, new SqlTimestampPropertyEditor("dd/MM/yyyy"));
		//SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		binder.registerCustomEditor(Timestamp.class, "modifiedDate", new CustomDateEditor(dateFormat, true));
		binder.registerCustomEditor(Timestamp.class, "createdDate", new CustomDateEditor(dateFormat, true));
	}
	
	@RequestMapping(value="/loadAddViewEditProject",method=RequestMethod.GET)
	public  String addViewEditProject(Model mod,HttpServletRequest req){
		System.out.println("Project Con");
		ProjectVO projectData=new ProjectVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in ProjectController"+e.getMessage());
		}
		
		mod.addAttribute("projectData", projectData);	
		mod.addAttribute("projectList",masterDataService.getAllProjects());
		
		return "addViewEditProject";
}
	
	
	
	// Project Log Details
	
		@RequestMapping(value="/loadViewEditProjectLogs",method=RequestMethod.GET)
		public  String ViewProjectLogs(Model mod,HttpServletRequest req){
			
			System.out.println("Project Con Log");
			String id = req.getParameter("id");
			ProjectVO projectLogData=new ProjectVO();
			try{
				LOG.info("Application Started");
			}catch(Exception e){
				LOG.error("Error in ProjectController"+e.getMessage());
			}
			
			mod.addAttribute("projectLogData", projectLogData);	
			mod.addAttribute("projectLogDataList",masterDataService.getAllProjectsLog(id));
			
			return "addViewEditProjectLog";
	}
		
	// Eod
		
		
		// Project Deleted Log Details
		
			@RequestMapping(value="/loadViewEditProjectDeletedLogs",method=RequestMethod.GET)
			public  String ViewProjectDeletedLogs(Model mod,HttpServletRequest req){
				
				System.out.println("Project Con Deleted Log");
				
				ProjectVO projectDeletedLogData=new ProjectVO();
				try{
					LOG.info("Application Started");
				}catch(Exception e){
					LOG.error("Error in ProjectController"+e.getMessage());
				}
				
				mod.addAttribute("projectDeletedLogData", projectDeletedLogData);	
				mod.addAttribute("projectDeletedLogDataList",masterDataService.getAllProjectsDeletedLog());
				
				return "addViewEditProjectDeletedLog";
		}
			
		// Eod
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping(value="/loadProjectPage",method=RequestMethod.GET)
	public String loadSkillPage(Model mod,HttpServletRequest req){
		ProjectVO projectData=new ProjectVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in ProjectController"+e.getMessage());
		}
		
		mod.addAttribute("projectData", projectData);	
		
		
		return "addProject";
	}
	@RequestMapping(value="/addProject",method=RequestMethod.POST)
	public @ResponseBody String addProjectData(@ModelAttribute("projectData") ProjectVO projectData,Model mod,HttpServletRequest req){
		String saveStatus=null;
		try{
			
			System.out.println("ProjectController");
			
			String userId=(String)httpSession.getAttribute("userId");
			
			
			projectData.setCreatedBy(userId);
			projectData.setCreatedDate(Utilities.currentDate());
			projectData.setModifiedBy(userId);
			projectData.setModifiedDate(Utilities.currentDate());
			
			Integer saveStatusCode=projectService.addProject(projectData);
			
			System.out.println("Status"+saveStatusCode);
			
			if(saveStatusCode==1){
				 saveStatus="Project Saved Successfully!";
			}else if(saveStatusCode==0){
				 saveStatus="Project Not Saved Successfully!";
			}
			else
			{
				saveStatus="Project Already Exist";
			}
		}
		   catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in ProjectController  ..addProject()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Project Not Saved Successfully!";
			ex.printStackTrace();
			LOG.error("Error in ProjectController  ..addProject()..."+ex.getMessage());
		}
		return saveStatus;
	}
	@RequestMapping(value = "/editProject", method = RequestMethod.GET)
	public  String editProject(Model mod,HttpServletRequest request) {
		   short projectId = Short.parseShort(request.getParameter("id")); 
		   
		   Project project=   projectService.getProjectById(projectId);
		  
		   ProjectVO projectVo=new ProjectVO();
		   projectVo.setId(project.getId());
		   projectVo.setProjectName(project.getProjectName());
		   projectVo.setCreatedBy(project.getCreatedBy());
		   projectVo.setCreatedDate(project.getCreatedDate());
		   projectVo.setModifiedBy(project.getModifiedBy());
		   projectVo.setModifiedDate(project.getModifiedDate());
		   
	       mod.addAttribute("projectVo",projectVo);
	       return "updateProject";
	}
@RequestMapping(value="/updateProject",method=RequestMethod.POST)
	
	public @ResponseBody String updateProject(@ModelAttribute("projectVo") ProjectVO projectVo,Model mod,HttpServletRequest req){
		String saveStatus=null;
		try{
			  
			  String userId=(String)httpSession.getAttribute("userId");
			  projectVo.setModifiedBy(userId);
			  projectVo.setModifiedDate(Utilities.currentDate());
			
			Integer saveStatusCode=projectService.updateProject(projectVo);
			if(saveStatusCode==1){
				saveStatus="Project Updated Successfully!";
			}else{
				saveStatus="Project Not Updated Successfully!";
			}
		}catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Skill Not Updated Successfully!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
		}
		return saveStatus;
	}
@RequestMapping(value="/deleteProject",method=RequestMethod.POST)
	public @ResponseBody String deleteProject(Model mod,HttpServletRequest request){
		  String saveStatus=null;
		  System.out.println("hiiiiiiiiiiii");
		   String s= request.getParameter("id");
		   String[] stringArray = s.split(",");
	      
            try{
			  
			  Integer saveStatusCode=projectService.deleteProject(stringArray);
			
			if(saveStatusCode==1){
				saveStatus="Project Deleted Successfully!";
			}else{
				saveStatus="Project Not Deleted Successfully!";
			}
		}catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in ProjectController  ..deleteProject()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Skill Not Deleted Successfully!";
			ex.printStackTrace();
			LOG.error("Error in ProjectController  ..deleteProject()..."+ex.getMessage());
		}
		 
		
		
		 /* Short id=new Short(request.getParameter("id"));
		  System.out.println(id);*/
		/*try{
			  
			  Integer saveStatusCode=projectService.deleteProject(id);
			
			if(saveStatusCode==1){
				saveStatus="Project Deleted Successfully!";
			}else{
				saveStatus="Project Not Deleted Successfully!";
			}
		}catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in ProjectController  ..deleteProject()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Skill Not Deleted Successfully!";
			ex.printStackTrace();
			LOG.error("Error in ProjectController  ..deleteProject()..."+ex.getMessage());
		}
		*/
		return saveStatus;
	}
	
}
