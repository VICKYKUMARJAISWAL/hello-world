package com.igate.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.Dao.MasterDataDao;
import com.igate.beans.RegisterUserVo;

@Controller
public class RegisterUserController {
	final static Logger LOG = Logger.getLogger(RegisterUserController.class);
	/*@Autowired
	private MasterDataDao masterDataDao;*/
	@RequestMapping(value="/addViewEditUser",method=RequestMethod.GET)
	public String loadViewRegisterUsers(Model mod,HttpServletRequest req){
		RegisterUserVo usersData=new RegisterUserVo();
		List<RegisterUserVo> userlist=new ArrayList<RegisterUserVo>();
		usersData.setUserId("U101");
		usersData.setFirstName("Basava");
		usersData.setMiddleName("");
		usersData.setLastName("Raja");
		usersData.setRole("Developer");
		userlist.add(usersData);
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in RegisterUserController"+e.getMessage());
		}
		
		mod.addAttribute("usersData", usersData);	
		mod.addAttribute("userList",userlist);
		
		return "addViewEditUser";
	}
	@RequestMapping(value="/loadAdminUser",method=RequestMethod.GET)
	public String loadAdminUser(Model mod,HttpServletRequest req){
		RegisterUserVo usersData=new RegisterUserVo();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in RegisterUserController"+e.getMessage());
		}
		
		mod.addAttribute("usersData",usersData);	
		
		
		return "registeruser";
	}
	
}
