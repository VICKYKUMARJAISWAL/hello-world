package com.igate.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.igate.model.Sow;
import com.igate.service.SowService;


@Controller
public class SOWController{
	@Autowired
	SowService sowService;	
	@RequestMapping(value="/loadSOWpage",method=RequestMethod.GET)
	public String loadSOWList(Model mod,HttpServletRequest req){
		System.out.println("SOWController");
		try{
			List<Sow> listOfSow = sowService.getSowList();
			mod.addAttribute("listofsow",listOfSow);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return "SOWPage";
				
	}

}