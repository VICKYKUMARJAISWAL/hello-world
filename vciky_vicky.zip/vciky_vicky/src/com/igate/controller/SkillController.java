package com.igate.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.igate.beans.SkillLogBean;
import com.igate.beans.SkillVO;
import com.igate.beans.TrainingVO;
import com.igate.model.Skill;
import com.igate.service.MasterDataService;
import com.igate.service.SkillService;
import com.igate.utilities.Utilities;

@Controller
public class SkillController {
	final static Logger LOG = Logger.getLogger(RegisterUserController.class);
	@Autowired
	HttpSession httpSession;
	@Autowired
	private SkillService skillService;
	
	@Autowired
	private MasterDataService masterDataService;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		//binder.registerCustomEditor(Timestamp.class, new SqlTimestampPropertyEditor("dd/MM/yyyy"));
		//SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		binder.registerCustomEditor(Timestamp.class, "modifiedDate", new CustomDateEditor(dateFormat, true));
		binder.registerCustomEditor(Timestamp.class, "createdDate", new CustomDateEditor(dateFormat, true));
	}

	@RequestMapping(value="/addViewEditSkill",method=RequestMethod.GET)
	public String addViewEditSkill(Model mod,HttpServletRequest req){
		SkillVO skillData=new SkillVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in SkillController"+e.getMessage());
		}
		
		System.out.println("Skill Data"+masterDataService.getAllSkills());
		mod.addAttribute("skillData", skillData);	
		mod.addAttribute("skillList",masterDataService.getAllSkills());
		
		return "addViewEditSkill";
	}
	
	// Log Details
		@RequestMapping(value="/addViewEditSkillLog",method=RequestMethod.GET)
		public String addViewEditSkillLog(Model mod,HttpServletRequest req){
			String id = req.getParameter("id");
			SkillLogBean skillLogData=new SkillLogBean();
			
			try{
				LOG.info("Application Started");
			}catch(Exception e){
				LOG.error("Error in SkillController"+e.getMessage());
			}
			
			mod.addAttribute("skillLogData", skillLogData);	
			mod.addAttribute("skillLogDataList",masterDataService.getAllSkillsLog(id));
			
			return "addViewEditSkillLog";
		}
	
	//End
	
	
		
		
		// Deleted Log Details
				@RequestMapping(value="/addViewEditSkillDeletedLog",method=RequestMethod.GET)
				public String addViewEditSkillDeletedLog(Model mod,HttpServletRequest req){
					
					SkillLogBean skillDeletedLogData=new SkillLogBean();
					
					try{
						LOG.info("Application Started");
					}catch(Exception e){
						LOG.error("Error in SkillController"+e.getMessage());
					}
					
					mod.addAttribute("skillDeletedLogData", skillDeletedLogData);	
					mod.addAttribute("skillDeletedLogDataList",masterDataService.getAllSkillsDeletedLog());
					
					return "addViewEditSkillDeletedLog";
				}
			
			//End
		
	
	
	@RequestMapping(value="/loadSkillPage",method=RequestMethod.GET)
	public String loadSkillPage(Model mod,HttpServletRequest req){
		SkillVO skillData=new SkillVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in SkillController"+e.getMessage());
		}
		
		mod.addAttribute("skillData", skillData);	
		
		
		return "addSkill";
	}
	
	
	
	@RequestMapping(value="/addSkill",method=RequestMethod.POST)
	public @ResponseBody String addSkillData(@ModelAttribute("skillData") SkillVO skillData,@ModelAttribute("skillLogBean") SkillLogBean skillLogBean,Model mod,HttpServletRequest req){
		String saveStatus=null;
		try{
			/*
			System.out.println("SkillController");
			String userId=(String)httpSession.getAttribute("userId");
			
			skillData.setCreatedBy(userId);
			skillData.setCreatedDate(Utilities.currentDate());
			skillData.setModifiedBy(userId);
			skillData.setModifiedDate(Utilities.currentDate());
			
			
			Integer saveStatusCode=skillService.addSkill(skillData);
			
			System.out.println("Status"+saveStatusCode);
			if(saveStatusCode==1){
				 saveStatus="Skill Saved Successfully!";
			}else{
				 saveStatus="Skill Not Saved Successfully!";
			}*/
			System.out.println("SkillController");
			String userId=(String)httpSession.getAttribute("userId");
			
			skillData.setCreatedBy(userId);
			skillData.setCreatedDate(Utilities.currentDate());
			skillData.setModifiedBy(userId);
			skillData.setModifiedDate(Utilities.currentDate());
			// Log Data
			skillLogBean.setAction("Add");
			skillLogBean.setModifiedBy(userId);
			skillLogBean.setModifiedDate(Utilities.currentDate());
			skillLogBean.setSkillsName(skillData.getSkillsName());
			skillLogBean.setStatus("sucess");	
			Integer saveStatusCode=skillService.addSkill(skillData,skillLogBean);
						
			System.out.println("Status"+saveStatusCode);
			if(saveStatusCode >0){
				 saveStatus="Skill Saved Successfully!";
			}else{
				 saveStatus="Skill Not Saved Successfully!";
			}
			
		}
		   catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..addSkill()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Skill Not Saved Successfully!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..addSkill()..."+ex.getMessage());
		}
		return saveStatus;
	}
	
	
	
	
	/*@RequestMapping(value="/addSkill",method=RequestMethod.POST)
	public @ResponseBody String addSkillData(@ModelAttribute("skillData") SkillVO skillData,Model mod,HttpServletRequest req){
		String saveStatus=null;
		try{
			
			System.out.println("SkillController");
			String userId=(String)httpSession.getAttribute("userId");
			
			skillData.setCreatedBy(userId);
			skillData.setCreatedDate(Utilities.currentDate());
			skillData.setModifiedBy(userId);
			skillData.setModifiedDate(Utilities.currentDate());
			Integer saveStatusCode=skillService.addSkill(skillData);
			
			System.out.println("Status"+saveStatusCode);
			if(saveStatusCode==1){
				 saveStatus="Skill Saved Successfully!";
			}else{
				 saveStatus="Skill Not Saved Successfully!";
			}
		}
		   catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..addSkill()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Skill Not Saved Successfully!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..addSkill()..."+ex.getMessage());
		}
		return saveStatus;
	}*/
	@RequestMapping(value = "/editSkill", method = RequestMethod.GET)
	public  String editSkill(Model mod,HttpServletRequest request) {
		
		
		   short skillId = Short.parseShort(request.getParameter("id")); 
		   
		   System.out.println("**************inside editskill*********");
		   Skill skill=   skillService.getSkillById(skillId);
		   System.out.println("Edit:"+skill.getSkillsName());
		   SkillVO skillVo=new SkillVO();
		  
		   skillVo.setId(skill.getId());
		   skillVo.setSkillsName(skill.getSkillsName());
		   skillVo.setCreatedBy(skill.getCreatedBy());
		   skillVo.setCreatedDate(skill.getCreatedDate());
		   skillVo.setModifiedBy(skill.getModifiedBy());
		   skillVo.setModifiedDate(skill.getModifiedDate());
		   
	       mod.addAttribute("skillVo",skillVo);
	       return "updateSkill";
	}
	
	
	@RequestMapping(value="/updateSkill",method=RequestMethod.POST)
	
	public @ResponseBody String updateSkill(@ModelAttribute("skillVo") SkillVO skillVo,Model mod,HttpServletRequest req){
		String saveStatus=null;
		try{
			  System.out.println("**********Update skill controller*************"+skillVo.getId());
			  String userId=(String)httpSession.getAttribute("userId");
			  skillVo.setModifiedBy(userId);
			  skillVo.setModifiedDate(Utilities.currentDate());
			
			Integer saveStatusCode=skillService.updateSkill(skillVo);
			if(saveStatusCode==1){
				saveStatus="Skill Updated Successfully!";
			}else{
				saveStatus="Skill Not Updated Successfully!";
			}
		}catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Skill Not Updated Successfully!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
		}
		return saveStatus;
	}
    @RequestMapping(value="/deleteSkill",method=RequestMethod.POST)
	public @ResponseBody String deleteSkill(Model mod,HttpServletRequest request){
		  String saveStatus=null;
		  System.out.println("hiiiiiiiiiiii");
		 
		  String id=request.getParameter("ids");
		  String[] stringArray = id.split(",");
		try{
			  
			  Integer saveStatusCode=skillService.deleteSkill(stringArray);
			
			if(saveStatusCode==1){
				saveStatus="Skill Deleted Successfully!";
			}else{
				saveStatus="Skill Not Deleted Successfully!";
			}
		}catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Skill Not Deleted Successfully!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
		}
		
		return saveStatus;
	}
}




//package com.igate.controller;
//
//import java.sql.Timestamp;
//import java.text.SimpleDateFormat;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.apache.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.propertyeditors.CustomDateEditor;
//import org.springframework.dao.DataIntegrityViolationException;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.WebDataBinder;
//import org.springframework.web.bind.annotation.InitBinder;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.igate.beans.SkillLogBean;
//import com.igate.beans.SkillVO;
//import com.igate.beans.TrainingVO;
//import com.igate.model.Skill;
//import com.igate.service.MasterDataService;
//import com.igate.service.SkillService;
//import com.igate.utilities.Utilities;
//
//@Controller
//public class SkillController {
//	final static Logger LOG = Logger.getLogger(RegisterUserController.class);
//	@Autowired
//	HttpSession httpSession;
//	@Autowired
//	private SkillService skillService;
//	
//	@Autowired
//	private MasterDataService masterDataService;
//	
//	@InitBinder
//	public void initBinder(WebDataBinder binder) {
//		//binder.registerCustomEditor(Timestamp.class, new SqlTimestampPropertyEditor("dd/MM/yyyy"));
//		//SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
//		binder.registerCustomEditor(Timestamp.class, "modifiedDate", new CustomDateEditor(dateFormat, true));
//		binder.registerCustomEditor(Timestamp.class, "createdDate", new CustomDateEditor(dateFormat, true));
//	}
//
//	@RequestMapping(value="/addViewEditSkill",method=RequestMethod.GET)
//	public String addViewEditSkill(Model mod,HttpServletRequest req){
//		SkillVO skillData=new SkillVO();
//		try{
//			LOG.info("Application Started");
//		}catch(Exception e){
//			LOG.error("Error in SkillController"+e.getMessage());
//		}
//		
//		System.out.println("Skill Data"+masterDataService.getAllSkills());
//		mod.addAttribute("skillData", skillData);	
//		mod.addAttribute("skillList",masterDataService.getAllSkills());
//		
//		return "addViewEditSkill";
//	}
//	@RequestMapping(value="/loadSkillPage",method=RequestMethod.GET)
//	public String loadSkillPage(Model mod,HttpServletRequest req){
//		SkillVO skillData=new SkillVO();
//		try{
//			LOG.info("Application Started");
//		}catch(Exception e){
//			LOG.error("Error in SkillController"+e.getMessage());
//		}
//		
//		mod.addAttribute("skillData", skillData);	
//		
//		
//		return "addSkill";
//	}
//	
//	
//	
//	@RequestMapping(value="/addSkill",method=RequestMethod.POST)
//	public @ResponseBody String addSkillData(@ModelAttribute("skillData") SkillVO skillData,@ModelAttribute("skillLogBean") SkillLogBean skillLogBean,Model mod,HttpServletRequest req){
//		String saveStatus=null;
//		try{
//			/*
//			System.out.println("SkillController");
//			String userId=(String)httpSession.getAttribute("userId");
//			
//			skillData.setCreatedBy(userId);
//			skillData.setCreatedDate(Utilities.currentDate());
//			skillData.setModifiedBy(userId);
//			skillData.setModifiedDate(Utilities.currentDate());
//			
//			
//			Integer saveStatusCode=skillService.addSkill(skillData);
//			
//			System.out.println("Status"+saveStatusCode);
//			if(saveStatusCode==1){
//				 saveStatus="Skill Saved Successfully!";
//			}else{
//				 saveStatus="Skill Not Saved Successfully!";
//			}*/
//			System.out.println("SkillController");
//			String userId=(String)httpSession.getAttribute("userId");
//			
//			skillData.setCreatedBy(userId);
//			skillData.setCreatedDate(Utilities.currentDate());
//			skillData.setModifiedBy(userId);
//			skillData.setModifiedDate(Utilities.currentDate());
//			// Log Data
//			skillLogBean.setAction("Add");
//			skillLogBean.setModifiedBy(userId);
//			skillLogBean.setModifiedDate(Utilities.currentDate());
//			skillLogBean.setSkillsName(skillData.getSkillsName());
//			skillLogBean.setStatus("sucess");	
//			Integer saveStatusCode=skillService.addSkill(skillData,skillLogBean);
//						
//			System.out.println("Status"+saveStatusCode);
//			if(saveStatusCode >0){
//				 saveStatus="Skill Saved Successfully!";
//			}else{
//				 saveStatus="Skill Not Saved Successfully!";
//			}
//			
//		}
//		   catch(DataIntegrityViolationException ex){
//			saveStatus="Plese try again.....Something went wrong!!!";
//			ex.printStackTrace();
//			LOG.error("Error in SkillController  ..addSkill()..."+ex.getMessage());
//		}
//		catch(Exception ex){
//			saveStatus="Skill Not Saved Successfully!";
//			ex.printStackTrace();
//			LOG.error("Error in SkillController  ..addSkill()..."+ex.getMessage());
//		}
//		return saveStatus;
//	}
//	
//	
//	
//	
//	/*@RequestMapping(value="/addSkill",method=RequestMethod.POST)
//	public @ResponseBody String addSkillData(@ModelAttribute("skillData") SkillVO skillData,Model mod,HttpServletRequest req){
//		String saveStatus=null;
//		try{
//			
//			System.out.println("SkillController");
//			String userId=(String)httpSession.getAttribute("userId");
//			
//			skillData.setCreatedBy(userId);
//			skillData.setCreatedDate(Utilities.currentDate());
//			skillData.setModifiedBy(userId);
//			skillData.setModifiedDate(Utilities.currentDate());
//			Integer saveStatusCode=skillService.addSkill(skillData);
//			
//			System.out.println("Status"+saveStatusCode);
//			if(saveStatusCode==1){
//				 saveStatus="Skill Saved Successfully!";
//			}else{
//				 saveStatus="Skill Not Saved Successfully!";
//			}
//		}
//		   catch(DataIntegrityViolationException ex){
//			saveStatus="Plese try again.....Something went wrong!!!";
//			ex.printStackTrace();
//			LOG.error("Error in SkillController  ..addSkill()..."+ex.getMessage());
//		}
//		catch(Exception ex){
//			saveStatus="Skill Not Saved Successfully!";
//			ex.printStackTrace();
//			LOG.error("Error in SkillController  ..addSkill()..."+ex.getMessage());
//		}
//		return saveStatus;
//	}*/
//	@RequestMapping(value = "/editSkill", method = RequestMethod.GET)
//	public  String editSkill(Model mod,HttpServletRequest request) {
//		
//		
//		   short skillId = Short.parseShort(request.getParameter("id")); 
//		   
//		   System.out.println("**************inside editskill*********");
//		   Skill skill=   skillService.getSkillById(skillId);
//		   System.out.println("Edit:"+skill.getSkillsName());
//		   SkillVO skillVo=new SkillVO();
//		  
//		   skillVo.setId(skill.getId());
//		   skillVo.setSkillsName(skill.getSkillsName());
//		   skillVo.setCreatedBy(skill.getCreatedBy());
//		   skillVo.setCreatedDate(skill.getCreatedDate());
//		   skillVo.setModifiedBy(skill.getModifiedBy());
//		   skillVo.setModifiedDate(skill.getModifiedDate());
//		   
//	       mod.addAttribute("skillVo",skillVo);
//	       return "updateSkill";
//	}
//	
//	
//	@RequestMapping(value="/updateSkill",method=RequestMethod.POST)
//	
//	public @ResponseBody String updateSkill(@ModelAttribute("skillVo") SkillVO skillVo,Model mod,HttpServletRequest req){
//		String saveStatus=null;
//		try{
//			  System.out.println("**********Update skill controller*************"+skillVo.getId());
//			  String userId=(String)httpSession.getAttribute("userId");
//			  skillVo.setModifiedBy(userId);
//			  skillVo.setModifiedDate(Utilities.currentDate());
//			
//			Integer saveStatusCode=skillService.updateSkill(skillVo);
//			if(saveStatusCode==1){
//				saveStatus="Skill Updated Successfully!";
//			}else{
//				saveStatus="Skill Not Updated Successfully!";
//			}
//		}catch(DataIntegrityViolationException ex){
//			saveStatus="Plese try again.....Something went wrong!!!";
//			ex.printStackTrace();
//			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
//		}
//		catch(Exception ex){
//			saveStatus="Skill Not Updated Successfully!";
//			ex.printStackTrace();
//			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
//		}
//		return saveStatus;
//	}
//    @RequestMapping(value="/deleteSkill",method=RequestMethod.POST)
//	public @ResponseBody String deleteSkill(Model mod,HttpServletRequest request){
//		  String saveStatus=null;
//		  System.out.println("hiiiiiiiiiiii");
//		 
//		  String id=request.getParameter("ids");
//		  String[] stringArray = id.split(",");
//		try{
//			  
//			  Integer saveStatusCode=skillService.deleteSkill(stringArray);
//			
//			if(saveStatusCode==1){
//				saveStatus="Skill Deleted Successfully!";
//			}else{
//				saveStatus="Skill Not Deleted Successfully!";
//			}
//		}catch(DataIntegrityViolationException ex){
//			saveStatus="Plese try again.....Something went wrong!!!";
//			ex.printStackTrace();
//			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
//		}
//		catch(Exception ex){
//			saveStatus="Skill Not Deleted Successfully!";
//			ex.printStackTrace();
//			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
//		}
//		
//		return saveStatus;
//	}
//}
