package com.igate.controller;


import java.sql.Time;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;



import com.igate.beans.TrainingVO;
import com.igate.model.Training;
import com.igate.model.TrainingAssign;
import com.igate.model.User;
import com.igate.service.MasterDataService;
import com.igate.service.TrainingService;
import com.igate.service.UserService;
import com.igate.utilities.Utilities;

/**
 * @author rm832401
 *
 */
@Controller
public class TrainingController {
	
	@Autowired
	HttpSession httpSession;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		//binder.registerCustomEditor(Timestamp.class, new SqlTimestampPropertyEditor("dd/MM/yyyy"));
		//SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		binder.registerCustomEditor(Date.class, "startDate", new CustomDateEditor(dateFormat, true));
		binder.registerCustomEditor(Date.class, "endDate", new CustomDateEditor(dateFormat, true));
	}

	final static Logger LOG = Logger.getLogger(TrainingController.class);
	@Autowired
	TrainingService trainingService;
	
	@Autowired
	MasterDataService masterDataService;
	
	@Autowired
	UserService userService;
	
	private static final String PM = "PM";
	
	@RequestMapping(value="/loadTraining",method=RequestMethod.GET)
	public String loadTraining(Model mod,HttpServletRequest req){
		TrainingVO trainingData=new TrainingVO();
		System.out.println("this is from controller@@@@@@@@@@@@@@@@");
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in TrainingController.....loadProfileUpdate()..."+e.getMessage());
		}
		mod.addAttribute("trainingdata", trainingData);	
		mod.addAttribute("categories", masterDataService.getAllTrainingCategories());
		mod.addAttribute("modes", masterDataService.getAllTrainingModes());
		mod.addAttribute("contenttypelist",trainingService.getContentType());
		mod.addAttribute("coursenamelist", trainingService.getCourseName());
	
		return "addTraining";
	}
	
	
	
	
	@RequestMapping(value="/addTraining123",method=RequestMethod.POST)
	@ResponseBody
	public String addTraining(@ModelAttribute("trainingdata") TrainingVO trainingData,Model mod,HttpServletRequest req){
		String saveStatus=null;
		try{
			System.out.println("###########@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			System.out.println(" i am in saving controller");
			String userId=(String)httpSession.getAttribute("userId");
			System.out.println(userId);
			trainingData.setCreatedBy(userId);
			trainingData.setCreatedDate(Utilities.currentDate());
			System.out.println("****************************************my venue"+trainingData.getVenue());
			System.out.println("****************************************my data"+trainingData.toString());
			System.out.println("****************************************start date"+trainingData.getStartDate());
			System.out.println("****************************************end date"+trainingData.getEndDate());
			Integer saveStatusCode=trainingService.addTraining(trainingData);
			System.out.println("status in controllewr:"+saveStatusCode);
			if(saveStatusCode==1){
				saveStatus="Data Saved Successfully!";
			}else{
				saveStatus="Data not Saved Successfully!";
			}
		}catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in TrainingController  ..addUser()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in TrainingController  ..addUser()..."+ex.getMessage());
		}
		return saveStatus;
	}
	
	@RequestMapping(value="/loadTrainingCalendar",method=RequestMethod.GET)
	public String loadTrainingCalendar(Model mod,HttpServletRequest req){
		TrainingVO trainingData=new TrainingVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in TrainingController.....loadProfileUpdate()..."+e.getMessage());
		}
		List<Training> trainingList = trainingService.getAllAvilableTraining();
		mod.addAttribute("trainingdata", trainingData);	
		mod.addAttribute("trainingList", trainingList);
		return "viewTrainingCalendar";
	}
	
	@RequestMapping(value="/viewTraining",method=RequestMethod.GET)
	public String viewTrainingCalendar(Model mod,HttpServletRequest req){
		System.out.println("---------------------------------------------------");
		System.out.println("in controller of view training");
		TrainingVO trainingData=new TrainingVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in TrainingController.....loadProfileUpdate()..."+e.getMessage());
		}
		List<Training> trainingList = trainingService.getAllAvilableTraining();
		mod.addAttribute("trainingdata", trainingData);	
		mod.addAttribute("trainingList", trainingList);
		return "ViewTraining";
	}
	
	/*@RequestMapping(value="/loadTrainingCalendar",method=RequestMethod.GET)
	public String loadTrainingCalendar(Model mod,HttpServletRequest req) throws JsonGenerationException, JsonMappingException, IOException{
		TrainingVO trainingData=new TrainingVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in TrainingController.....loadProfileUpdate()..."+e.getMessage());
		}
		List<Training> trainingList = trainingService.getAllAvilableTraining();
		mod.addAttribute("trainingdata", trainingData);	
		mod.addAttribute("trainingList", trainingList);
		ObjectMapper mapper = new ObjectMapper();
		String jsonTrainingListString = mapper.writeValueAsString(trainingList);
		mod.addAttribute("trainingListJSON", jsonTrainingListString);
		String jsonTrainingVOString = mapper.writeValueAsString(trainingData);
		mod.addAttribute("trainingVOJSON", jsonTrainingVOString);
		System.out.println(jsonTrainingVOString);
		System.out.println("******************************************************************************");
		System.out.println(jsonTrainingListString);
		return "viewTrainingCalendar";
	}*/
	
	@RequestMapping(value="/addViewEditTraining",method=RequestMethod.GET)
	public String loadViewTrainingCalendar(Model mod,HttpServletRequest req){
		TrainingVO trainingData=new TrainingVO();
		try{
			LOG.info("Application Started");
		}catch(Exception e){
			LOG.error("Error in TrainingController.....loadProfileUpdate()..."+e.getMessage());
		}
		List<Training> trainingList = trainingService.getAllAvilableTraining();
		mod.addAttribute("trainingdata", trainingData);	
		mod.addAttribute("trainingList", trainingList);
		mod.addAttribute("categories", masterDataService.getAllTrainingCategories());
		mod.addAttribute("modes", masterDataService.getAllTrainingModes());
		return "addViewEditTraining";
	}
	
	@RequestMapping(value="/loadUsersinpopup",method=RequestMethod.GET)
	public String loadUserList(Model mod,HttpServletRequest req){
		User user = new User();
		mod.addAttribute("user", user);	
		try {
			List<User>  listuser = userService.getUserList();
			mod.addAttribute("userList", userService.getUserList());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "displayuserlistinpopup";				
	}
	
	
	@RequestMapping(value = "/editTraining", method = RequestMethod.GET)
	public ModelAndView editUser(HttpServletRequest request) {
		
		int trainingId = Integer.parseInt(request.getParameter("id")); 
		
		Training training = trainingService.getTrainingById(trainingId);
		TrainingVO trainingObj = new TrainingVO();
		
		
		trainingObj.setTrainingId(training.getTrainingId());
		trainingObj.setCourseName(training.getCourseName());
		trainingObj.setRegistrationRequired(false);
		trainingObj.setContentType(training.getContentType());
		trainingObj.setStartDate(training.getStartDate());
		trainingObj.setEndDate(training.getEndDate());
		trainingObj.setTrainingCatID(training.getTrainingCategory().getCategoryId());
		trainingObj.setTrainingModeId(training.getTrainingMode().getModeId());
		
		//String satrtMeridiem =  training.getStartTime().toString();
		String startTime = training.getStartTime();
		String endTime = training.getEndTime();
		//String endMeridiem = training.getEndTime().toString();
		//startTime =  getTime(satrtMeridiem, startTime);
		//endTime = getTime(endMeridiem, endTime);
		
		/*Time startTime = training.getStartTime();
	    Time endTime = training.getEndTime();
		*/
		
		trainingObj.setStartTime((startTime));
		trainingObj.setEndTime(endTime);
		trainingObj.setDuration(training.getDuration());
		trainingObj.setVenue(training.getVenue());
		trainingObj.setRemark(training.getRemark());
		
		ModelAndView model = new ModelAndView("updateTraining");
		model.addObject("updatetrainingdata", trainingObj);
		model.addObject("categories", masterDataService.getAllTrainingCategories());
		model.addObject("modes", masterDataService.getAllTrainingModes());
		model.addObject("venues", trainingService.getVenueNames());
		
		return model;
	}
	
	@RequestMapping(value="/updateTraining",method=RequestMethod.POST)
	@ResponseBody
	public String updateTraining(@ModelAttribute("updatetrainingdata")TrainingVO trainingData,Model mod,HttpServletRequest req){
		String saveStatus=null;
		System.out.println("Hi Update");
		try{
			
			System.out.println("*********in update ************Training is id"+ trainingData.getTrainingId());
			String userId=(String)httpSession.getAttribute("userId");
			//short trainingId = Short.parseShort(req.getParameter("id")); 
			trainingData.setCreatedBy(userId);
			trainingData.setCreatedDate(Utilities.currentDate());
			//trainingData.setTrainingId(trainingId);
			Integer saveStatusCode=trainingService.updateTraining(trainingData);
			if(saveStatusCode==1){
				saveStatus="Training Updated Successfully!";
			}else{
				saveStatus="Training not Updated Successfully!";
			}
		}catch(DataIntegrityViolationException ex){
			saveStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in TrainingController  ..addUser()..."+ex.getMessage());
		}
		catch(Exception ex){
			saveStatus="Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in TrainingController  ..addUser()..."+ex.getMessage());
		}
		return saveStatus;
	}
	
	
	 @RequestMapping(value="/deletetraining",method=RequestMethod.POST)
		public @ResponseBody String deleteSkill(Model mod,HttpServletRequest request){
			  String saveStatus=null;
			  System.out.println("hiiiiiiiiiiii");
			 
			  String id=request.getParameter("ids");
			  String[] stringArray = id.split(",");
			try{
				  
				  Integer saveStatusCode=trainingService.deletetraining(stringArray);
				
				if(saveStatusCode==1){
					saveStatus="Training Deleted Successfully!";
				}else{
					saveStatus="Training Not Deleted Successfully!";
				}
			}catch(DataIntegrityViolationException ex){
				saveStatus="Plese try again.....Something went wrong!!!";
				ex.printStackTrace();
				LOG.error("Error in TrainingController  ..deleteTraining()..."+ex.getMessage());
			}
			catch(Exception ex){
				saveStatus="Training Not Deleted Successfully!";
				ex.printStackTrace();
				LOG.error("Error in TrainingController  ..deleteTraining()..."+ex.getMessage());
			}
			
			return saveStatus;
		}
	
	 
	 @RequestMapping(value="/loadResourcedata",method=RequestMethod.GET)
     public String loadResource(Model mod,@RequestParam String id1) throws Exception{
		 
		 
		 
        System.out.println("inside load resource data");
      // String tid=req.getParameter("id1");
       
        System.out.println("hbfjbdjhfdsjhfdsjhf"+id1);
               User user = new User();
               
               
              /* mod.addAttribute("user", user);
               try {
                     List<User>  listuser1 = userService.getUserList();
                     mod.addAttribute("userList1", userService.getUserList());
               } catch (Exception e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
               }*/
           	try{
    			LOG.info("Application Started");
    		}catch(Exception e){
    			LOG.error("Error in TrainingController.....AssignTraining()..."+e.getMessage());
    		}
              
               //ModelAndView model = new ModelAndView("trainingAssign");
               mod.addAttribute("trainingid", id1);
               mod.addAttribute("user", user);
               System.out.println("@@@@@@@@@@@@@@@@@@@@ inside controller"+userService.getUserList().toString());
               mod.addAttribute("userList1", userService.getUserList());
             //  mav.setViewName("trainingAssign");
               
               return "trainingAssign";
                           
        }
	 
	    @RequestMapping(value="/assigntraining",method=RequestMethod.POST)
		@ResponseBody
		public String AssignTraining(@ModelAttribute("user") User user,Model mod,HttpServletRequest req){
			String saveStatus1=null;
			String array[];
			try{
				
				TrainingAssign t=new TrainingAssign();
				System.out.println("###########@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				
				String userId=(String)httpSession.getAttribute("userId");
				
				System.out.println("in controller current logged in userid is"+userId);
				
				String tids= req.getParameter("idtraining");
			    array = tids.split(",");
				
			    System.out.println("array is"+array);
				String traiid=array[0];
				String uid=array[1];
				
				int i=Integer.parseInt(traiid);
				
				System.out.println("in controller training id is"+i);
				System.out.println("in controller selected user id"+uid);
				
				t.setComment("some comments");
				t.setNominatedby(userId);
				t.setNominationdate(Utilities.currentDate());
				t.setTrainingId(i);
				t.setUserId(uid);
				
				
				
				
				
				/*System.out.println("****************************************my venue"+trainingData.getVenue());
				System.out.println("****************************************my data"+trainingData.toString());
				System.out.println("****************************************start date"+trainingData.getStartDate());
				System.out.println("****************************************end date"+trainingData.getEndDate());*/
				
				
				Integer saveStatusCode=trainingService.assignTraining(t);
				System.out.println("status in controller:"+saveStatusCode);
				if(saveStatusCode==1){
					saveStatus1="Training Assigned Successfully!";
				}else{
					saveStatus1="Training not Assigned Successfully!";
				}
			}catch(DataIntegrityViolationException ex){
				saveStatus1="Plese try again.....Something went wrong!!!";
				ex.printStackTrace();
				LOG.error("Error in TrainingController  ..addUser()..."+ex.getMessage());
			}
			catch(Exception ex){
				saveStatus1="Data not Saved successfully!";
				ex.printStackTrace();
				LOG.error("Error in TrainingController  ..addUser()..."+ex.getMessage());
			}
			return saveStatus1;
		}
	 

	/* @RequestMapping(value="/loadResourcedata",method=RequestMethod.GET)
     public String loadResource(Model mod,HttpServletRequest req) throws Exception{
		 
		 
		 @RequestParam String id1
        System.out.println("inside load resource data");
       String tid=req.getParameter("id1");
       
        System.out.println("hbfjbdjhfdsjhfdsjhf"+tid);
               User user = new User();
               //mod.addAttribute("user", user);
               try {
                     List<User>  listuser1 = userService.getUserList();
                     mod.addAttribute("userList1", userService.getUserList());
               } catch (Exception e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
               }
              
              
               //ModelAndView model = new ModelAndView("trainingAssign");
               
               mod.addAttribute("user", user);
               System.out.println("@@@@@@@@@@@@@@@@@@@@"+userService.getUserList().toString());
               mod.addAttribute("userList1", userService.getUserList());
             //  mav.setViewName("trainingAssign");
               
               return "trainingAssign";
                           
        }
		*/
	/* @RequestMapping(value="/loadResourcedata",method=RequestMethod.GET)
		public String loadResource(Model mod,HttpServletRequest req){
			User user = new User();
			
			try{
				LOG.info("Application Started");
			}catch(Exception e){
				LOG.error("Error in TrainingController.....loadResourcedata()..."+e.getMessage());
			}
			
			System.out.println("userislist is"+ userService.getUserIdList());
			
			mod.addAttribute("user", user);	
			mod.addAttribute("UserId", userService.getUserIdList());
			mod.addAttribute("UserEmail", userService.getUserEmailList());
			
			return "trainingAssign";
			
			
			try {
			List<User>  listuser = userService.getUserList();
			mod.addAttribute("userList", userService.getUserList());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
					
		}*/
	 
	 
	public String getTime(String meridiem, String time) {
		Integer hour = Integer.parseInt(time);
		if(PM.equals(meridiem)) {
			hour = 12 + hour;
		}
		String hourInString = hour.toString()+":00:00";
		return hourInString;
	}
	
}
