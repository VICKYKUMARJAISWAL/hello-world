package com.igate.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.igate.beans.SkillLogBean;
import com.igate.beans.SkillVO;
import com.igate.model.User;
import com.igate.model.UserProfile;
import com.igate.model.UserType;
import com.igate.service.UserService;
import com.igate.utilities.PasswordEncryptor;
import com.igate.utilities.Utilities;

@Controller
public class UserController {
	final static Logger LOG = Logger.getLogger(UserController.class);
	@Autowired
	UserService userService;
	@Autowired
	HttpSession httpSession;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String Login(Model mod, HttpServletRequest req) {
		User user = new User();
		try {
			LOG.info("Application Started");
		} catch (Exception e) {
			LOG.error("Error in UserController.....Login()..." + e.getMessage());
		}
		mod.addAttribute("userDetails", user);
		return "login";
	}

	@RequestMapping(value = "/loadHomePage", method = RequestMethod.POST)
	public String loadHomePage(Model mod, HttpServletRequest req,
			@ModelAttribute("userDetails") User user) {
		String viewPage = "login";
		try {
			int statusCode = userService.loginUser(user);
			User data = userService.getUserData(user.getUserId());
			String userName = data.getFname();
			httpSession = req.getSession();
			httpSession.setAttribute("userName", userName);
			httpSession.setAttribute("userId", user.getUserId());
			httpSession.setAttribute("lastName", data.getLname());
			if (statusCode == 2) {
				System.out.println("********************************************");
				System.out.println("i am in load home page");
				viewPage = "menu";
			} else if (statusCode == 3) {
				mod.addAttribute("result", "Please enter correct password");
			} else if (statusCode == 1) {
				mod.addAttribute("result", "User is not registered!!!!");
			}
		} catch (Exception ex) {
			mod.addAttribute("result", "Unexpected Error, please contact system admin!");
			ex.printStackTrace();
		}
		
		return "menu";
	}
	
	@RequestMapping(value = "/loadAddUserForm", method = RequestMethod.GET)
	public String loadAddUserForm(Model mod, HttpServletRequest req) {
		System.out.println("In loadAddUserForm ");
		User user = new User();
		try {
			LOG.info("Application Started");
		} catch (Exception e) {
			LOG.error("Error in UserController.....loadProfileUpdate()..."
					+ e.getMessage());
		}
		/*req.setAttribute("user", user);*/
		mod.addAttribute("user", user);
		return "addUserPage";
	}

	@RequestMapping(value = "/loadProfileUpdate", method = RequestMethod.GET)
	public String loadProfileUpdate(Model mod, HttpServletRequest req) {
		UserProfile userProfile = new UserProfile();
		try {
			LOG.info("Application Started");
		} catch (Exception e) {
			LOG.error("Error in UserController.....loadProfileUpdate()..."
					+ e.getMessage());
		}
		mod.addAttribute("userProfile", userProfile);
		return "updateProfile";
	}

	@RequestMapping(value = "/loadRegistrationPage", method = RequestMethod.GET)
	public String loadRegistrationPage(Model mod, HttpServletRequest req) {
		User user = new User();
		try {
			LOG.info("Application Started");
		} catch (Exception e) {
			LOG.error("Error in UserController.....loadRegistrationPage()..."
					+ e.getMessage());
		}
		mod.addAttribute("userDetails", user);
		return "Registration";
	}

	@RequestMapping(value = "/loadResetPage", method = RequestMethod.GET)
	public String loadResetPage(Model mod, HttpServletRequest req) {
		User user = new User();
		try {
			LOG.info("Application Started");
		} catch (Exception e) {
			LOG.error("Error in UserController.....loadRegistrationPage()..."
					+ e.getMessage());
		}
		mod.addAttribute("userDetails", user);
		return "ResetPassword";
	}

	/*@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	@ResponseBody
	public String addUser(@ModelAttribute("userDetails") User user, Model mod,
			HttpServletRequest req) {
		String saveStatus = null;
		PasswordEncryptor pe = new PasswordEncryptor();
		pe.encrypt(user.getPassword());
		String password   = pe.getEncryptedString();
		user.setSysPwd("igate@123");
		user.setPassword(password);
		user.setPassword(user.getPassword());
		user.setCreatedDate(Utilities.currentDate());
		try {
			UserType userType = userService.getUserType((short) 1);
			user.setUserType(userType);
			Integer saveStatusCode = userService.addUser(user);
			if (saveStatusCode == 1) {
				saveStatus = "Data Saved Successfully!";
			} else {
				saveStatus = "Data not Saved Successfully!";
			}
		} catch (DataIntegrityViolationException ex) {
			saveStatus = "User is already existed!";
			ex.printStackTrace();
			LOG.error("Error in UserController  ..addUser()..."
					+ ex.getMessage());
		} catch (Exception ex) {
			saveStatus = "Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in UserController  ..addUser()..."
					+ ex.getMessage());
		}
		return saveStatus;
	}*/

	@RequestMapping(value = "/editUser", method = RequestMethod.GET)
	public 	String editUserData(Model mod, HttpServletRequest req) throws Exception {
		System.out.println("Edit");
		String userID =req.getParameter("id");
		System.out.println("User Id"+userID);
		User user = userService.getCompleteUserData(userID);
		 mod.addAttribute("user",user);
		
		return "editUserData";
		
	}
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public @ResponseBody 	String AddUserData(@ModelAttribute("userData") User userData,Model mod,HttpServletRequest req) throws Exception {
		String AddStatus=null;
		System.out.println("Add User");
		/*User user = new User();*/
		List<User>  listuser = userService.getUserList();
		String user_id=userData.getUserId();
		System.out.println("User_ID:"+user_id);
		for(User user:listuser ){
			System.out.println("In list"+user.getUserId());
			if(user.getUserId().equals(user_id)){
				AddStatus="User id entered already exists.";
				return AddStatus;
			}
		}
		UserProfile userprofile = userData.getUserProfile();
		System.out.println(user_id);
		System.out.println("Qual:"+userprofile.getHighestEducation());
		userprofile.setUserId(user_id);
		userprofile.setCreatedDate(Utilities.currentDate());
		userprofile.setModifiedDate(Utilities.currentDate());
		UserType ut=new UserType();
		ut.setId((short) 3);
		userData.setUserType(ut);
		userData.setActive("yes");
		Integer status = userService.addUser(userData);
		if(status==1){
			AddStatus="Resource Added Successfully!";
		}else{
			AddStatus="Adding was not successful!";
		}
		return AddStatus;
		
	}

	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public @ResponseBody 	String UpdateUserData(@ModelAttribute("userData") User userData,Model mod,HttpServletRequest req) throws Exception {
		String UpdateStatus=null;
		System.out.println("Update");
		User user = new User();
		String user_id=userData.getUserId();
		System.out.println("Qual:"+userData.getUserProfile().getHighestEducation());
		userData.getUserProfile().setUserId(user_id);
		Integer status = userService.updateUser(userData);
		if(status==1){
			UpdateStatus="Resource Details Saved Successfully!";
		}else{
			UpdateStatus="Update not successful!";
		}
		return UpdateStatus;
		
	}
	
	@RequestMapping(value = "/DeleteUsers", method = RequestMethod.POST)
	public @ResponseBody 	String DeleteUsers(Model mod,HttpServletRequest request) throws Exception {
		String deleteStatus=null;
		System.out.println("/DeleteUsers");
		String id=request.getParameter("ids");
		String[] stringArray = id.split(",");
		
		try{
			Integer saveStatusCode=userService.deleteUsers(stringArray);
			
			if(saveStatusCode==1){
				deleteStatus="User Deleted Successfully!";
			}else{
				deleteStatus="User Not Deleted Successfully!";
			}
		}catch(DataIntegrityViolationException ex){
			deleteStatus="Plese try again.....Something went wrong!!!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
		}
		catch(Exception ex){
			deleteStatus="Skill Not Deleted Successfully!";
			ex.printStackTrace();
			LOG.error("Error in SkillController  ..deleteSkill()..."+ex.getMessage());
		}
		
		return deleteStatus;
		
	}
	
	@RequestMapping(value = "/loadUserProfileData", method = RequestMethod.POST, headers = "Accept=application/json")
	public @ResponseBody
	UserProfile loadUserProfileData(Model mod, HttpServletRequest req) {
		UserProfile userProfile = null;
		String userID = null;
		if (req.getSession().getAttribute("userId") != null) {
			userID = req.getSession().getAttribute("userId").toString();
		}
		try {
			userProfile = userService.getUserProfileData(userID);
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in UserController  ..addUser()..."
					+ ex.getMessage());
		}
		return userProfile;
	}

	@RequestMapping(value = "/updateUserProfile", method = RequestMethod.POST)
	@ResponseBody
	public String updateUserProfile(
			@ModelAttribute("userProfile") UserProfile userProfile, Model mod,
			HttpServletRequest req) {
		String saveStatus = null;
		userProfile.setModifiedDate(Utilities.currentDate());
		try {
			Integer saveStatusCode = userService
					.updateUserProfileData(userProfile);
			if (saveStatusCode == 1) {
				saveStatus = "Data Updated Successfully!";
			} else {
				saveStatus = "Data not Updated Successfully!";
			}
		} catch (Exception ex) {
			saveStatus = "Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in UserController  ..updateUserProfile()..."
					+ ex.getMessage());
		}
		return saveStatus;
	}

	@RequestMapping(value = "/loadResetPassword", method = RequestMethod.GET)
	public String loadResetPassword(Model mod, HttpServletRequest req) {
		User user = new User();
		try {
			LOG.info("Application Started");
		} catch (Exception e) {
			LOG.error("Error in UserController.....loadRegistrationPage()..."
					+ e.getMessage());
		}
		mod.addAttribute("userDetails", user);
		return "changePassword";
	}

	@RequestMapping(value = "/savePassword", method = RequestMethod.POST)
	@ResponseBody
	public String savePassword(@ModelAttribute("userDetails") User user,
			Model mod, HttpServletRequest req) {
		String saveStatus = null;
		String userID = req.getSession().getAttribute("userId").toString();
		user.setUserId(userID);
		try {
			Integer saveStatusCode = userService.updatePassword(user);
			if (saveStatusCode == 1) {
				saveStatus = "Password Changed Successfully!";
			} else if (saveStatusCode == 2) {
				saveStatus = "Please enter old password correctly!";
			} else if (saveStatusCode == 0) {
				saveStatus = "Data not Saved successfully!";
			}
		} catch (Exception ex) {
			saveStatus = "Data not Saved successfully!";
			ex.printStackTrace();
			LOG.error("Error in UserController  ..savePassword()..."
					+ ex.getMessage());
		}
		return saveStatus;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	@RequestMapping(value = "/loadResourceStatus", method = RequestMethod.GET)
	public String loadResourceStatus(HttpSession session) {
		return "loadstatus";
	}
	
	@RequestMapping(value="/loadUsers",method=RequestMethod.GET)
	public String loadUserList(Model mod,HttpServletRequest req){
		/*User user = new User();
		mod.addAttribute("user", user);	*/
		try {
			List<User>  listuser = userService.getUserList();
			mod.addAttribute("userList", listuser);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		return "viewUserList";
				
	}
	
	/*@RequestMapping(value = "/editUser", method = RequestMethod.POST)
	public @ResponseBody
	String editUserData(Model mod, HttpServletRequest req) throws Exception {
		
		String userID =req.getParameter("userID");
		
		User user = userService.getUserData(userID);
		 mod.addAttribute("user",user);
		return "editUserData";
		
	}*/

}
