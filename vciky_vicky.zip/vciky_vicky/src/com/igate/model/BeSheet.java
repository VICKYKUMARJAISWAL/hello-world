package com.igate.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the users database table.
 * 
 */
@Entity
@Table(name="#BE_SHEET")
/*@NamedQuery(name="User.findAll", query="SELECT u FROM User u")*/
public class BeSheet implements Serializable {
	
	private static final long serialVersionUID = 1L;

	//@Id
	@Column(name="Project_Id")
	private BigDecimal projectId;

	@Column(name="Project_Name")
	private String projectName;

	@Column(name="SOW_Name")
	private String sowName;

	@Id
	@Column(name="Emp_Id")
	private BigDecimal empId;

	@Column(name = "Emp_Name")
	private String empName;

	@Column(name = "Emp_Loc")
	private String empLoc;

	@Column(name = "GS_Start_dt")
	private String gsStartDt;

	@Column(name = "GS_End_dt")
	private String gSEndDt;
	
	@Column(name="USD_Bill_Rate")
	private String usdBillRate;
	
	@Column(name="Jan_Billing")
	private String janBilling;
	
	@Column(name="Feb_Billing")
	private String febBilling;
	
	@Column(name="Mar_Billing")
	private String marBilling;
	
	@Column(name="Apr_Billing")
	private String aprBilling;
	
	@Column(name="May_Billing")
	private String mayBilling;
	
	@Column(name="Jun_Billing")
	private String junBilling;
	
	@Column(name="Jul_Billing")
	private String julBilling;
	
	@Column(name="Aug_Billing")
	private String augBilling;
	
	@Column(name="Sep_Billing")
	private String sepBilling;
	
	@Column(name="Oct_Billing")
	private String octBilling;
	
	@Column(name="Nov_Billing")
	private String novBilling;
	
	@Column(name="Dec_Billing")
	private String decBilling;
	
	public BigDecimal getProjectId() {
		return projectId;
	}

	public void setProjectId(BigDecimal projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getSowName() {
		return sowName;
	}

	public void setSowName(String sowName) {
		this.sowName = sowName;
	}

	public BigDecimal getEmpId() {
		return empId;
	}

	public void setEmpId(BigDecimal empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpLoc() {
		return empLoc;
	}

	public void setEmpLoc(String empLoc) {
		this.empLoc = empLoc;
	}

	public String getGsStartDt() {
		return gsStartDt;
	}

	public void setGsStartDt(String gsStartDt) {
		this.gsStartDt = gsStartDt;
	}

	public String getgSEndDt() {
		return gSEndDt;
	}

	public void setgSEndDt(String gSEndDt) {
		this.gSEndDt = gSEndDt;
	}

	public String getUsdBillRate() {
		return usdBillRate;
	}

	public void setUsdBillRate(String usdBillRate) {
		this.usdBillRate = usdBillRate;
	}

	public String getJanBilling() {
		return janBilling;
	}

	public void setJanBilling(String janBilling) {
		this.janBilling = janBilling;
	}

	public String getFebBilling() {
		return febBilling;
	}

	public void setFebBilling(String febBilling) {
		this.febBilling = febBilling;
	}

	public String getMarBilling() {
		return marBilling;
	}

	public void setMarBilling(String marBilling) {
		this.marBilling = marBilling;
	}

	public String getAprBilling() {
		return aprBilling;
	}

	public void setAprBilling(String aprBilling) {
		this.aprBilling = aprBilling;
	}

	public String getMayBilling() {
		return mayBilling;
	}

	public void setMayBilling(String mayBilling) {
		this.mayBilling = mayBilling;
	}

	public String getJunBilling() {
		return junBilling;
	}

	public void setJunBilling(String junBilling) {
		this.junBilling = junBilling;
	}

	public String getJulBilling() {
		return julBilling;
	}

	public void setJulBilling(String julBilling) {
		this.julBilling = julBilling;
	}

	public String getAugBilling() {
		return augBilling;
	}

	public void setAugBilling(String augBilling) {
		this.augBilling = augBilling;
	}

	public String getSepBilling() {
		return sepBilling;
	}

	public void setSepBilling(String sepBilling) {
		this.sepBilling = sepBilling;
	}

	public String getOctBilling() {
		return octBilling;
	}

	public void setOctBilling(String octBilling) {
		this.octBilling = octBilling;
	}

	public String getNovBilling() {
		return novBilling;
	}

	public void setNovBilling(String novBilling) {
		this.novBilling = novBilling;
	}

	public String getDecBilling() {
		return decBilling;
	}

	public void setDecBilling(String decBilling) {
		this.decBilling = decBilling;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	
	@Override
	public String toString() {
		return "BESheet [projectId=" + projectId + ", projectName=" + projectName
				+ ", sowName=" + sowName + ", empId=" + empId + ", empName="
				+ empName + ", empLoc=" + empLoc + ", gsStartDt=" + gsStartDt
				+ ", gSEndDt=" + gSEndDt + ", usdBillRate=" + usdBillRate
				+ ", janBilling=" + janBilling + ", febBilling=" + febBilling
				+ ", marBilling=" + marBilling + ", aprBilling=" + aprBilling
				+ ", mayBilling=" + mayBilling + ", junBilling=" + junBilling
				+ ", julBilling=" + julBilling + ", augBilling=" + augBilling
				+ ", sepBilling=" + sepBilling + ", octBilling=" + octBilling
				+ ", novBilling=" + novBilling + ", decBilling=" + decBilling
				+ "]";
	}
	
}