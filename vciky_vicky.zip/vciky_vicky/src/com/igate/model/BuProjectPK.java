package com.igate.model;

import java.io.Serializable;

import javax.persistence.*;

/**
 * The primary key class for the bu_projects database table.
 * 
 */
@Embeddable
public class BuProjectPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="bu_id", insertable=false, updatable=false)
	private short buId;

	@Column(name="project_id", insertable=false, updatable=false)
	private short projectId;

	public BuProjectPK() {
	}
	public short getBuId() {
		return this.buId;
	}
	public void setBuId(short buId) {
		this.buId = buId;
	}
	public short getProjectId() {
		return this.projectId;
	}
	public void setProjectId(short projectId) {
		this.projectId = projectId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BuProjectPK)) {
			return false;
		}
		BuProjectPK castOther = (BuProjectPK)other;
		return 
			(this.buId == castOther.buId)
			&& (this.projectId == castOther.projectId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.buId);
		hash = hash * prime + ((int) this.projectId);
		
		return hash;
	}
}