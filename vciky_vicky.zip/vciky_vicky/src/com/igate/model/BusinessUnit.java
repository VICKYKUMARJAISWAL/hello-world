package com.igate.model;

import java.io.Serializable;

import javax.persistence.*;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the business_unit database table.
 * 
 */
@Entity
@Table(name="business_unit")
@NamedQuery(name="BusinessUnit.findAll", query="SELECT b FROM BusinessUnit b")
public class BusinessUnit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private short id;
	

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="created_date")
	private Date createdDate;

	@Column(name="modified_by")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="name")
	private String name;

	//bi-directional many-to-one association to BuProject
	@OneToMany(mappedBy="businessUnit")
	private List<BuProject> buProjects;

	public BusinessUnit() {
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public short getId() {
		return id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<BuProject> getBuProjects() {
		return this.buProjects;
	}

	public void setBuProjects(List<BuProject> buProjects) {
		this.buProjects = buProjects;
	}

	public BuProject addBuProject(BuProject buProject) {
		getBuProjects().add(buProject);
		buProject.setBusinessUnit(this);

		return buProject;
	}

	public BuProject removeBuProject(BuProject buProject) {
		getBuProjects().remove(buProject);
		buProject.setBusinessUnit(null);

		return buProject;
	}

}