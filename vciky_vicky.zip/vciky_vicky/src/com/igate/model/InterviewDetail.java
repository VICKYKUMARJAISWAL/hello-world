package com.igate.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.igate.utilities.OpportunityStausenum;

/**
 * The persistent class for the interview_details database table.
 * 
 */

@Entity
@Table(name = "interview_details")
@NamedQuery(name = "InterviewDetail.findAll", query = "SELECT i FROM InterviewDetail i")
public class InterviewDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "interview_id")
	private Integer interviewId;

	@Column(name = "comments")
	private String comments;

	@Temporal(TemporalType.DATE)
	@Column(name = "opportunity_start_date")
	private Date opportunityStartDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "opportunity_end_date")
	private Date opportunityEndtartDate;

	@Column(name = "name")
	private String name;

	@Column(name = "opportunity_status")
	private String opportunityStatus;
	
	@Column(name = "active")
	private String active;
	
	public InterviewDetail() {
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getInterviewId() {
		return this.interviewId;
	}

	public void setInterviewId(Integer interviewId) {
		this.interviewId = interviewId;
	}

	public String getOpportunityStatus() {
		return opportunityStatus;
	}

	public void setOpportunityStatus(String opportunityStatus) {
		this.opportunityStatus = opportunityStatus;
	}

	public Date getOpportunityStartDate() {
		return opportunityStartDate;
	}

	public void setOpportunityStartDate(Date opportunityStartDate) {
		this.opportunityStartDate = opportunityStartDate;
	}

	public Date getOpportunityEndtartDate() {
		return opportunityEndtartDate;
	}

	public void setOpportunityEndtartDate(Date opportunityEndtartDate) {
		this.opportunityEndtartDate = opportunityEndtartDate;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// Ravikiran
	@Fetch(FetchMode.JOIN)
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "interview_skills", joinColumns = { @JoinColumn(name = "interview_id") }, inverseJoinColumns = { @JoinColumn(name = "skill_id") })
	private List<Skill> skills = new ArrayList<Skill>();

	public List<Skill> getSkills() {

		return skills;

	}

	public void setSkills(List<Skill> skills) {
		this.skills = skills;
	}

	// srinivas

	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "business_unit_id",insertable=false, updatable=false)
	private BusinessUnit businessUnit;

	public BusinessUnit getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(BusinessUnit businessUnit) {
		this.businessUnit = businessUnit;
	}

	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "location_id",insertable=false, updatable=false)
	private Location location;

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "project_id",insertable=false, updatable=false)
	private Project project;

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

//	@Column(name = "opportunity_status")
//	List<OpportunityStausenum> opportunitystatus=Arrays.asList(OpportunityStausenum.values());
	
	@Column(name = "location_id")
	private Integer locationId;

	@Column(name = "project_id")
	private Short projectId;

	@Column(name = "business_unit_id")
	private Short businessUnitId;

	

//	public List<OpportunityStausenum> getOpportunitystatus() {
//		return opportunitystatus;
//	}
//
//	public void setOpportunitystatus(List<OpportunityStausenum> opportunitystatus) {
//		this.opportunitystatus = opportunitystatus;
//	}

	public Short getBusinessUnitId() {
		return this.businessUnitId;
	}

	public void setBusinessUnitId(Short businessUnitId) {
		this.businessUnitId = businessUnitId;
	}

	public Integer getLocationId() {
		return this.locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Short getProjectId() {
		return this.projectId;
	}

	public void setProjectId(Short s) {
		this.projectId = s;
	}

}
