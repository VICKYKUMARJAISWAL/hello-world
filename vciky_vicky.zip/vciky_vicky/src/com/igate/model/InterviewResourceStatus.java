package com.igate.model;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the interview_resource_status database table.
 * 
 */
@Entity
@Table(name="interview_resource_status")
@NamedQuery(name="InterviewResourceStatus.findAll", query="SELECT i FROM InterviewResourceStatus i")
public class InterviewResourceStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="int_resource_id")
	private int intResourceId;

	@Column(name="interview_feedback")
	private String interviewFeedback;

	@Column(name="modified_by")
	private String modifiedBy;

	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="user_id")
	private String userId;

	@Column(name="interview_id")
	private int interviewid;

	@Column(name="interview_status_id")
	private int interviewStatusId;

	public InterviewResourceStatus() {
	}

	public int getIntResourceId() {
		return this.intResourceId;
	}

	public void setIntResourceId(int intResourceId) {
		this.intResourceId = intResourceId;
	}

	public String getInterviewFeedback() {
		return this.interviewFeedback;
	}

	public void setInterviewFeedback(String interviewFeedback) {
		this.interviewFeedback = interviewFeedback;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getInterviewid() {
		return interviewid;
	}

	public void setInterviewid(int interviewid) {
		this.interviewid = interviewid;
	}

	public int getInterviewStatusId() {
		return interviewStatusId;
	}

	public void setInterviewStatusId(int interviewStatusId) {
		this.interviewStatusId = interviewStatusId;
	}

	
}