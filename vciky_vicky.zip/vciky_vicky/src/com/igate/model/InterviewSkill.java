package com.igate.model;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the interview_skills database table.
 * 
 */
@Entity
@Table(name="interview_skills")
@NamedQuery(name="InterviewSkill.findAll", query="SELECT i FROM InterviewSkill i")
public class InterviewSkill implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="interview_skills_id")
	private int interviewSkillsId;

	@Column(name="modified_by")
	private String modifiedBy;

	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="skill_id")
	private int skillId;


	@Column(name="interview_id")
	private int interviewid;

	public InterviewSkill() {
	}

	public int getInterviewSkillsId() {
		return interviewSkillsId;
	}

	public void setInterviewSkillsId(int interviewSkillsId) {
		this.interviewSkillsId = interviewSkillsId;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public int getInterviewid() {
		return interviewid;
	}

	public void setInterviewid(int interviewid) {
		this.interviewid = interviewid;
	}

	

}