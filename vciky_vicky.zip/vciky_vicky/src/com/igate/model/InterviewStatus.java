package com.igate.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="interview_status")
@NamedQuery(name="InterviewStatus.findAll", query="SELECT a FROM InterviewStatus a")
public class InterviewStatus implements Serializable {
	
	/*
	 * 
	 * 
	 * 	

	 * CREATE TABLE interview_status (
		id "row_id"  IDENTITY ,
		status_name VARCHAR(20)  NOT NULL,
		created_by CHAR(8)  NOT NULL,
		created_date DATETIME  NOT NULL
	)
	 * 	

	 */
	

private static final long serialVersionUID = 1L;

@Id
@Column(name="id")
private Integer id;

@Column(name="status_name")
private String statusName;

@Column(name="created_by")
private String createdBy;

@Column(name="created_date")
private Timestamp createdDate;

public Integer getId() {
	return id;
}

@Override
public String toString() {
	return id +  ":" +statusName ;
}

public void setId(Integer id) {
	this.id = id;
}

public String getStatusName() {
	return statusName;
}

public void setStatusName(String statusName) {
	this.statusName = statusName;
}

public String getCreatedBy() {
	return createdBy;
}

public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}

public Timestamp getCreatedDate() {
	return createdDate;
}

public void setCreatedDate(Timestamp createdDate) {
	this.createdDate = createdDate;
}
	

}
