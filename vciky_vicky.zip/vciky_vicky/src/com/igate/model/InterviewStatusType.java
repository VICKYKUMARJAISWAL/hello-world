package com.igate.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the interview_status_type database table.
 * 
 */
@Entity
@Table(name="interview_status_type")
@NamedQuery(name="InterviewStatusType.findAll", query="SELECT i FROM InterviewStatusType i")
public class InterviewStatusType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private short id;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="status_name")
	private String statusName;

		public InterviewStatusType() {
	}

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getStatusName() {
		return this.statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	
	

}