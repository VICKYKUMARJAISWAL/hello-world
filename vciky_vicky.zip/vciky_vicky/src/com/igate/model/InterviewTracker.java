package com.igate.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "interview_tracker")
public class InterviewTracker implements Serializable {

	private static final long serialVersionUID = 2672613521127425761L;

	
	/*
	 * 	private int resourceName;
	    private short teamInterviewedFor;
	
	/*
	 * id :pk user id : char not null pk user table project id : small int pk
	 * project
  
	
	private Date dateOfInterview;
	private String clientManager;
	private String technologyStack;
	private short roundNumber;
	private short status;
	private int location;
	private int modeOfInterview;
	
	 */
	
	
	
	
	@Id
//	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@GenericGenerator(name="generator", strategy="increment")
	@GeneratedValue(generator="generator")
	@Column(name = "id")
	private Integer id;

	@Column(name = "user_id")
	private String userId; //char

	@Column(name = "interview_date")
	private Date interviewDate;

	@Column(name = "project_id")
	private Integer projectId;

	@Column(name = "client_mgr_name")
	private String clientManagerName;

	@Column(name = "technology_stack")
	private String technologyStack;

	@Column(name = "interview_round")
	private Integer interviewRound;

	@Column(name = "interview_status_id")
	private Integer interviewStatusId;

	@Column(name = "location_id")
	private Integer locationId;

	@Column(name = "interview_mode_id")
	private Integer interviewMode;
	
	
	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;
	

	

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getInterviewDate() {
		return interviewDate;
	}

	public void setInterviewDate(java.util.Date date) {
		this.interviewDate = (Date) date;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getClientManagerName() {
		return clientManagerName;
	}

	public void setClientManagerName(String clientManagerName) {
		this.clientManagerName = clientManagerName;
	}

	public String getTechnologyStack() {
		return technologyStack;
	}

	public void setTechnologyStack(String technologyStack) {
		this.technologyStack = technologyStack;
	}

	public int getInterviewRound() {
		return interviewRound;
	}

	public void setInterviewRound(Integer interviewRound) {
		this.interviewRound = interviewRound;
	}

	public int getInterviewStatusId() {
		return interviewStatusId;
	}

	public void setInterviewStatusId(Integer interviewStatusId) {
		this.interviewStatusId = interviewStatusId;
	}

	public int getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public int getInterviewMode() {
		return interviewMode;
	}

	public void setInterviewMode(Integer interviewMode) {
		this.interviewMode = interviewMode;
	}

}
