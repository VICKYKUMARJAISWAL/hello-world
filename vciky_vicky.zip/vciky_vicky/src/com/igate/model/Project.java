package com.igate.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the projects database table.
 * 
 */
@Entity
@Table(name="projects")
@NamedQueries({
	@NamedQuery(name="Project.findAll", query="SELECT p FROM Project p"),
	@NamedQuery(name = "Project.findProjectById",query = "SELECT p FROM Project p where p.id = :id")
})
public class Project implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private short id;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	@Temporal(TemporalType.DATE)
	private Date createdDate;

	@Column(name="modified_by")
	private String modifiedBy;

	@Column(name="modified_date")
	@Temporal(TemporalType.DATE)
	private Date modifiedDate;

	@Column(name="project_name")
	private String projectName;

	/*//bi-directional many-to-one association to BuProject
	@OneToMany(mappedBy="project")
	private List<BuProject> buProjects;*/

	public Project() {
	}

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

/*	public List<BuProject> getBuProjects() {
		return this.buProjects;
	}

	public void setBuProjects(List<BuProject> buProjects) {
		this.buProjects = buProjects;
	}*/

	/*public BuProject addBuProject(BuProject buProject) {
		getBuProjects().add(buProject);
		buProject.setProject(this);

		return buProject;
	}

	public BuProject removeBuProject(BuProject buProject) {
		getBuProjects().remove(buProject);
		buProject.setProject(null);

		return buProject;
	}*/

}