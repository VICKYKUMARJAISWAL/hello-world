package com.igate.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the projects Log database table.
 * 
 */
@Entity
@Table(name="AuditAdminProjectsLog")
@NamedQueries({
	@NamedQuery(name="ProjectLog.findAll", query="SELECT p FROM ProjectLog p"),
	@NamedQuery(name = "ProjectLog.findProjectById",query = "SELECT p FROM ProjectLog p where p.id = :id")
})
public class ProjectLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="projectid")
	private String projectid;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	@Temporal(TemporalType.DATE)
	private Date createdDate;

	@Column(name="modified_by")
	private String modifiedBy;

	@Column(name="modified_date")
	@Temporal(TemporalType.DATE)
	private Date modifiedDate;

	@Column(name="project_name")
	private String projectName;
	
	@Column(name="Status")
	private String status;
	
	@Column(name="action")
	private String action;

	
	

	

	

	public String getProjectid() {
		return projectid;
	}

	public void setProjectid(String projectid) {
		this.projectid = projectid;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	
	
	

}