package com.igate.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the skills database table.
 * 
 */
@Entity
@Table(name="skills")
@NamedQueries({
	@NamedQuery(name="Skill.findAll", query="SELECT s FROM Skill s"),
	@NamedQuery(name = "Skill.findSkillById",query = "select t from Skill t where t.id = :id"),
	
})
public class Skill implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private short id;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	@Temporal(TemporalType.DATE)
	private Date createdDate;

	@Column(name="modified_by")
	private String modifiedBy;

	@Column(name="modified_date")
	@Temporal(TemporalType.DATE)
	private Date modifiedDate;

	@Column(name="skills_name")
	private String skillsName;

	//bi-directional many-to-many association to User
	/*@ManyToMany(mappedBy="skills")
	private List<User> users;*/

	public Skill() {
	}

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getSkillsName() {
		return this.skillsName;
	}

	public void setSkillsName(String skillsName) {
		this.skillsName = skillsName;
	}

	/*public List<User> getUsers() {
		return this.users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}
*/
}