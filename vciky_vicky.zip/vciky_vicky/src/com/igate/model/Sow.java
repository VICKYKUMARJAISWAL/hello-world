package com.igate.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;


/**
 * The persistent class for the sow database table.
 * 
 */
@Entity

@Table(name="sow")
/*@NamedQueries({
	@NamedQuery(name="Sow.findAll", query="SELECT s FROM Sow s"),
	@NamedQuery(name = "Sow.findSowById",query = "select t from Sow t where t.sow_id = :id"),
	
})*/
public class Sow implements Serializable {

	private static final long serialVersionUID = 1L;

	
	@GeneratedValue(strategy=GenerationType.AUTO)
	private short id;
	
	@Id
	@Column(name="sow_id")
	private String sowId;

	@Column(name="sow_name")
	private String sowName;
	
	@Column(name="start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;
	
	@Column(name="end_date")
	@Temporal(TemporalType.DATE)
	private Date endDate;
	
	@Column(name="billing_type")
	private String billingType;
	
	@Column(name="amendment")
	private char amendment;
	
	@Column(name="schedule_no")
	private int scheduleNo;
	
	@Column(name="sow_project_id")
	private short projectId;
	
	//many-to-one unidirectional association to projects
	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="sow_project_id",insertable=false, updatable=false)
	private Project proj;
	
	@Column(name="ichange_proj_id")	
	private String ichangeProjId;
	
	@Column(name="extension")	
	private char extension;
	
	@Column(name="prev_sow_id")
	private String prevSowId;
	
	/*@Fetch(FetchMode.JOIN)
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="prev_sow_id",insertable=false, updatable=false)
	private Sow sow;*/
	
	@Column(name="bu_id")
	private short buId;
	
	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="bu_id", insertable=false, updatable=false)
	private BusinessUnit bu;
	
	@Column(name="proj_type")
	private String projectType;
	
	@Column(name="client_manager")
	private String clientMgr;
	
	@Column(name="cg_manager")
	private String cgManager;
	
	@OneToMany
	@JoinTable(
		name="sow_users"
		, joinColumns={
			@JoinColumn(name="sow_id")
			}
		, inverseJoinColumns={
			@JoinColumn(name="user_id")
			}
		)
	private List<User> users;
	/*@OneToMany
	@JoinTable(
		name="sow_users"
		, joinColumns={
			@JoinColumn(name="sow_id")
			}
		, inverseJoinColumns={
			@JoinColumn(name="user_id")
			}
		)
	private List<User> users;*/
	
	/*@OneToMany
	@JoinColumn(name="user_id")
	private List<User> users;*/

	public short getId() {
		return id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getSowId() {
		return sowId;
	}

	public void setSowId(String sowId) {
		this.sowId = sowId;
	}

	public String getSowName() {
		return sowName;
	}

	public void setSowName(String sowName) {
		this.sowName = sowName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public char getAmendment() {
		return amendment;
	}

	public void setAmendment(char amendment) {
		this.amendment = amendment;
	}

	public int getScheduleNo() {
		return scheduleNo;
	}

	public void setScheduleNo(int scheduleNo) {
		this.scheduleNo = scheduleNo;
	}

	public short getProjectId() {
		return projectId;
	}

	public void setProjectId(Short projectId) {
		this.projectId = projectId;
	}

	public Project getProj() {
		return proj;
	}

	public void setProj(Project proj) {
		this.proj = proj;
	}

	public String getIchangeProjId() {
		return ichangeProjId;
	}

	public void setIchangeProjId(String ichangeProjId) {
		this.ichangeProjId = ichangeProjId;
	}

	public char getExtension() {
		return extension;
	}

	public void setExtension(char extension) {
		this.extension = extension;
	}

	public String getPrevSowId() {
		return prevSowId;
	}

	public void setPrevSowId(String prevSowId) {
		this.prevSowId = prevSowId;
	}

	/*public Sow getSow() {
		return sow;
	}

	public void setSow(Sow sow) {
		this.sow = sow;
	}*/

	public short getBuId() {
		return buId;
	}

	public void setBuId(short buId) {
		this.buId = buId;
	}

	public BusinessUnit getBu() {
		return bu;
	}

	public void setBu(BusinessUnit bu) {
		this.bu = bu;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public String getClientMgr() {
		return clientMgr;
	}

	public void setClientMgr(String clientMgr) {
		this.clientMgr = clientMgr;
	}

	public String getCgManager() {
		return cgManager;
	}

	public void setCgManager(String cgManager) {
		this.cgManager = cgManager;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}


}