package com.igate.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;


/**
 * The persistent class for the sow_users database table.
 * 
 */
@Entity

@Table(name="sow_users")
/*@NamedQueries({
	@NamedQuery(name="Sow.findAll", query="SELECT s FROM Sow s"),
	@NamedQuery(name = "Sow.findSowById",query = "select t from Sow t where t.sow_id = :id"),
	
})*/
public class SowUsers implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SowUsersComposite suCompKey;
	
	@Column(name="resource_sow_start_date")
	@Temporal(TemporalType.DATE)
	private Date resourceSowStartDate;
	
	@Column(name="resource_sow_end_date")
	@Temporal(TemporalType.DATE)
	private Date resourceSowEndDate;
	
	@Column(name="local_currency")
	private String localCurrency;
	
	@Column(name="inr_rate")
	private int inrRate;
	
	@Column(name="dollar_rate")
	private int dollarRate;
	
	public SowUsersComposite getSuCompKey() {
		return suCompKey;
	}

	public void setSuCompKey(SowUsersComposite suCompKey) {
		this.suCompKey = suCompKey;
	}

	public Date getResourceSowStartDate() {
		return resourceSowStartDate;
	}

	public void setResourceSowStartDate(Date resourceSowStartDate) {
		this.resourceSowStartDate = resourceSowStartDate;
	}

	public Date getResourceSowEndDate() {
		return resourceSowEndDate;
	}

	public void setResourceSowEndDate(Date resourceSowEndDate) {
		this.resourceSowEndDate = resourceSowEndDate;
	}

	public String getLocalCurrency() {
		return localCurrency;
	}

	public void setLocalCurrency(String localCurrency) {
		this.localCurrency = localCurrency;
	}

	public int getInrRate() {
		return inrRate;
	}

	public void setInrRate(int inrRate) {
		this.inrRate = inrRate;
	}

	public int getDollarRate() {
		return dollarRate;
	}

	public void setDollarRate(int dollarRate) {
		this.dollarRate = dollarRate;
	}

	
	

}