package com.igate.model;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import java.sql.Timestamp;
import java.sql.Time;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the training database table.
 * 
 */
@Entity
@Table(name="training")
@NamedQueries({
	@NamedQuery(name="Training.findAll", query="SELECT t FROM Training t"),
	@NamedQuery(name = "Traing.findAllFromCurrentDate",query = "select t from Training t where t.startDate >= :startDate"),
	//@NamedQuery(name = "Traing.findAllFromCurrentDate",query = "select t from Training t left join fetch TrainingCategory tc left join fetch  TrainingMode tc left join fetch  TrainingStatus ts where t.startDate > :startDate"),
	@NamedQuery(name = "Traing.findTrainingbyId",query = "select t from Training t where t.trainingId = :trainingId"),
	//@NamedQuery(name="Traing.getContentType", query="select content_type from Training"),
	//@NamedQuery(name="Traing.getCourseName", query="select course_name from Training t")
	//@NamedQuery(name = "Skill.findSkillById",query = "select t from Skill t where t.id = :id"),
})
public class Training implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="training_id")
	private short trainingId;

	@Column(name="content_type")
	private String contentType;

	@Column(name="course_name")
	private String courseName;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Date createdDate;

	private String duration;

	@Temporal(TemporalType.DATE)
	@Column(name="end_date")
	private Date endDate;

	@Column(name="end_time")
	private String endTime;

	@Column(name="registration_required")
	private boolean registrationRequired;

	private String remark;

	@Temporal(TemporalType.DATE)
	@Column(name="start_date")
	private Date startDate;

	@Column(name="start_time")
	private String startTime;

	private String venue;

	//bi-directional many-to-one association to TrainingCategory
	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="category_id")
	private TrainingCategory trainingCategory;

	//bi-directional many-to-one association to TrainingMode
	
	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="mode_id")
	private TrainingMode trainingMode;

	//bi-directional many-to-one association to TrainingStatus
	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="status_id")
	private TrainingStatus trainingStatus;

	public Training() {
	}

	public short getTrainingId() {
		return this.trainingId;
	}

	public void setTrainingId(short trainingId) {
		this.trainingId = trainingId;
	}

	public String getContentType() {
		return this.contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getCourseName() {
		return this.courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDuration() {
		return this.duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getEndTime() {
		return this.endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public boolean getRegistrationRequired() {
		return this.registrationRequired;
	}

	public void setRegistrationRequired(boolean registrationRequired) {
		this.registrationRequired = registrationRequired;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getStartTime() {
		return this.startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getVenue() {
		return this.venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}

	public TrainingCategory getTrainingCategory() {
		return this.trainingCategory;
	}

	public void setTrainingCategory(TrainingCategory trainingCategory) {
		this.trainingCategory = trainingCategory;
	}

	public TrainingMode getTrainingMode() {
		return this.trainingMode;
	}

	public void setTrainingMode(TrainingMode trainingMode) {
		this.trainingMode = trainingMode;
	}

	public TrainingStatus getTrainingStatus() {
		return this.trainingStatus;
	}

	public void setTrainingStatus(TrainingStatus trainingStatus) {
		this.trainingStatus = trainingStatus;
	}

	/*//Code Added by Ajaya on 20150907
	private List<TrainingCategory> allTrainingCategories;
	
	private List<TrainingMode> allTrainingModes;
	
	public List<TrainingCategory> getAllTrainingCategories() {
		return allTrainingCategories;
	}

	public List<TrainingMode> getAllTrainingModes() {
		return allTrainingModes;
	}
  	
	public void setAllTrainingCategories(List<TrainingCategory> allTrainingCategory) {
		// TODO Auto-generated method stub
		
	}

	public void setAllTrainingModes(List<TrainingMode> allTrainingMode) {
		// TODO Auto-generated method stub
		
	}
	//Code added by Ajaya 20150907 ends here
*/}