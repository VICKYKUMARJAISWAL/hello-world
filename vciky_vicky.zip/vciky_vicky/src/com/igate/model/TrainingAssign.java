package com.igate.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Generated;

@Entity
@Table(name="training_assigned")
public class TrainingAssign {
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@Column(name="user_id")
	private String userId;
	
	@Column(name="training_id")
	private int trainingId;
	@Column(name="nominated_by")
	private String nominatedby;
	@Column(name="nomination_date")
	private Date nominationdate;
	@Column(name="comments")
	private String comment;
	
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}
	public String getNominatedby() {
		return nominatedby;
	}
	public void setNominatedby(String nominatedby) {
		this.nominatedby = nominatedby;
	}
	public Date getNominationdate() {
		return nominationdate;
	}
	public void setNominationdate(Date nominationdate) {
		this.nominationdate = nominationdate;
	}
	

}
