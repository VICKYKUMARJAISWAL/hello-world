package com.igate.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the training_mode database table.
 * 
 */
@Entity
@Table(name="training_mode")
@NamedQuery(name="TrainingMode.findAll", query="SELECT t FROM TrainingMode t")
public class TrainingMode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="mode_id")
	private int modeId;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="mode_name")
	private String modeName;

	//bi-directional many-to-one association to Training
	@OneToMany(mappedBy="trainingMode" )
	private List<Training> trainings;

	public TrainingMode() {
		
		
	}

	public int getModeId() {
		return this.modeId;
	}

	public void setModeId(int modeId) {
		this.modeId = modeId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getModeName() {
		return this.modeName;
	}

	public void setModeName(String modeName) {
		this.modeName = modeName;
	}

	public List<Training> getTrainings() {
		return this.trainings;
	}

	public void setTrainings(List<Training> trainings) {
		this.trainings = trainings;
	}

	public Training addTraining(Training training) {
		getTrainings().add(training);
		training.setTrainingMode(this);

		return training;
	}

	public Training removeTraining(Training training) {
		getTrainings().remove(training);
		training.setTrainingMode(null);

		return training;
	}

}