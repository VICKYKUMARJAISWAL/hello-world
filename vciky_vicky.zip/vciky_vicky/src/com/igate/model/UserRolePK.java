package com.igate.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the user_role database table.
 * 
 */
@Embeddable
public class UserRolePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="role_id", insertable=false, updatable=false)
	private short roleId;

	@Column(name="user_id", insertable=false, updatable=false)
	private String userId;

	public UserRolePK() {
	}
	public short getRoleId() {
		return this.roleId;
	}
	public void setRoleId(short roleId) {
		this.roleId = roleId;
	}
	public String getUserId() {
		return this.userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}


}