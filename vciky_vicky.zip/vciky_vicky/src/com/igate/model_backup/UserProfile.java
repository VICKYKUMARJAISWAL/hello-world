package com.igate.model_backup;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the user_profile database table.
 * 
 */
@Entity
@Table(name="user_profile")
@NamedQuery(name="UserProfile.findAll", query="SELECT u FROM UserProfile u")
public class UserProfile implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_id")
	private String userId;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="exp_summary")
	private String expSummary;

	@Column(name="highest_education")
	private String highestEducation;

	@Column(name="modified_date")
	private Timestamp modifiedDate;

	@Column(name="months_of_exp")
	private BigDecimal monthsOfExp;

	@Column(name="year_of_exp")
	private BigDecimal yearOfExp;

	//bi-directional many-to-one association to UserStatus
	@ManyToOne
	@JoinColumn(name="user_status_id")
	private UserStatus userStatus;

	//bi-directional one-to-one association to User
	@OneToOne
	@JoinColumn(name="user_id")
	private User user;

	public UserProfile() {
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getExpSummary() {
		return this.expSummary;
	}

	public void setExpSummary(String expSummary) {
		this.expSummary = expSummary;
	}

	public String getHighestEducation() {
		return this.highestEducation;
	}

	public void setHighestEducation(String highestEducation) {
		this.highestEducation = highestEducation;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public BigDecimal getMonthsOfExp() {
		return this.monthsOfExp;
	}

	public void setMonthsOfExp(BigDecimal monthsOfExp) {
		this.monthsOfExp = monthsOfExp;
	}

	public BigDecimal getYearOfExp() {
		return this.yearOfExp;
	}

	public void setYearOfExp(BigDecimal yearOfExp) {
		this.yearOfExp = yearOfExp;
	}

	public UserStatus getUserStatus() {
		return this.userStatus;
	}

	public void setUserStatus(UserStatus userStatus) {
		this.userStatus = userStatus;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}