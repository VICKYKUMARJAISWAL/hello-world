package com.igate.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.igate.model.BeSheet;

public interface BeSheetService {	
	public List<BeSheet> getBeSheetDetails(int year);
}
