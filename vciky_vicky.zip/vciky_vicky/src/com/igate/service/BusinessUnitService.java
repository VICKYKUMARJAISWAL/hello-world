package com.igate.service;

import com.igate.beans.BusinessUnitVO;
import com.igate.model.BusinessUnit;

public interface BusinessUnitService {
  public Integer addBusinessUnit(BusinessUnitVO businessUnitVO);
  public BusinessUnit getBuUnitById(Short id);
}
