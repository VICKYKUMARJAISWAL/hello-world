package com.igate.service;

import java.util.List;






import com.igate.beans.InterviewVO;
import com.igate.model.InterviewDetail;
import com.igate.model.Skill;

public interface InterviewScheduleService {

	public Integer addScheduleDetails(InterviewVO interviewVO) throws Exception;
	public List<InterviewDetail> getAllAvilableInterviews();
	
	public List<InterviewDetail> getAllAvilableInterviewsSkill();
	
	public InterviewDetail getInterviewById(int interviewId);
	
	public Integer updateInterviewData(InterviewVO interviewVO);
	
	public List<Skill> getIntervSkillsById(int interviewId) ;
	
	public Integer deleteInterviewData(String[] strarray);
	
	
	
	}

