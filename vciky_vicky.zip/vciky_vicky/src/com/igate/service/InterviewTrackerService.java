package com.igate.service;

import com.igate.beans.InterviewTrackerVO;

public interface InterviewTrackerService {
	
	public String addInterviewTrackerData(InterviewTrackerVO interviewTracker);

}
