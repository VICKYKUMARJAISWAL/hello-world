package com.igate.service;

import java.util.List;

import com.igate.beans.LocationVO;
import com.igate.model.Location;


public interface LocationService {
	
	//public List<Location> getAllAvailableLocations();
	public Integer addLocationData(LocationVO locationvo);
	public Integer updateLocationData(LocationVO locationvo);
	public Location getLocationById(int id);
	public Integer deleteLocationData(String[] strarray);


}
