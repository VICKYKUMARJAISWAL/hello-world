package com.igate.service;

import java.util.List;

import com.igate.model.BusinessUnit;
import com.igate.model.InterviewStatus;
import com.igate.model.Location;
import com.igate.model.LocationLog;
import com.igate.model.ModeOfInterview;
import com.igate.model.Project;
import com.igate.model.ProjectLog;
import com.igate.model.Skill;
import com.igate.model.SkillLog;
import com.igate.model.Training;
import com.igate.model.TrainingCategory;
import com.igate.model.TrainingMode;
import com.igate.model.TypeOfInterview;
import com.igate.model.User;

/**
 * @author rm832401
 * 
 */

public interface MasterDataService {

	public List<Skill> getAllSkills();
	
	
	public List<SkillLog> getAllSkillsLog(String id);

	public List<SkillLog> getAllSkillsDeletedLog();

	public List<Location> getAllLocations();

	public List<Project> getAllProjects();

	public Project getProject(String userId);

	public List<TypeOfInterview> getAllTypeOfInterviews();

	public List<ModeOfInterview> getAllModeOfInterviews();

	public List<BusinessUnit> getAllBusinessunits();

	public List<User> getAllUsers();

	public List<TrainingCategory> getAllTrainingCategories();

	public List<TrainingMode> getAllTrainingModes();
	
	public List<InterviewStatus> getAllStatus();
	public List<LocationLog> getAllLocationsLog(String id);
    public List<LocationLog> getAllLocationsDeletedLog();
    
    
    
    public List<ProjectLog> getAllProjectsLog(String id);
    public List<ProjectLog> getAllProjectsDeletedLog();
	//public List<Training> getAllTrainingContentType();
	

	
	
	
	/*
	 * id "row_id"  IDENTITY ,
		status_name VARCHAR(20)  NOT NULL,
		created_by CHAR(8)  NOT NULL,
		created_date DATETIME  NOT NULL
	 */
	

}
