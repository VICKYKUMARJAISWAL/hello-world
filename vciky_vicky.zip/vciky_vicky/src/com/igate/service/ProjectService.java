package com.igate.service;

import com.igate.beans.ProjectVO;
import com.igate.model.Project;

public interface ProjectService {
 public Integer  addProject(ProjectVO ProjectVO);
 public Project   getProjectById(Short id);
 public Integer   updateProject(ProjectVO ProjectVO);
 //public Integer deleteProject(Short id);
 public Integer deleteProject(String[] id);
}
