package com.igate.service;

import com.igate.beans.SkillVO;
import com.igate.model.Skill;
import com.igate.beans.SkillLogBean;
public interface SkillService {
	public Integer addSkill(SkillVO skillVo,SkillLogBean skillLogBean);
	/*public Integer addSkill(SkillVO skillVo);*/
	public Skill getSkillById(Short id);
	public Integer updateSkill(SkillVO skillvo);
	public Integer deleteSkill(String[] id);
	public Integer addSkillLog(SkillLogBean SkillLogBean);
	}
