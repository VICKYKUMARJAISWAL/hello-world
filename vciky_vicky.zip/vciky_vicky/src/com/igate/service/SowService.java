package com.igate.service;

import java.util.List;

import com.igate.model.Sow;

public interface SowService {
	public List<Sow> getSowList();
}
