/**
 * 
 */
package com.igate.service;

import java.util.List;

import com.igate.beans.TrainingVO;
import com.igate.model.Training;
import com.igate.model.TrainingAssign;

/**
 * @author rm832401
 *
 */
public interface TrainingService {
	
	public Integer addTraining(TrainingVO training);
	public List<String> getContentType();
	public List<Training> getAllAvilableTraining();
	public Training getTrainingById(int id);
	public Integer updateTraining(TrainingVO training);
	public List<String> getCourseName();
	public List<String> getVenueNames();
	public Integer deletetraining(String[] id);
	
	public Integer assignTraining(TrainingAssign t);
	
}
