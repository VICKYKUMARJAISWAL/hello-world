/**
 * 
 */
package com.igate.service;

import java.util.List;

import com.igate.model.InterviewStatusType;
import com.igate.model.User;
import com.igate.model.UserProfile;
import com.igate.model.UserStatus;
import com.igate.model.UserType;


/**
 * @author rm832401
 *
 */

public interface UserService {
public Integer addUser(User user)throws Exception;
public Integer loginUser(User user)throws Exception;
public UserType getUserType(short type)throws Exception;
public UserProfile getUserProfileData(String userID)throws Exception;
public Integer updateUserProfileData(UserProfile userProfile)throws Exception;
public Integer updatePassword(User user)throws Exception;
public User getUserData(String userId)throws Exception;
public List<UserStatus> getUserStatus()throws Exception;
public UserStatus getUserStatus(short status)throws Exception;
public InterviewStatusType getInterviewStatusType(short id)throws Exception;
public List<User>getUserList()throws Exception;
public User getCompleteUserData(String userID);
public Integer updateUser(User user);
public Integer deleteUsers(String[] stringArray); 

}
