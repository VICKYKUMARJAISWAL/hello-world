package com.igate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.Dao.BeSheetDao;
import com.igate.Dao.TrainingDao;
import com.igate.model.BeSheet;
import com.igate.service.BeSheetService;
@Service
public class BeSheetServiceImpl implements BeSheetService{

	@Autowired
	BeSheetDao beSheetDao;
	
	@Override
	public List<BeSheet> getBeSheetDetails(int year) {
		// TODO Auto-generated method stub
		return beSheetDao.getBeSheetDetails(year);
	}

}
