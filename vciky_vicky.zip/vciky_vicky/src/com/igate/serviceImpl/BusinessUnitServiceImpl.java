package com.igate.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.igate.Dao.BusinessUnitDao;
import com.igate.beans.BusinessUnitVO;
import com.igate.model.BusinessUnit;
import com.igate.service.BusinessUnitService;
@Service
public class BusinessUnitServiceImpl implements BusinessUnitService{
  
	@Autowired
	BusinessUnitDao businessUnitDao;
	
	@Override
	@Transactional
	public Integer addBusinessUnit(BusinessUnitVO businessUnitVO) {
		// TODO Auto-generated method stub
		return businessUnitDao.addBuUnit(businessUnitVO);
	}

	@Override
	@Transactional
	public BusinessUnit getBuUnitById(Short id) {
		// TODO Auto-generated method stub
		return businessUnitDao.getBuUnitByID(id);
	}


}
