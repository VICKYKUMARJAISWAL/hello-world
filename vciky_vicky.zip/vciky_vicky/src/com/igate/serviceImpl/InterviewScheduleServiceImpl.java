package com.igate.serviceImpl;

import java.util.List;









import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.igate.Dao.InterviewScheduleDao;
import com.igate.beans.InterviewVO;
import com.igate.model.InterviewDetail;
import com.igate.model.Skill;
import com.igate.service.InterviewScheduleService;

@Service
public class InterviewScheduleServiceImpl implements InterviewScheduleService {
	@Autowired
	InterviewScheduleDao interviewScheduleDao;
	
	@Transactional
	@Override
	public Integer addScheduleDetails(InterviewVO interviewVO)throws Exception{
		return interviewScheduleDao.addScheduleDetailsData(interviewVO);
	}
	
	@Override
	public List<InterviewDetail> getAllAvilableInterviews(){		
		return interviewScheduleDao.getAllAvilableInterviews();
	}

	@Override
	public InterviewDetail getInterviewById(int interviewId) {
		// TODO Auto-generated method stub
		return interviewScheduleDao.getInterviewById(interviewId);
	}

	@Override
	public List<InterviewDetail> getAllAvilableInterviewsSkill() {
		
		return interviewScheduleDao.getAllAvilableInterviewsSkills();
	}

	@Transactional
	@Override
	public Integer updateInterviewData(InterviewVO interviewVO) {
		// TODO Auto-generated method stub
		Integer status=0;
		try {
			status= interviewScheduleDao.updateInterviewData(interviewVO);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public List<Skill> getIntervSkillsById(int interviewId) {
		return interviewScheduleDao.getIntervSkillsById(interviewId);
		 
	}

	@Transactional
	@Override
	public Integer deleteInterviewData(String[] strarray) {
		// TODO Auto-generated method stub
		System.out.println("serviceimpl del");
		Integer status=0;
		try {
			status= interviewScheduleDao.deleteInterviewData(strarray);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}

	
}
