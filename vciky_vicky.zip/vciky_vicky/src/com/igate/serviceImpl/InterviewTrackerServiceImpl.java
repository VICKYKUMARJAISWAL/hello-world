package com.igate.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.igate.Dao.InterviewTrackerDao;
import com.igate.beans.InterviewTrackerVO;
import com.igate.service.InterviewTrackerService;


public class InterviewTrackerServiceImpl implements InterviewTrackerService {

	@Autowired
	InterviewTrackerDao interviewDao;
	@Transactional
	@Override
	public String addInterviewTrackerData(InterviewTrackerVO interviewTracker) {
		// TODO Auto-generated method stub
		String status = interviewDao.addInterviewTrackerData(interviewTracker);
		return status;
	}

}
