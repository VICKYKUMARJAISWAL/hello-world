package com.igate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.igate.Dao.LocationDao;
import com.igate.beans.LocationVO;
import com.igate.model.Location;
import com.igate.service.LocationService;

public class LocationServiceImpl implements LocationService{
		
	@Autowired
	LocationDao locationDao;
	
	/*@Override
	public List<Location> getAllAvailableLocations() {
		return locationDao.getAllAvailableLocations();

	}*/
	
	@Transactional
	@Override	
	public Integer addLocationData(LocationVO locationvo){
		return locationDao.addLocationData(locationvo);
	}
	@Transactional
	@Override
	public Location getLocationById(int id){
		return locationDao.getLocationById(id);
	}
	@Transactional
	@Override
	public Integer updateLocationData(LocationVO locationvo){
		Integer status=0;
		try {
			status= locationDao.updateLocationData(locationvo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}
	
	
	@Transactional
	@Override
	public Integer deleteLocationData(String[] strarray){
		System.out.println("serviceimpl del");
		Integer status=0;
		try {
			status= locationDao.deleteLocationData(strarray);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}

}
