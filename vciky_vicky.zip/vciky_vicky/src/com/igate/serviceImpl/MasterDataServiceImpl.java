package com.igate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.igate.Dao.MasterDataDao;
import com.igate.model.BusinessUnit;
import com.igate.model.Location;
import com.igate.model.LocationLog;
import com.igate.model.ModeOfInterview;
import com.igate.model.Project;
import com.igate.model.ProjectLog;
import com.igate.model.Skill;
import com.igate.model.InterviewStatus;
import com.igate.model.SkillLog;
import com.igate.model.Training;
import com.igate.model.TrainingCategory;
import com.igate.model.TrainingMode;
import com.igate.model.TypeOfInterview;
import com.igate.model.User;
import com.igate.service.MasterDataService;

/**
 * @author rm832401
 *
 */
public class MasterDataServiceImpl implements MasterDataService {
	@Autowired
	MasterDataDao masterDataDao;
	@Override
	@Transactional
	public List<Skill> getAllSkills() {
		return masterDataDao.getAllSkills();
	}

	@Override
	@Transactional
	public List<Location> getAllLocations() {
		System.out.println(masterDataDao.getAllLocations());
		return masterDataDao.getAllLocations();
	}

	@Override
	@Transactional
	public List<Project> getAllProjects() {
		System.out.println(masterDataDao.getAllProjects());
	return masterDataDao.getAllProjects();	
	
	}

	@Override
	@Transactional
	public Project getProject(String userId) {
		return masterDataDao.getProject(userId);
	}

	@Override
	@Transactional
	public List<TypeOfInterview> getAllTypeOfInterviews() {
		return masterDataDao.getAllTypeOfInterviews();
	}

	@Override
	@Transactional
	public List<ModeOfInterview> getAllModeOfInterviews() {
		return masterDataDao.getAllModeOfInterviews();
	}

	@Override
	@Transactional
	public List<BusinessUnit> getAllBusinessunits() {
		// TODO Auto-generated method stub
		return masterDataDao.getAllBusinessunits();
	}
	@Override
	@Transactional
	public List<User> getAllUsers()
	{
		return masterDataDao.getAllUsers();
	}
	@Override
	@Transactional
	public List<TrainingCategory> getAllTrainingCategories() {
		// TODO Auto-generated method stub
		return masterDataDao.getAllTrainingCategories();
	}
	/*@Override
	@Transactional
	public List<Training> getAllTrainingContentType() {
		// TODO Auto-generated method stub
		return masterDataDao.getAllTrainingContentType();
	}*/
	
	@Override
	@Transactional
	public List<TrainingMode> getAllTrainingModes() {
		// TODO Auto-generated method stub
		return masterDataDao.getAllTrainingModes();
	}


	
	
	@Override
	@Transactional
	public List<InterviewStatus> getAllStatus() {
		System.out.println(masterDataDao.getAllStatus());
		return masterDataDao.getAllStatus();
	}

	@Override
    @Transactional
    public List<LocationLog> getAllLocationsDeletedLog() {
                                                    return masterDataDao.getAllLocationsDeletedLog();
    }


@Override
    @Transactional
    public List<LocationLog> getAllLocationsLog(String id) {
                    System.out.println(masterDataDao.getAllLocationsLog(id));
                    return masterDataDao.getAllLocationsLog(id);
    }




	@Override
	@Transactional
	public List<ProjectLog> getAllProjectsLog(String id) {
		System.out.println(masterDataDao.getAllProjectsLog(id));
	return masterDataDao.getAllProjectsLog(id);	
	
	}
	
	@Override
	@Transactional
	public List<ProjectLog> getAllProjectsDeletedLog() {
		System.out.println(masterDataDao.getAllProjectsDeletedLog());
	return masterDataDao.getAllProjectsDeletedLog();	

}
	
	
	@Override
	@Transactional
	public List<SkillLog> getAllSkillsLog(String id) {
		return masterDataDao.getAllSkillsLog(id);
	}
	
	@Override
	@Transactional
	public List<SkillLog> getAllSkillsDeletedLog() {
		return masterDataDao.getAllSkillsDeletedLog();
	}
	
	
}
