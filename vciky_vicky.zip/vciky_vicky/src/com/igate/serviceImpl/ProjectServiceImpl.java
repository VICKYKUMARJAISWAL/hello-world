package com.igate.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.igate.Dao.ProjectDao;
import com.igate.beans.ProjectVO;
import com.igate.model.Project;
import com.igate.service.ProjectService;
@Service
public class ProjectServiceImpl implements ProjectService{
	
	@Autowired
	private ProjectDao projectDao;

	@Override
	@Transactional
	public Integer addProject(ProjectVO projectVO) {
		// TODO Auto-generated method stub
		return projectDao.addProject(projectVO);
	}

	@Override
	@Transactional
	public Project getProjectById(Short id) {
		// TODO Auto-generated method stub
		return projectDao.getProjectById(id);
	}

	@Override
	@Transactional
	public Integer updateProject(ProjectVO projectVO) {
		// TODO Auto-generated method stub
		return projectDao.updateProject(projectVO);
	}

	/*@Override
	@Transactional
	public Integer deleteProject(Short id) {
		// TODO Auto-generated method stub
		return projectDao.deleteProject(id);
	}*/

	@Override
	@Transactional
	public Integer deleteProject(String[] id) {
		// TODO Auto-generated method stub
		return projectDao.deleteProject(id);
	}

}
