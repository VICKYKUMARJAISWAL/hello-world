package com.igate.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.igate.beans.SkillLogBean;
import com.igate.Dao.SkillDao;
import com.igate.beans.SkillVO;
import com.igate.model.Skill;
import com.igate.service.SkillService;
@Service
public class SkillServiceImpl implements SkillService{
    @Autowired
	private SkillDao skillDao;
    
    @Override
	@Transactional
	public Integer addSkill(SkillVO skillVo,SkillLogBean skillLogBean) {
		// TODO Auto-generated method stub
		System.out.println("User Id"+skillVo.getCreatedBy());
		return skillDao.addKill(skillVo,skillLogBean);
	}


	@Override
	@Transactional
	public Skill getSkillById(Short id) {
		// TODO Auto-generated method stub
		return skillDao.getSkillByID(id);
	}

	@Override
	@Transactional
	public Integer updateSkill(SkillVO skillvo) {
		// TODO Auto-generated method stub
		return skillDao.updateSkill(skillvo);
	}

	@Override
	@Transactional
	public Integer deleteSkill(String[] id) {
		// TODO Auto-generated method stub
		return skillDao.deleteSkill(id);
	}

	@Override
	@Transactional
	public Integer addSkillLog(SkillLogBean SkillLog) {
		// TODO Auto-generated method stub
		return skillDao.addSkillLog(SkillLog);
	}

}
