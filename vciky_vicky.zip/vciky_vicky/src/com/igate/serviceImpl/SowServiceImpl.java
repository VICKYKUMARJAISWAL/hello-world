package com.igate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.igate.Dao.SowDao;
import com.igate.model.Sow;
import com.igate.service.SowService;

public class SowServiceImpl implements SowService{
	@Autowired
	SowDao sowDao;
	
	@Override
	public List<Sow> getSowList() {
		return (List<Sow>) sowDao.getSowList();
	}

}
