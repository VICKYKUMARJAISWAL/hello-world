package com.igate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.igate.Dao.TrainingDao;
import com.igate.beans.TrainingVO;
import com.igate.model.Training;
import com.igate.model.TrainingAssign;
import com.igate.service.TrainingService;

public class TrainingServiceImpl implements TrainingService {
	@Autowired
	TrainingDao trainingDao;
	@Override
	@Transactional
	public Integer addTraining(TrainingVO training) {
		
		return trainingDao.addTraining(training);
	}
	
	@Override
	public List<Training> getAllAvilableTraining() {
		return trainingDao.getAvilableTraining();

	}

	@Override
	public Training getTrainingById(int id) {
		// TODO Auto-generated method stub
		return trainingDao.getTrainingById(id);
	}
	
	@Override
	@Transactional
	public Integer updateTraining(TrainingVO training) {
		
		return trainingDao.updateTraining(training);
	}

	@Override
	public List<String> getContentType() {
		// TODO Auto-generated method stub
		return trainingDao.getContentType();
	}
	
	@Override
	public List<String> getCourseName() {
		// TODO Auto-generated method stub
		return trainingDao.getCourseName();
	}

	@Override
	public List<String> getVenueNames() {
		// TODO Auto-generated method stub
		return trainingDao.getVenueNames();
	}

	@Override
	public Integer deletetraining(String[] id) {
		// TODO Auto-generated method stub
		return trainingDao.deleteTraining(id);
	}

	
	@Override
	@Transactional
	public Integer assignTraining(TrainingAssign t) {
		// TODO Auto-generated method stub
		System.out.println("inside service assign");
		return trainingDao.assignTraining(t);
	}

}
