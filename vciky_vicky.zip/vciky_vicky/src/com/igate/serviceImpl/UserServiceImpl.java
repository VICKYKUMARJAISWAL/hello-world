package com.igate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.igate.Dao.UserDao;
import com.igate.model.InterviewStatusType;
import com.igate.model.User;
import com.igate.model.UserProfile;
import com.igate.model.UserStatus;
import com.igate.model.UserType;
import com.igate.service.UserService;
/**
 * @author rm832401
 *
 */
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserDao userDao;
	@Override
	@Transactional
	public Integer addUser(User user) throws Exception{
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}
	@Override
	@Transactional
	public Integer loginUser(User user)throws Exception {
		return userDao.loginUser(user);
	}
	@Override
	@Transactional
	public UserType getUserType(short type){
		return userDao.getUserType(type);
	}
	@Override
	@Transactional
	public UserProfile getUserProfileData(String userID)throws Exception{
		return userDao.getUserProfileData(userID);
	}
	@Override
	@Transactional
	public Integer updateUserProfileData(UserProfile userProfile)throws Exception{
		return userDao.updateUserProfileData(userProfile);
	}
	@Override
	@Transactional
	public Integer updatePassword(User user)throws Exception{
		return userDao.updatePassword(user);
	}
	@Override
	@Transactional
	public User getUserData(String userId)throws Exception{
		return userDao.getUserData(userId);
	}
	@Override
	@Transactional
	public List<UserStatus>getUserStatus(){
		return userDao.getUserStatus();
	}
	@Override
	@Transactional
	public UserStatus getUserStatus(short status) {
		return userDao.getUserStatus(status);
	}
	
	@Transactional
	public InterviewStatusType getInterviewStatusType(short id) {
		// TODO Auto-generated method stub
		return userDao.getInterviewStatusType(id);
	}
	@Override
	public List<User> getUserList() throws Exception {
		return userDao.getUserList();
	}
	@Override
	public User getCompleteUserData(String userID) {
		// TODO Auto-generated method stub
		 return userDao.getCompleteUserData(userID);
	}
	@Override
	public Integer updateUser(User user) {
		return userDao.updateUser(user);
	}
	@Override
	public Integer deleteUsers(String[] stringArray) {
		// TODO Auto-generated method stub
		return userDao.deleteUser(stringArray);
	}
	
	
	
	
}
