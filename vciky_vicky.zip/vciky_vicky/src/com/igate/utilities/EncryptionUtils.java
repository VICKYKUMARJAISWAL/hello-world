package com.igate.utilities;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Encoder;

public class EncryptionUtils {

	

	/**
	 * Returns encrypted string for given text
	 * @param String text
	 * @return encrypted string
	 */
	public static String encryptString(String str) {
		final  String key = "Bar12345Bar12345";
		final  String encrytoinType = "AES";
		Key aesKey = new SecretKeySpec(key.getBytes(), encrytoinType);
		Cipher cipher;
		String encryptString = null;
		try {
			cipher = Cipher.getInstance("AES/NoPadding");
			cipher.init(Cipher.ENCRYPT_MODE, aesKey);
			byte[] encrypted = cipher.doFinal(str.getBytes("UTF8"));
			BASE64Encoder encoder = new BASE64Encoder();
			encryptString = encoder.encode(encrypted);
		} catch (UnsupportedEncodingException|BadPaddingException | NoSuchAlgorithmException
				| NoSuchPaddingException | IllegalBlockSizeException
				| InvalidKeyException e) {
			e.printStackTrace();
		}
		
		return encryptString;
	}
}
