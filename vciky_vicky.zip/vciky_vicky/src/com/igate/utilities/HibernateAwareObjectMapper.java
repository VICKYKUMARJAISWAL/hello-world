package com.igate.utilities;

import org.codehaus.jackson.map.ObjectMapper;

public class HibernateAwareObjectMapper extends ObjectMapper {

    public HibernateAwareObjectMapper() {
       //registerModule(new Hibernate4Module());
    }
}