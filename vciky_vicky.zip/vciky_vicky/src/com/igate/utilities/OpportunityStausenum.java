package com.igate.utilities;

public enum OpportunityStausenum {
	//Open, InProgress, Closed
	Open("Open"), InProgress("In Progress"), Closed("Closed");
	
    private final String displayName;

    OpportunityStausenum(final String display)
    {
        this.displayName = display;
    }

    public String getDisplayName()
    {
        return this.displayName;
    }
}
