package com.igate.utilities;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PasswordEncryptor {
	private static final Logger logger = LoggerFactory.getLogger(PasswordEncryptor.class);
	private SecretKeySpec secretKey;
	private byte[] key;
	private String decryptedString;
	private String encryptedString;

	public PasswordEncryptor() {
		final String strPsswordSecretKey = "encryptor key";
		setKey(strPsswordSecretKey);
	}

	public void setKey(String myKey) {
		MessageDigest sha = null;
		try {
			key = myKey.getBytes("UTF-8");
			sha = MessageDigest.getInstance("SHA-1");
			key = sha.digest(key);
			key = new byte[16];
			secretKey = new SecretKeySpec(key, "AES");
		} catch (NoSuchAlgorithmException e) {
			logger.error("Security Exception" + e.getMessage());
		} catch (UnsupportedEncodingException e) {
			logger.error("Security Exception" + e.getMessage());
		}
	}

	public String getDecryptedString() {
		return decryptedString;
	}

	public void setDecryptedString(String decryptedString) {
		this.decryptedString = decryptedString;
	}

	public String getEncryptedString() {
		return encryptedString;
	}

	public void setEncryptedString(String encryptedString) {
		this.encryptedString = encryptedString;
	}

	public void encrypt(String strToEncrypt) {
		try {
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			setEncryptedString(new BASE64Encoder().encode(cipher
					.doFinal(strToEncrypt.getBytes("UTF-8"))));
		} catch (Exception e) {
			logger.error("Error while encrypting: " + e.getMessage().toString());
		}
	}

	public void decrypt(String strToDecrypt) {
		try {
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			setDecryptedString(new String(cipher.doFinal(new BASE64Decoder()
					.decodeBuffer(strToDecrypt))));
		} catch (Exception e) {
			logger.error("Error while decrypting: " + e.getMessage().toString());
		}
	}
}