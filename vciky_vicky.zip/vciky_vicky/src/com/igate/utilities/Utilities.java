package com.igate.utilities;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

public class Utilities {
	public static Timestamp currentDate(){
		Calendar calendar = Calendar.getInstance();
		Date now = calendar.getTime();
		Timestamp createdDate =new Timestamp(now.getTime());
		return createdDate;
	}

}


